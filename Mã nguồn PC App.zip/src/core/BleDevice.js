import { EventEmitter } from "./EventEmitter";

const SERVICE = "0000ab00-0000-1000-8000-00805f9b34fb";
const AB01 = "0000ab01-0000-1000-8000-00805f9b34fb"; // write
const AB02 = "0000ab02-0000-1000-8000-00805f9b34fb"; // notify

export class BleDevice extends EventEmitter {
    constructor() {
        super();

        this.connected = false;
        this.device = null;
        this.server = null;
        this.service = null;
        this.txChar = null;
        this.rxChar = null;

        this.rxHandler = null;

        // bind để giữ this
        this.onDisconnected = this.onDisconnected.bind(this);

        this.writeLock = Promise.resolve();
    }

    // ===== CONNECT =====
    async connect() {
        try {
            // --- Check support ---
            if (!navigator.bluetooth) {
                alert("Máy / Browser không hỗ trợ BLE");
                return false;
            }

            const isAvailable =
                await navigator.bluetooth.getAvailability();

            if (!isAvailable) {
                console.log("BLE tắt hoặc không có adapter");
                return false;
            }

            // --- Request device ---
            this.device =
                await navigator.bluetooth.requestDevice({
                    filters: [{ services: [SERVICE] }],
                });

            if (!this.device) {
                this.emit("connectChange", false);
                return false;
            }

            // --- Connect GATT ---
            this.server = await this.device.gatt.connect();
            this.service = await this.server.getPrimaryService(SERVICE);
            this.device.addEventListener("gattserverdisconnected", this.onDisconnected);

            // --- Characteristics ---
            this.txChar = await this.service.getCharacteristic(AB01);
            this.rxChar = await this.service.getCharacteristic(AB02);

            // --- Start notify ---
            await this.rxChar.startNotifications();

            this.rxHandler = (e) => {
                const raw = new Uint8Array(
                    e.target.value.buffer
                );

                // ===== PAD TO 256 =====
                const data = new Uint8Array(256);
                data.set(raw, 0); // copy vào đầu

                //console.log("BLE RX:", data);
                this.emit("data", data);
            };


            this.rxChar.addEventListener(
                "characteristicvaluechanged",
                this.rxHandler
            );

            this.connected = true;
            this.emit("connectChange", true);

            return true;
        } catch (err) {
            console.error("BLE connect error:", err);
            this.connected = false;
            this.emit("connectChange", false);
            return false;
        }
    }

    // ===== DISCONNECT =====
    async disconnect() {
        try {
            if (this.rxChar && this.rxHandler) {
                this.rxChar.removeEventListener("characteristicvaluechanged", this.rxHandler);
            }
            if (this.device?.gatt?.connected) {
                this.device.gatt.disconnect();
            }
        } catch (err) {
            console.error("Disconnect error:", err);
        }

        this.connected = false;
        this.emit("connectChange", false);
    }

    // ===== AUTO DISCONNECT EVENT =====
    onDisconnected() {
        console.log("BLE disconnected");
        this.connected = false;
        this.emit("connectChange", false);
    }

    // ===== CHECK =====
    isConnected() {
        return this.connected;
    }

    // ===== SEND =====
    async send(data) {
        if (!this.connected || !this.txChar)
            return false;

        const buffer =
            data instanceof Uint8Array
                ? data
                : new Uint8Array(data);

        // ===== Serialize write =====
        this.writeLock = this.writeLock.then(async () => {
            try {
                await this.txChar.writeValue(buffer);
                //console.log("BLE TX:", Array.from(buffer).map(b => b.toString(16).padStart(2, "0")).join(" "));
            } catch (err) {
                console.error("BLE write error:", err);
                throw err;
            }
        });

        return this.writeLock
            .then(() => true)
            .catch(() => false);
    }


}

import { EventEmitter } from "./EventEmitter";
import { BleDevice } from "./BleDevice";
import { HidBridgeDevice } from "./HidBridgeDevice";

export class DeviceManager extends EventEmitter {
    static instance = null;

    static getInstance() {
        if (!DeviceManager.instance) {
            DeviceManager.instance = new DeviceManager();
        }
        return DeviceManager.instance;
    }

    constructor() {
        super();

        this.bleDevice = null;
        this.hidDevice = null;
        this.currentType = null;

        this._queue = [];
        this._pending = null;
        this._busy = false;
    }

    // ================= CONNECT =================

    async connect(type) {
        let ok = false;

        if (type === "hid") ok = await this.connectHid();
        else if (type === "ble") ok = await this.connectBle();

        if (!ok) return false;
        this.currentType = type;
        return true;
    }

    async connectHid() {
        if (!this.hidDevice) this.hidDevice = new HidBridgeDevice();

        this.hidDevice.on("data", (frame) => this._handleFrame(frame, "hid"));

        this.hidDevice.on("connectChange", (connected) => {
            this.emit("connectChange", { type: "hid", connected });
            if (!connected) this.disconnectAll();
        });

        return await this.hidDevice.connect();
    }

    async connectBle() {
        if (!this.bleDevice) this.bleDevice = new BleDevice();

        this.bleDevice.on("data", (frame) => {
            this._handleFrame(frame, "ble");
        });

        this.bleDevice.on("connectChange", (connected) => {
            this.emit("connectChange", { type: "ble", connected });
            if (!connected) this.disconnectAll();
        });

        return await this.bleDevice.connect();
    }

    disconnectAll() {
        this.hidDevice?.disconnect();
        this.bleDevice?.disconnect();

        this.hidDevice = null;
        this.bleDevice = null;
        this.currentType = null;

        this._queue = [];

        if (this._pending) {
            clearTimeout(this._pending.timer);
            this._pending.reject(new Error("Disconnected"));
            this._pending = null;
        }

        this._busy = false;
    }

    // ================= SEND =================

    send(cmd, payload = [], type = null, target = null) {
        return this._enqueue({
            cmd,
            payload,
            timeout: 0,
            type,
            target,
            noWait: true,
            retry: 0,
        });
    }

    sendAndWait(cmd, payload = [], timeout = 1000, type = null, target = null) {
        return this._enqueue({
            cmd,
            payload,
            timeout,
            type,
            target,
            noWait: false,
            retry: 0,
        });
    }

    _enqueue(item) {
        return new Promise((resolve, reject) => {
            this._queue.push({ ...item, resolve, reject });
            this._processQueue();
        });
    }

    // ================= QUEUE ENGINE =================

    async _processQueue() {
        if (this._busy) return;
        if (this._queue.length === 0) return;

        const item = this._queue.shift();
        const { cmd, payload, timeout, type, target, resolve, reject, noWait } = item;
        const deviceType = type || this.currentType;

        if (!deviceType) {
            reject(new Error("No device"));
            return;
        }

        const frame = this._buildFrame(cmd, payload, target);

        this._busy = true;

        if (!noWait) {
            this._pending = {
                cmd,
                resolve,
                reject,
                item,
                retry: item.retry,
                timer: null,
            };
        }

        let ok = false;
        try {
            if (deviceType === "hid") ok = await this.hidDevice.send(frame);
            else if (deviceType === "ble") ok = await this.bleDevice.send(frame);
        } catch {
            ok = false;
        }

        if (!ok) {
            this._pending = null;
            this._busy = false;
            reject(new Error("Send failed CMD " + cmd));
            queueMicrotask(() => this._processQueue());
            return;
        }

        if (noWait) {
            this._busy = false;
            resolve(true);
            queueMicrotask(() => this._processQueue());
            return;
        }


        // ---- WAIT RESPONSE ----
        const pendingRef = this._pending;
        if (!pendingRef) {
            this._processing = false;
            queueMicrotask(() => this._processQueue());
            return;
        }

        pendingRef.timer = setTimeout(() => {
            // Nếu pending đã bị clear → bỏ
            if (this._pending !== pendingRef) return;

            if (pendingRef.retry < 3) {
                pendingRef.retry++;
                pendingRef.item.retry = pendingRef.retry;

                this._pending = null;
                this._processing = false;

                this._queue.unshift(pendingRef.item);
                queueMicrotask(() => this._processQueue());
                return;
            }

            this._pending = null;
            this._processing = false;

            pendingRef.reject(new Error("Timeout CMD " + pendingRef.cmd));
            queueMicrotask(() => this._processQueue());
        }, timeout);
    }

    // ================= RX =================

    _handleFrame(frame, type) {
        if (Array.isArray(frame)) frame = new Uint8Array(frame);
        if (!frame || frame.length < 5) return;

        const cmd = frame[2];
        const len = frame[3];

        //console.log(cmd);
        this.emit("data", { type, cmd, data: frame.slice(4, 4 + len) });

        const p = this._pending;
        if (!p) return;

        if (p.cmd !== cmd) return;

        clearTimeout(p.timer);

        this._pending = null;
        this._busy = false;

        p.resolve(frame.slice(4, 4 + len));

        queueMicrotask(() => this._processQueue());
    }

    // ================= BUILD FRAME =================

    _buildFrame(cmd, payload, target) {
        const frame = new Uint8Array(256);
        const len = Math.min(payload.length, 252);

        if (target === "remid") {
            frame[0] = 0xA7;
            frame[1] = 0x7A;
        } else if (target === "effect") {
            frame[0] = 0xA5;
            frame[1] = 0x5A;
        } else {
            frame[0] = 0xA6;
            frame[1] = 0x6A;
        }

        frame[2] = cmd;
        frame[3] = len;
        frame.set(payload.slice(0, len), 4);
        frame[4 + len] = 0x16;

        return frame;
    }
}

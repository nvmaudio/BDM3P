import { EventEmitter } from "./EventEmitter";

export class HidBridgeDevice extends EventEmitter {
    isConnected = false;
    static instance = null;

    constructor() {
        super();

        HidBridgeDevice.instance = this;

        try {
            const bridge = window.chrome?.webview?.hostObjects?.bridge;
            if (bridge) {


                if (!window.__HID_LISTENER__) {
                    window.__HID_LISTENER__ = true;

                    window.chrome.webview.addEventListener("message", (event) => {
                        const msg = event.data;

                        if (msg === "DEVICE_DISCONNECTED") {
                            this.isConnected = false;
                            this.emit("connectChange", false);
                            return;
                        }

                        if (typeof msg === "string") {
                            const bytes = msg.split("-").map(h => parseInt(h, 16));

                            this.emit("data", bytes);
                        }
                    });
                }

            } else {
                console.warn("Bridge chưa sẵn sàng");
            }
        } catch (err) {
            console.error("Error initializing bridge callbacks:", err);
        }
    }

    async connect() {
        try {
            const bridge = window.chrome?.webview?.hostObjects?.bridge;
            if (!bridge) {
                console.error("Bridge chưa sẵn sàng");
                return false;
            }

            const ok = await bridge.ConnectDeviceAsync();

            if (ok) {
                this.isConnected = ok;
                this.emit("connectChange", ok);
                return ok;
            } else {
                this.isConnected = false;
                this.emit("connectChange", false);
                alert("Kết nối thiết bị thất bại");
                return false;
            }

        } catch (err) {
            console.error("Error in connect():", err);
            this.isConnected = false;
            this.emit("connectChange", false);
            return false;
        }
    }

    disconnect() {
        try {
            const bridge = window.chrome?.webview?.hostObjects?.bridge;
            if (bridge) bridge.Disconnect();
            this.isConnected = false;
        } catch (err) {
            console.error("Error in disconnect():", err);
        }
    }

    async send(payload) {

        // ===== tìm vị trí byte 0x16 đầu tiên =====
        let end = payload.indexOf(0x16);
        if (end === -1) end = payload.length;

        // ===== cắt mảng tới 0x16 =====
        const slice = payload.slice(0, end + 1);

        // ===== convert sang HEX =====
        //const hex = slice
        //    .map(b => "0x" + b.toString(16).padStart(2, "0").toUpperCase())
        //    .join(" ");

        //console.log("TX HEX:", hex);

        try {
            if (!this.isConnected) return false;

            const bridge = window.chrome?.webview?.hostObjects?.bridge;
            if (!bridge) return false;

            return await bridge.SendData(Array.from(payload), 1000);
        } catch (err) {
            console.error("Error in send():", err);
            return false;
        }
    }

}

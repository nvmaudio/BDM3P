// EventEmitter.js
export class EventEmitter {
    constructor() {
        this._events = {};
    }

    /**
     * Đăng ký sự kiện
     * @param {string} name - tên sự kiện
     * @param {Function} callback - hàm callback
     * @returns {Function} - hàm để hủy đăng ký
     */
    on(name, callback) {
        if (!this._events[name]) this._events[name] = [];
        this._events[name].push(callback);

        // Trả về hàm unsubscribe
        return () => this.off(name, callback);
    }

    /**
     * Hủy đăng ký sự kiện
     * @param {string} name - tên sự kiện
     * @param {Function} callback - hàm callback cần hủy
     */
    off(name, callback) {
        if (!this._events[name]) return;
        this._events[name] = this._events[name].filter(fn => fn !== callback);
    }

    /**
     * Phát sự kiện
     * @param {string} name - tên sự kiện
     * @param  {...any} args - dữ liệu gửi kèm
     */
    emit(name, ...args) {
        if (!this._events[name]) return;
        this._events[name].forEach(fn => fn(...args));
    }
}

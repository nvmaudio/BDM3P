import { useCallback } from "react";

import { DeviceManager } from "@core/DeviceManager";
import { useDeviceStore } from "@store/useDeviceStore";
import { useConfigStore } from "@store/useConfigStore";


const CMD = {
    Board_name: 1,
    Activate: 2,
    FW_Version: 3,
    HID_Version: 4,
    BLE_Version: 5,
    Delay_start: 6,
    Audio_mode: 7,
    Nho_mode: 8,
    Mode_mac_dinh: 9,
    Nho_mode_effect: 10,
    I2s0_en: 11,
    I2s1_en: 12,
    Volume_tong: 13,
    Nho_volume: 14,
    Dongbo_volume: 15,
    BT_Name: 16,
    Profile_BT: 17,
    A2dp_AAC: 18,
    Bt_BackgroundType: 19,
    Bt_SimplePairingEnable: 20,
    Bt_PinCode: 21,
    Thong_bao_en: 22,
    Volume_thong_bao: 23,
    Item_thong_bao: 24,
    Key_en: 25,
    Key_matrix: 26,
    Vr_en: 27,
    Pre_en: 28,
    Pre_mode: 29,
    Buoc_eq: 30,

    Vr_log: 200,
    Read_All: 201,
    Save: 255,
};

function parseSysParameter(buf) {
    if (!(buf instanceof Uint8Array)) {
        buf = Uint8Array.from(Object.values(buf));
    }

    const text = (start, len) => {
        return new TextDecoder()
            .decode(buf.slice(start, start + len))
            .replace(/\0/g, "")
            .trim();
    };

    const data = {};

    data.byte_check = buf[0];

    data.Board_name = text(1, 40);
    data.Activate = buf[41];

    data.FW_Version = buf.slice(42, 45);
    data.HID_Version = buf.slice(45, 48);
    data.BLE_Version = buf.slice(48, 51);

    data.Delay_start = buf[51];
    data.Audio_mode = buf[52];
    data.Nho_mode = buf[53];
    data.Mode_mac_dinh = buf[54];
    data.Nho_mode_effect = buf[55];

    data.I2s0_en = buf[56];
    data.I2s1_en = buf[57];

    data.Volume_tong = buf[58];
    data.Nho_volume = buf[59];
    data.Dongbo_volume = buf[60];

    data.BT_Name = text(61, 40);

    data.Profile_BT = buf[101];
    data.A2dp_AAC = buf[102];
    data.Bt_BackgroundType = buf[103];
    data.Bt_SimplePairingEnable = buf[104];

    data.Bt_PinCode = text(105, 6);

    data.Thong_bao_en = buf[111];
    data.Volume_thong_bao = buf[112];

    data.Item_thong_bao = Array.from(buf.slice(113, 121));

    data.Key_en = buf[121];

    // 11 x 5 matrix
    data.Key_matrix = [];
    let offset = 122;
    for (let r = 0; r < 11; r++) {
        data.Key_matrix.push(
            Array.from(buf.slice(offset, offset + 5))
        );
        offset += 5;
    }

    data.Vr_en = buf[177];
    data.Pre_en = buf[178];
    data.Pre_mode = buf[179];
    data.Buoc_eq = buf[180];

    return data;
}

function encodePayloadFromKey(key, value) {
    if (
        key.endsWith("_Version") ||
        key === "Item_thong_bao" ||
        key === "Vr_log"
    ) {
        return Array.from(value);
    }
    if (
        key === "Board_name" ||
        key === "BT_Name" ||
        key === "Bt_PinCode"
    ) {
        return Array.from(value).map((c) =>
            c.charCodeAt(0)
        );
    }

    if (key === "Key_matrix") {
        if (value instanceof Uint8Array)
            return Array.from(value);

        if (
            Array.isArray(value) &&
            Array.isArray(value[0])
        )
            return value.flat();

        if (Array.isArray(value)) return value;

        return [];
    }
    return [value];
}


export function useSystemConfig() {
    const dm = DeviceManager.getInstance();

    const connected = useDeviceStore((s) => s.connected);

    const data = useConfigStore((s) => s.data);
    const setField = useConfigStore((s) => s.setField);
    const setAll = useConfigStore((s) => s.setAll);
    const pushVrLog = useConfigStore((s) => s.pushVrLog);


    const sendAndWait = useCallback(async (cmd, payload = [], timeout = 3000, type = null) => {
        try {
            const data = await dm.sendAndWait(cmd, payload, timeout, type);
            return data;
        } catch (err) {
            console.error("sendAndWait error:", err);
            throw err;
        }
    }, [dm]);

    const sendAndWaitRemid = useCallback(async (cmd, payload = [], timeout = 3000, type = null) => {
        try {
            const data = await dm.sendAndWait(cmd, payload, timeout, type, "remid");
            return data;
        } catch (err) {
            console.error("sendAndWait error:", err);
            throw err;
        }
    }, [dm]);


    const loadData = useCallback(async () => {
        if (!connected) return;
        const temp = await sendAndWait(201);
        if (temp[0] === 0x97) {
            setAll(parseSysParameter(temp));
        }
        const temp2 = await sendAndWait(200);
        if (temp2) {
            pushVrLog(temp2);
        }
    }, [connected, sendAndWait, setAll]);


    const update = useCallback(async (key, value) => {
        const state = useConfigStore.getState();
        const current = state.data[key];
        const newValue = typeof value === "function" ? value(current) : value;
        setField(key, newValue);
        const cmd = CMD[key];
        if (!cmd) return;
        const payload = encodePayloadFromKey(key, newValue);
        await sendAndWait(cmd, payload);
    }, [connected, sendAndWait, setField]);

    const save = useCallback(async () => {
        const temp = await sendAndWait(255);
        if (temp[0] === 1) {
            alert("Lưu thành công, Sẽ áp dụng cho lần khởi động kế tiếp!");
        }
    }, [connected, sendAndWait]);


    const onData = useCallback((callback) => {
        dm.on("data", callback);
        return () => dm.off("data", callback);
    }, [dm]);

    return {
        data,
        loadData,
        onData,
        pushVrLog,

        update,
        save,

        sendAndWait,
        sendAndWaitRemid
    };
}

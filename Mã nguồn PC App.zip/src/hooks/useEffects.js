import { useCallback } from "react";

import { DeviceManager } from "@core/DeviceManager";
import { useDeviceStore } from "@store/useDeviceStore";
import { useEffectStore } from "@store/useEffectStore";


export const EffectTypeMap = {
    2: "DRC",
    4: "EQ",
    5: "EXPANDER",
    8: "NOISE_GATE",
    9: "PITCH_SHIFTER",
    10: "REVERB",
    11: "SILENCE_DETECTOR",
    12: "THREE_D",
    13: "VIRTUAL_BASS",
    14: "VOICE_CHANGER",
    15: "GAIN_CONTROL",
    20: "PHASE_CONTROL",
    23: "VIRTUAL_BASS_CLASSIC",
    24: "PCM_DELAY",
    25: "EXCITER",
    26: "CHORUS",
    28: "STEREO_WIDENER",
    30: "THREE_D_PLUS",
    32: "NOISE_Suppressor_Blue",
    33: "FLANGER",
    35: "OVERDRIVE",
    36: "DISTORTION",
    37: "EQ_DRC",
    38: "AEC",
    39: "DISTORTION_DS1",
    40: "OVERDRIVE_POLY",
    41: "COMPANDER",
    42: "LOW_LEVEL_COMPRESSOR",
    101: "DynamicEQ",
};


export function getEffectType(id) {
    return EffectTypeMap[id] || "UNKNOWN";
}


export const effect_list1 = [
    {
        "index": 1,
        "cmdIndex": 129,
        "id": 15,
        "hex": "000f",
        "type": "GAIN_CONTROL",
        "name": "BT Play Gain",
        "group": 0
    },
    {
        "index": 2,
        "cmdIndex": 130,
        "id": 15,
        "hex": "000f",
        "type": "GAIN_CONTROL",
        "name": "USB Device Gain",
        "group": 0
    },
    {
        "index": 3,
        "cmdIndex": 131,
        "id": 5,
        "hex": "0005",
        "type": "EXPANDER",
        "name": "Music Noise Suppressor",
        "group": 2
    },
    {
        "index": 5,
        "cmdIndex": 133,
        "id": 4,
        "hex": "0004",
        "type": "EQ1",
        "name": "Music Preamp EQ",
        "group": 1
    },
    {
        "index": 6,
        "cmdIndex": 134,
        "id": 41,
        "hex": "0029",
        "type": "COMPANDER",
        "name": "DAC0 Compander",
        "group": 2
    },
    {
        "index": 7,
        "cmdIndex": 135,
        "id": 13,
        "hex": "000d",
        "type": "VIRTUAL_BASS",
        "name": "DAC0 VB",
        "group": 2
    },
    {
        "index": 8,
        "cmdIndex": 136,
        "id": 23,
        "hex": "0017",
        "type": "VIRTUAL_BASS_CLASSIC",
        "name": "DAC0 VB Classic",
        "group": 2
    },
    {
        "index": 9,
        "cmdIndex": 137,
        "id": 12,
        "hex": "000c",
        "type": "THREE_D",
        "name": "DAC0 3D",
        "group": 2
    },
    {
        "index": 10,
        "cmdIndex": 138,
        "id": 25,
        "hex": "0019",
        "type": "EXCITER",
        "name": "DAC0 Exciter",
        "group": 2
    },
    {
        "index": 11,
        "cmdIndex": 139,
        "id": 28,
        "hex": "001c",
        "type": "STEREO_WIDENER",
        "name": "DAC0 Stereo Widener",
        "group": 2
    },
    {
        "index": 12,
        "cmdIndex": 140,
        "id": 4,
        "hex": "0004",
        "type": "EQ",
        "name": "DAC0 DynamicEQLP",
        "group": 2
    },
    {
        "index": 13,
        "cmdIndex": 141,
        "id": 4,
        "hex": "0004",
        "type": "EQ",
        "name": "DAC0 DynamicEQHP",
        "group": 2
    },
    {
        "index": 14,
        "cmdIndex": 142,
        "id": 101,
        "hex": "0065",
        "type": "DYNAMIC_EQ",
        "name": "DAC0 Dynamic EQ",
        "group": 2
    },
    {
        "index": 15,
        "cmdIndex": 143,
        "id": 4,
        "hex": "0004",
        "type": "EQ",
        "name": "DAC0 EQ DSP",
        "group": 2
    },
    {
        "index": 16,
        "cmdIndex": 144,
        "id": 2,
        "hex": "0002",
        "type": "DRC",
        "name": "DAC0 DRC",
        "group": 2
    },
    {
        "index": 17,
        "cmdIndex": 145,
        "id": 15,
        "hex": "000f",
        "type": "GAIN_CONTROL",
        "name": "DAC0 GAIN_OUT",
        "group": 2
    },
    {
        "index": 18,
        "cmdIndex": 146,
        "id": 4,
        "hex": "0004",
        "type": "EQ",
        "name": "DAC0 L EQ DSP",
        "group": 2
    },
    {
        "index": 19,
        "cmdIndex": 147,
        "id": 4,
        "hex": "0004",
        "type": "EQ",
        "name": "DAC0 R EQ DSP",
        "group": 2
    },
    {
        "index": 200,
        "cmdIndex": 9,
        "id": 200,
        "hex": "0004",
        "type": "Gain_dac0",
        "name": "DAC0 GAIN R + L",
        "group": 2
    },
    {
        "index": 20,
        "cmdIndex": 148,
        "id": 20,
        "hex": "0014",
        "type": "PHASE_CONTROL",
        "name": "DACX Phase Control",
        "group": 3
    },
    {
        "index": 21,
        "cmdIndex": 149,
        "id": 24,
        "hex": "0018",
        "type": "PCM_DELAY",
        "name": "DACX Phase Delay",
        "group": 3
    },
    {
        "index": 22,
        "cmdIndex": 150,
        "id": 13,
        "hex": "000d",
        "type": "VIRTUAL_BASS",
        "name": "DACX VB",
        "group": 3
    },
    {
        "index": 23,
        "cmdIndex": 151,
        "id": 23,
        "hex": "0017",
        "type": "VIRTUAL_BASS_CLASSIC",
        "name": "DACX VB Classic",
        "group": 3
    },
    {
        "index": 24,
        "cmdIndex": 152,
        "id": 4,
        "hex": "0004",
        "type": "EQ",
        "name": "DACX DynamicEQLP",
        "group": 3
    },
    {
        "index": 25,
        "cmdIndex": 153,
        "id": 4,
        "hex": "0004",
        "type": "EQ",
        "name": "DACX DynamicEQHP",
        "group": 3
    },
    {
        "index": 26,
        "cmdIndex": 154,
        "id": 101,
        "hex": "0065",
        "type": "DYNAMIC_EQ",
        "name": "DACX Dynamic EQ",
        "group": 3
    },
    {
        "index": 27,
        "cmdIndex": 155,
        "id": 4,
        "hex": "0004",
        "type": "EQ",
        "name": "DACX EQ DSP",
        "group": 3
    },
    {
        "index": 28,
        "cmdIndex": 156,
        "id": 2,
        "hex": "0002",
        "type": "DRC",
        "name": "DACX DRC",
        "group": 3
    },
    {
        "index": 29,
        "cmdIndex": 157,
        "id": 15,
        "hex": "000f",
        "type": "GAIN_CONTROL",
        "name": "DACX GAIN_OUT",
        "group": 3
    }
]

export function useEffects() {

    const dm = DeviceManager.getInstance();
    const connected = useDeviceStore((s) => s.connected);

    //    const effect_list = useEffectStore((s) => s.effect_list);

    const effect_list = effect_list1;
    const setAll_Effect = useEffectStore((s) => s.setAll_Effect);




    const sendAndWait = useCallback(async (cmd, payload = [], timeout = 3000, type = null) => {
        try {
            const data = await dm.sendAndWait(cmd, payload, timeout, type);
            return data;
        } catch (err) {
            console.error("sendAndWait error:", err);
            throw err;
        }
    }, [dm]);


    const sendEffect = useCallback(async (cmd, payload = [], type = null) => {
        try {
            const data = await dm.send(cmd, payload, type, "effect");
            return data;
        } catch (err) {
            console.error("sendAndWait error:", err);
            throw err;
        }
    }, [dm]);

    const sendAndWaitEffect = useCallback(async (cmd, payload = [], timeout = 3000, type = null) => {
        try {
            const data = await dm.sendAndWait(cmd, payload, timeout, type, "effect");
            return data;
        } catch (err) {
            console.error("sendAndWait error:", err);
            throw err;
        }
    }, [dm]);



    const loadEffectList = useCallback(async () => {
        if (!connected) return;

        // ===== 1️⃣ LOAD LIST =====
        const res = await sendAndWaitEffect(0x80, [0]);
        if (!res || res.length < 7) return;

        const sum = res[1];
        let offset = 2;

        const ids = [];
        const effects = [];

        // ===== READ ID =====
        for (let i = 0; i < sum; i++) {
            const id = res[offset] | (res[offset + 1] << 8);
            ids.push(id);
            offset += 2;
        }

        // ===== READ GROUP =====
        for (let i = 0; i < sum; i++) {
            const group = res[offset++];
            const type = getEffectType(ids[i]);
            if (type === "SILENCE_DETECTOR") continue;
            effects.push({
                index: i + 1,
                cmdIndex: 0x81 + i,
                id: ids[i],
                hex: ids[i].toString(16).padStart(4, "0"),
                type,
                name: "",
                group,
            });
        }

        await new Promise((r) => setTimeout(r, 3));

        for (let i = 0; i < effects.length; i++) {
            const eff = effects[i];
            try {
                const nameRes = await sendAndWaitEffect(0x80, [eff.index]);
                if (!nameRes || nameRes.length < 3) continue;
                const len = nameRes[1];
                const nameBytes = nameRes.slice(2, 2 + len - 1);
                const name = new TextDecoder().decode(
                    new Uint8Array(nameBytes)
                );
                eff.name = name;

                await new Promise((r) => setTimeout(r, 3));


            } catch (err) {
                console.warn("Load name fail:", eff.index);
            }
        }

        // ===== FINAL =====
        setAll_Effect(effects);
        console.log("Effect list:", effects);

    }, [connected, sendAndWaitEffect]);



    return {
        effect_list,
        loadEffectList,
        sendAndWait,
        sendEffect,
        sendAndWaitEffect
    };
}

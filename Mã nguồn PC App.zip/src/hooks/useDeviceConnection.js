import { useCallback } from "react";
import { DeviceManager } from "@core/DeviceManager";
import { useDeviceStore } from "@store/useDeviceStore";

export function useDeviceConnection() {
    const dm = DeviceManager.getInstance();

    const mode = useDeviceStore((s) => s.mode);
    const connected = useDeviceStore((s) => s.connected);
    const connecting = useDeviceStore((s) => s.connecting);

    const setMode = useDeviceStore((s) => s.setMode);
    const setConnected = useDeviceStore((s) => s.setConnected);
    const setConnecting = useDeviceStore((s) => s.setConnecting);

    // CONNECT
    const connect = useCallback(async (type) => {
        setConnecting(true);
        setMode(type);
        try {
            const ok = await dm.connect(type);
            if (type == "hid") {
                setConnected(ok);
            }
            return ok;
        } finally {
            setConnecting(false);
        }
    }, [dm]);

    // DISCONNECT
    const disconnect = useCallback((type = null) => {
        if (type) dm.disconnect(type);
        else dm.disconnectAll();

        setConnected(false);
        setMode("none");
    }, [dm]);

    const sendAndWait = useCallback(
        (cmd, payload = [], timeout = 3000, type = null) =>
            dm.sendAndWait(cmd, payload, timeout, type),
        [dm]
    );


    return {
        mode,
        connected,
        connecting,
        connect,
        disconnect,
        sendAndWait
    };
}

import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";

import Home from "@src/home/Home";
import CaiDat from "@src/caidat/CaiDat";
import KetNoi from "@src/Ketnoi";

import { useDeviceStore } from "@store/useDeviceStore";

export default function App() {
  const { connected } = useDeviceStore();

  return (
    <>
      <KetNoi />

      {connected && (
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/index.html" element={<Home />} />
            <Route path="/caidat" element={<CaiDat />} />
          </Routes>
        </BrowserRouter>
      )}
    </>
  );
}

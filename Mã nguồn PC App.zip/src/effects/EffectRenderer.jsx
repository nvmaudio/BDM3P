import React from "react";

import Gain from "./GAIN/Gain";
import EQ from "./EQ/EQ";

import EQ1 from "./Preamp/EQ";

import DYNAMIC_EQ from "./DYNAMIC_EQ/DYNAMIC_EQ";
import DRC from "./DRC/DRC";
import EXPANDER from "./EXPANDER/EXPANDER";
import COMPANDER from "./COMPANDER/COMPANDER";
import VIRTUAL_BASS from "./VIRTUAL_BASS/VIRTUAL_BASS";
import VIRTUAL_BASS_CLASSIC from "./VIRTUAL_BASS_CLASSIC/VIRTUAL_BASS_CLASSIC";
import THREE_D from "./THREE_D/THREE_D";
import EXCITER from "./EXCITER/EXCITER";
import STEREO_WIDENER from "./STEREO_WIDENER/STEREO_WIDENER";

import PHASE_CONTROL from "./PHASE_CONTROL/PHASE_CONTROL";
import PCM_DELAY from "./PCM_DELAY/PCM_DELAY";

import Gain_dac0 from "./Gain_dac0/Gain_dac0";

export default function EffectRenderer({ effect_data }) {
  if (!effect_data) return null;

  const { cmdIndex: index, type, name } = effect_data;

  switch (type) {
    case "GAIN_CONTROL":
      return <Gain index={index} name={name} />;

    case "Gain_dac0":
      return <Gain_dac0 index={index} name={name} />;

    case "EQ":
      return <EQ index={index} name={name} />;

    case "EQ1":
      return <EQ1 index={index} name={name} />;

    case "DYNAMIC_EQ":
      return <DYNAMIC_EQ index={index} name={name} />;

    case "EXPANDER":
      return <EXPANDER index={index} name={name} />;

    case "COMPANDER":
      return <COMPANDER index={index} name={name} />;

    case "VIRTUAL_BASS":
      return <VIRTUAL_BASS index={index} name={name} />;

    case "VIRTUAL_BASS_CLASSIC":
      return <VIRTUAL_BASS_CLASSIC index={index} name={name} />;

    case "THREE_D":
      return <THREE_D index={index} name={name} />;

    case "EXCITER":
      return <EXCITER index={index} name={name} />;

    case "STEREO_WIDENER":
      return <STEREO_WIDENER index={index} name={name} />;

    case "PHASE_CONTROL":
      return <PHASE_CONTROL index={index} name={name} />;

    case "PCM_DELAY":
      return <PCM_DELAY index={index} name={name} />;

    case "DRC":
      return <DRC index={index} name={name} />;

    default:
      return (
        <div className="p-3 border rounded-xl bg-gray-100">
          Unsupported effect: {type}
        </div>
      );
  }
}

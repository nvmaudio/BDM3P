import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";


// ======================================================
// ===================== PARSE ===========================
// ======================================================
export function parseEQ(index, buf) {
    const view = new DataView(buf.buffer);

    const enable = Boolean(buf[1]);

    let offset = 3;

    const pregainRaw = view.getInt16(offset, true);
    offset += 2;

    const calculation_type = view.getUint16(offset, true);
    offset += 2;

    const filters = [];

    for (let i = 0; i < 10; i++) {
        const enableF = view.getUint16(offset, true); offset += 2;
        const type = view.getInt16(offset, true); offset += 2;
        const f0 = view.getUint16(offset, true); offset += 2;
        const Qraw = view.getInt16(offset, true); offset += 2;
        const gainRaw = view.getInt16(offset, true); offset += 2;

        filters.push({
            enable: enableF,
            type,
            f0,

            Q_raw: Qraw,
            Q: Qraw / 1024,

            gain_raw: gainRaw,
            gain: gainRaw / 256,
        });
    }

    return {
        index,
        enable,

        pregain_raw: pregainRaw,
        pregain: pregainRaw / 256,

        calculation_type,

        filters,

        raw: Array.from(buf),
    };
}


// ======================================================
// ================= FULL PAYLOAD ========================
// ======================================================

export function buildEQPayload(p = {}) {
    const buf = new Uint8Array(107);
    const view = new DataView(buf.buffer);

    buf[0] = 0xff;

    // ===== ENABLE (uint16) =====
    buf[1] = p.enable ? 1 : 0;
    buf[2] = 0x00;

    let offset = 3;

    // ===== PREGAIN (int16) =====
    view.setInt16(offset, p.pregain_raw ?? 0, true);
    offset += 2;

    // ===== CALC TYPE (uint16) =====
    view.setUint16(offset, p.calculation_type ?? 0, true);
    offset += 2;

    // ===== FILTERS =====
    const filters = Array.isArray(p.filters) ? p.filters : [];

    for (let i = 0; i < 10; i++) {
        const f = filters[i] || {};

        view.setUint16(offset, f.enable ?? 0, true); offset += 2;
        view.setInt16(offset, f.type ?? 0, true); offset += 2;
        view.setUint16(offset, f.f0 ?? 0, true); offset += 2;
        view.setInt16(offset, f.Q_raw ?? 0, true); offset += 2;
        view.setInt16(offset, f.gain_raw ?? 0, true); offset += 2;
    }

    return buf;
}


// ======================================================
// ============ SINGLE FIELD PAYLOAD (3B) ================
// ======================================================
function buildEQSinglePayload(cmd, value) {
    const buf = new Uint8Array(3);
    buf[0] = cmd;
    const view = new DataView(buf.buffer);
    view.setInt16(1, value, true);
    return buf;
}


// ======================================================
// ====================== HOOK ===========================
// ======================================================
export function useEQ(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore((s) => s.effect_params[index]);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);
    const clearEffectParams = useEffectStore((s) => s.clearEffectParams);


    // ==================================================
    // ================= LOAD ===========================
    // ==================================================

    const loadEQ = useCallback(
        async () => {
            if (params) return params;

            const res = await sendAndWaitEffect(index);
            if (!res || res.length < 107) return null;

            const parsed = parseEQ(index, res);
            setEffectParams(index, parsed);

            return parsed;
        },
        [index, params, sendAndWaitEffect, setEffectParams]
    );


    // ==================================================
    // ================= ENABLE =========================
    // ==================================================
    const setEQEnable = useCallback(
        async (enable) => {
            const cur = await loadEQ();
            if (!cur) return;

            const payload = buildEQPayload({ ...cur, enable });
            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                enable,
            });
        },
        [index, loadEQ, sendEffect, setEffectParams]
    );


    // ==================================================
    // ================= PREGAIN ========================
    // ==================================================
    const setPregain = useCallback(
        async (pregainDb) => {
            const cur = await loadEQ();
            if (!cur) return;

            const pregain_raw = Math.round(pregainDb * 256);

            const payload = buildEQPayload({
                ...cur,
                pregain: pregainDb,
                pregain_raw,
            });

            sendEffect(index, payload);
            setEffectParams(index, next);
        },
        [index, loadEQ, sendEffect, setEffectParams]
    );


    // ==================================================
    // ============ FULL FILTER UPDATE ==================
    // ==================================================
    const setFilterParam = useCallback(
        async (band, field, value) => {
            const cur = await loadEQ();
            if (!cur) return;

            const filters = [...cur.filters];
            const f = { ...filters[band] };

            if (field === "gain") {
                f.gain = value;
                f.gain_raw = Math.round(value * 256);
            }

            if (field === "Q") {
                f.Q = value;
                f.Q_raw = Math.round(value * 1024);
            }

            if (field === "f0") {
                f.f0 = value;
            }

            if (field === "type") {
                f.type = value;
            }

            if (field === "enable") {
                f.enable = value ? 1 : 0;
            }

            filters[band] = f;

            const next = {
                ...cur,
                filters,
            };

            const payload = buildEQPayload(next);
            sendEffect(index, payload);
            setEffectParams(index, next);
        },
        [index, loadEQ, sendEffect, setEffectParams]
    );


    // ==================================================
    // ============ REALTIME SINGLE FIELD ================
    // ==================================================
    const setFilterFieldFast = useCallback(
        async (band, field, value) => {
            const cur = await loadEQ();
            if (!cur) return;

            const fieldMap = {
                enable: 0,
                type: 1,
                f0: 2,
                Q: 3,
                gain: 4,
            };

            const fieldIndex = fieldMap[field];
            if (fieldIndex === undefined) return;

            const cmd = 3 + band * 5 + fieldIndex;

            let raw = value;

            if (field === "enable") raw = value ? 1 : 0;
            if (field === "gain") raw = Math.round(value * 256);
            if (field === "Q") raw = Math.round(value * 1024);

            const payload = buildEQSinglePayload(cmd, raw);
            sendEffect(index, payload);

            // update store local
            const filters = [...cur.filters];
            const f = { ...filters[band] };

            if (field === "gain") {
                f.gain = value;
                f.gain_raw = raw;
            } else if (field === "Q") {
                f.Q = value;
                f.Q_raw = raw;
            } else if (field === "enable") {
                f.enable = raw;
            } else {
                f[field] = value;
            }

            filters[band] = f;

            setEffectParams(index, {
                ...cur,
                filters,
            });
        },
        [index, loadEQ, sendEffect, setEffectParams]
    );


    // ==================================================
    // ================= RETURN =========================
    // ==================================================
    return {
        data: params,
        loadEQ,
        setEQEnable,
        setPregain,
        setFilterParam,       // full struct
        setFilterFieldFast,  // realtime 3B,
        clearEffectParams
    };
}

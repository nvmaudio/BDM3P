import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

/* ================= PARSE ================= */
export function parsePhase(index, buf) {
    const readU16 = (lo, hi) => lo | (hi << 8);

    const enable = buf[1] === 1;
    const phase = readU16(buf[3], buf[4]); // 0 = normal, 1 = invert

    return {
        index,
        enable,
        phase,
        raw: Array.from(buf),
    };
}

/* ================= BUILD PAYLOAD ================= */
export function buildPhaseControlPayload({ enable, phase }) {
    const buf = new Uint8Array(5);

    buf[0] = 0xff;

    // enable u16
    buf[1] = enable ? 1 : 0;
    buf[2] = 0;

    if (phase > 1) phase = 0;
    if (phase < 0) phase = 0;

    // phase u16
    buf[3] = phase & 0xff;
    buf[4] = (phase >> 8) & 0xff;

    return buf;
}

/* ================= HOOK ================= */
export function usePHASE_CONTROL(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore((s) => s.effect_params[index]);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);

    /* LOAD */
    const loadPhase = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res || res.length < 5) return null;

        const parsed = parsePhase(index, res);
        setEffectParams(index, parsed);
        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);

    /* ENABLE */
    const setEnable = useCallback(
        async (enable) => {
            const cur = await loadPhase();

            const payload = buildPhaseControlPayload({
                ...cur,
                enable,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                enable,
            });
        },
        [index, loadPhase, sendEffect, setEffectParams]
    );

    /* PHASE */
    const setPhase = useCallback(
        async (value) => {
            const cur = await loadPhase();

            const payload = buildPhaseControlPayload({
                ...cur,
                phase: value,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                phase: value,
            });
        },
        [index, loadPhase, sendEffect, setEffectParams]
    );

    return {
        data: params,
        loadPhase,
        setEnable,
        setPhase,
    };
}

import { useEffect, useState, useMemo, useRef, useCallback } from "react";
import { useEQ } from "./useEQ";
import EQGraph from "./EQGraph";

/* ================= FILTER TYPES ================= */

export const EQ_FILTER_TYPES = [
  { label: "PK (Peaking / Bell)", value: 0 },
  { label: "LS (Low Shelf)", value: 1 },
  { label: "HS (High Shelf)", value: 2 },
  { label: "LPF (Low Pass Filter)", value: 3 },
  { label: "HPF (High Pass Filter)", value: 4 },
  { label: "BPF (Band Pass Filter)", value: 5 },
  { label: "NOTCH (Band Stop Filter)", value: 6 },
];

/* ================= COMPONENT ================= */

export default function EQ({ index, name }) {
  const {
    data,
    loadEQ,
    setEQEnable,
    setPregain,
    setFilterParam,
    setFilterFieldFast,
  } = useEQ(index);

  const [draft, setDraft] = useState(null);
  const [open, setOpen] = useState(false);

  const loadedRef = useRef(false);
  const pregainDebounce = useRef(null);
  const fastSendRef = useRef({});

  /* ===== LOAD ===== */

  useEffect(() => {
    if (!data) loadEQ();
  }, [data, loadEQ]);

  /* ===== DEVICE → DRAFT ===== */

  useEffect(() => {
    if (data && !loadedRef.current) {
      setDraft(JSON.parse(JSON.stringify(data)));
      loadedRef.current = true;
    }
  }, [data]);

  const enable = draft?.enable ?? false;

  /* ================= POWER ================= */

  const togglePower = async (e) => {
    e.stopPropagation();
    await setEQEnable(!enable);

    setDraft((d) => ({
      ...d,
      enable: !enable,
    }));
  };

  /* ================= PREGAIN ================= */

  const updatePregain = (v) => {
    setDraft((d) => ({ ...d, pregain: v }));

    clearTimeout(pregainDebounce.current);
    pregainDebounce.current = setTimeout(() => {
      setPregain(v);
    }, 120);
  };

  /* ================= FILTER ================= */

  const throttleFastSend = (band, field, value) => {
    if (!fastSendRef.current[band]) {
      fastSendRef.current[band] = {};
    }

    clearTimeout(fastSendRef.current[band][field]);

    fastSendRef.current[band][field] = setTimeout(() => {
      setFilterFieldFast(band, field, value);
    }, 250);
  };

  const updateFilter = (band, field, value) => {
    if (field === "f0") {
      value = Math.max(20, Math.min(20000, value));
    }

    if (field === "gain") {
      value = Math.max(-12, Math.min(12, value));
    }

    const round3 = (v) => Math.round(v * 1000) / 1000;

    if (field === "Q") {
      value = Math.max(0.01, Math.min(10, value));
      value = round3(value);
    }

    setDraft((d) => {
      const copy = { ...d };
      copy.filters = [...copy.filters];

      const f = {
        ...copy.filters[band],
        [field]: value,
      };

      copy.filters[band] = f;

      /* ===== AUTO INIT WHEN ENABLE ===== */

      if (field === "enable") {
        if (value === true) {
          if (copy.filters[band].f0 === 0) {
            const prev = copy.filters[band - 1];
            const baseFreq = prev ? prev.f0 : 1000;

            f.f0 = Math.min(baseFreq + 1000, 20000);
            f.gain = 0;
            f.Q = 0.707;
            f.type = 0;
          }

          throttleFastSend(band, "enable", value);
          throttleFastSend(band, "f0", f.f0);
          throttleFastSend(band, "gain", f.gain);
          throttleFastSend(band, "Q", f.Q);
          throttleFastSend(band, "type", f.type);
        }
      }

      /* ===== REALTIME ===== */

      if (field === "gain" || field === "Q" || field === "f0") {
        throttleFastSend(band, field, value);
      }

      if (field === "type") {
        throttleFastSend(band, field, value);
      }

      return copy;
    });
  };

  /* ================= ACTIVE FILTERS ================= */

  const activeFilters = useMemo(() => {
    if (!draft) return [];

    return draft.filters
      .map((f, i) => ({ ...f, band: i }))
      .filter((f) => f.enable);
  }, [draft]);

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  if (!draft) {
    return <div className="p-3 text-sm text-gray-400">Loading EQ...</div>;
  }

  /* ================= UI ================= */

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* ===== HEADER ===== */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}`}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div
          className={`text-gray-500 transition-transform
            ${open ? "rotate-180" : ""}`}
        >
          ▾
        </div>
      </div>

      {/* ===== BODY ===== */}
      {open && (
        <div className={`p-3 space-y-3 ${!enable && "opacity-60"}`}>
          {/* ===== GRAPH ===== */}
          <div className="w-full bg-[#0f2a35] p-2 rounded-xl">
            <EQGraph
              filters={activeFilters}
              pregain={draft.pregain}
              onDrag={(band, v) => {
                if (v.f0 !== undefined) updateFilter(band, "f0", v.f0);
                if (v.gain !== undefined) updateFilter(band, "gain", v.gain);
              }}
            />
          </div>

          {/* ===== PREGAIN ===== */}
          <div className="text-xs bg-gray-100 border rounded-xl p-3">
            <div className="font-semibold mb-2">Pre-Gain</div>

            <div className="flex items-center gap-3">
              <input
                type="range"
                min={-96}
                max={18}
                step={0.1}
                value={draft.pregain}
                onChange={(e) => updatePregain(Number(e.target.value))}
                className="flex-1"
              />

              <div className="text-center rounded py-1">
                <InlineInput
                  value={draft.pregain}
                  min={-60}
                  max={12}
                  step={0.1}
                  enable={enable}
                  title="Range: -60 → 12 dB. Mức Gain đầu Vào."
                  format={(v) => v.toFixed(2)}
                  onChange={(v) => updatePregain(v)}
                  className="w-[80px] text-right font-semibold px-2 py-1 rounded-lg outline-none border border-gray-200"
                />
                {" dB"}
                
              </div>
            </div>
          </div>

          {/* ===== FILTER ENABLE ===== */}
          <div className="bg-gray-100 border rounded-xl p-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="text-xs font-semibold">Filters</div>

              {draft.filters.map((f, i) => (
                <button
                  key={i}
                  onClick={() => updateFilter(i, "enable", !f.enable)}
                  className={`px-2 py-1 text-xs rounded-lg border transition
                    ${f.enable ? "bg-blue-500 text-white" : "bg-gray-200"}`}
                >
                  F{i}
                </button>
              ))}
            </div>
          </div>

          {/* ===== TABLE ===== */}
          <div className="border rounded-xl overflow-hidden">
            <div className="grid grid-cols-5 bg-gray-50 text-xs px-3 py-1">
              <div>Band</div>
              <div>Type</div>
              <div>Fc</div>
              <div>Gain</div>
              <div>Q</div>
            </div>

            {draft.filters
              .map((f, i) => ({ ...f, band: i }))
              .filter((f) => f.enable)
              .map((f) => (
                <div
                  key={f.band}
                  className="grid grid-cols-5 items-center border-t bg-gray-50 px-3 py-2 gap-2"
                >
                  <div>F{f.band}</div>

                  <select
                    value={f.type}
                    onChange={(e) =>
                      updateFilter(f.band, "type", Number(e.target.value))
                    }
                    className="bg-gray-200 border rounded px-2"
                    title="Chọn loại Filter"
                  >
                    {EQ_FILTER_TYPES.map((t) => (
                      <option key={t.value} value={t.value}>
                        {t.label}
                      </option>
                    ))}
                  </select>

                  <InlineInput
                    value={f.f0}
                    min={20}
                    max={20000}
                    step={1}
                    title="Range: 20 → 20000 Hz. Tần số trung tâm của filter."
                    onChange={(v) => updateFilter(f.band, "f0", v)}
                    className="bg-gray-200 border rounded px-2"
                  />

                  <InlineInput
                    value={f.gain}
                    min={-12}
                    max={12}
                    step={0.1}
                    title="Range: -12 → 12 dB."
                    format={(v) => v.toFixed(2)}
                    onChange={(v) => updateFilter(f.band, "gain", v)}
                    className="bg-gray-200 border rounded px-2"
                  />

                  <InlineInput
                    value={f.Q}
                    min={0.01}
                    max={10}
                    step={0.01}
                    title="Range: 0.01 → 10. Độ rộng băng tần."
                    format={(v) => v.toFixed(3)}
                    onChange={(v) => updateFilter(f.band, "Q", v)}
                    className="bg-gray-200 border rounded px-2"
                  />
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= INPUT COMPONENT ================= */

function InlineInput({
  value,
  min,
  max,
  step = 1,
  title,
  enable = true,
  onChange,
  format,
  className,
}) {
  const [display, setDisplay] = useState("");
  const isEditingRef = useRef(false);

  useEffect(() => {
    if (isEditingRef.current) return;
    if (value === undefined || value === null) return;

    const formatted = format ? format(value) : value.toString();
    setDisplay(formatted);
  }, [value, format]);

  const handleChange = (e) => {
    const v = e.target.value;
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    isEditingRef.current = true;
    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    isEditingRef.current = false;

    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    const formatted = format ? format(num) : num.toString();
    setDisplay(formatted);
    onChange(num);
  };

  return (
    <input
      type="text"
      inputMode="decimal"
      value={display}
      step={step}
      title={title}
      disabled={!enable}
      onChange={handleChange}
      onBlur={handleBlur}
      className={className}
    />
  );
}

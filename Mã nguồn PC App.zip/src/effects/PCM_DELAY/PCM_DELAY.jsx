import { useEffect, useState, useCallback } from "react";
import { usePCM_DELAY } from "./usePCM_DELAY";

export default function PCM_DELAY({ index, name }) {
  const { data, loadDelay, setEnable, setDelay, setMaxDelay, setHQ } =
    usePCM_DELAY(index);

  const [local, setLocal] = useState({
    delay: 0,
    max_delay: 3000,
    high_quality: 0,
  });

  const [open, setOpen] = useState(false);

  /* LOAD */
  useEffect(() => {
    if (!data) loadDelay();
  }, [data, loadDelay]);

  /* SYNC */
  useEffect(() => {
    if (data) {
      setLocal({
        delay: data.delay,
        max_delay: data.max_delay,
        high_quality: data.high_quality,
      });
    }
  }, [data]);

  const enable = data?.enable ?? false;

  /* POWER */
  const togglePower = async (e) => {
    e.stopPropagation();
    await setEnable(!enable);
  };

  /* ================= UPDATE LOGIC ================= */

  const updateDelay = useCallback(
    (v) => {
      setLocal((prev) => {
        let value = Math.max(0, Math.min(v, prev.max_delay));
        setDelay(value);
        return { ...prev, delay: value };
      });
    },
    [setDelay],
  );

  const updateMax = useCallback(
    (v) => {
      setLocal((prev) => {
        const limit = prev.high_quality ? 1000 : 3000;
        let newMax = Math.min(v, limit);
        let newDelay = Math.min(prev.delay, newMax);

        setMaxDelay(newMax);
        if (newDelay !== prev.delay) setDelay(newDelay);

        return {
          ...prev,
          max_delay: newMax,
          delay: newDelay,
        };
      });
    },
    [setMaxDelay, setDelay],
  );

  const toggleHQ = () => {
    setLocal((prev) => {
      const newHQ = prev.high_quality ? 0 : 1;
      const limit = newHQ ? 1000 : 3000;

      let newMax = Math.min(prev.max_delay, limit);
      let newDelay = Math.min(prev.delay, newMax);

      setHQ(newHQ);
      setMaxDelay(newMax);
      if (newDelay !== prev.delay) setDelay(newDelay);

      return {
        delay: newDelay,
        max_delay: newMax,
        high_quality: newHQ,
      };
    });
  };

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  /* ================= UI ================= */
  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer select-none"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
            ${enable ? "bg-blue-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
              ${enable ? "translate-x-4" : "translate-x-1"}`}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`transition-transform ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className="px-4 py-4">
          <div
            className={`
              ${!enable && "opacity-50"}
              flex flex-col sm:flex-row sm:flex-wrap gap-4 sm:gap-6
            `}
          >
            <Inline
              label="Delay"
              value={local.delay}
              unit="ms"
              min={1}
              max={local.max_delay}
              title="Range: 1 → max_delay dB. Dùng để làm trễ pha sub"
              enable={enable}
              onChange={updateDelay}
            />

            <Inline
              label="Max Delay"
              value={local.max_delay}
              unit="ms"
              min={10}
              max={local.high_quality ? 1000 : 3000}
              title="Range: 10 → max_delay dB. khai báo max delay, cần tắt efect để cập nhật lại!"
              enable={enable}
              onChange={updateMax}
            />

            {/* HQ */}
            <div
              className="flex items-center gap-3"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-sm w-[90px] text-right">HQ</div>

              <button
                disabled={!enable}
                onClick={toggleHQ}
                className={`w-10 h-5 rounded-full transition relative
                ${local.high_quality ? "bg-blue-500" : "bg-gray-300"}`}
              >
                <div
                  className={`w-4 h-4 bg-white rounded-full shadow absolute top-[2px] transition
                  ${local.high_quality ? "left-5" : "left-1"}`}
                />
              </button>

              <div className="text-xs text-gray-500">
                {local.high_quality ? "HQ" : "Normal"}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= INLINE WITH INTERMEDIATE INPUT ================= */
function Inline({
  label,
  value,
  unit,
  min,
  max,
  step = 1,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  /* Sync external value */
  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    // only allow number format
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div
      className="flex items-center gap-2 w-full sm:w-auto"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="text-sm w-[90px] text-right shrink-0">{label}</div>

      <input
        type="text"
        value={display}
        step={step}
        disabled={!enable}
        title={title}
        onChange={handleChange}
        onBlur={handleBlur}
        className="w-[90px] px-2 py-1 text-sm text-white font-medium text-center rounded-md bg-gradient-to-b from-[#112e3a] to-[#113a0a] border border-[#4e6a75] outline-none focus:ring-2 focus:ring-blue-400"
      />

      <div className="text-sm w-[40px] shrink-0">{unit}</div>
    </div>
  );
}

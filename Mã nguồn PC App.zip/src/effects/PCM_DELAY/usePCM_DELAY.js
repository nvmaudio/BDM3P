import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

/* ================= PARSE ================= */
export function parseDelay(index, buf) {
    const readS16 = (lo, hi) => {
        let v = lo | (hi << 8);
        if (v & 0x8000) v -= 0x10000;
        return v;
    };

    const enable = buf[1] === 1;

    const delay = readS16(buf[3], buf[4]);
    const max_delay = readS16(buf[5], buf[6]);
    const high_quality = readS16(buf[7], buf[8]);

    return {
        index,
        enable,
        delay,
        max_delay,
        high_quality,
        raw: Array.from(buf),
    };
}

/* ================= BUILD ================= */
export function buildPCMDelayPayload({ enable, delay, max_delay, high_quality }) {
    const buf = new Uint8Array(9);

    buf[0] = 0xff;

    // enable u16
    buf[1] = enable ? 1 : 0;
    buf[2] = 0;

    const writeS16 = (offset, v) => {
        if (v < 0) v = 0;
        buf[offset] = v & 0xff;
        buf[offset + 1] = (v >> 8) & 0xff;
    };

    // clamp theo firmware
    if (high_quality) {
        if (max_delay > 1000) max_delay = 1000;
    } else {
        if (max_delay > 3000) max_delay = 3000;
    }

    if (delay > max_delay) delay = max_delay;
    if (delay < 0) delay = 0;

    writeS16(3, delay);
    writeS16(5, max_delay);
    writeS16(7, high_quality ? 1 : 0);

    return buf;
}

/* ================= HOOK ================= */
export function usePCM_DELAY(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore((s) => s.effect_params[index]);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);

    /* LOAD */
    const loadDelay = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res || res.length < 9) return null;

        const parsed = parseDelay(index, res);
        setEffectParams(index, parsed);
        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);

    /* ENABLE */
    const setEnable = useCallback(
        async (enable) => {
            const cur = await loadDelay();
            if (!cur) return;

            const payload = buildPCMDelayPayload({
                ...cur,
                enable,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                enable,
            });
        },
        [index, loadDelay, sendEffect, setEffectParams]
    );

    /* DELAY */
    const setDelay = useCallback(
        async (value) => {
            const cur = await loadDelay();
            if (!cur) return;

            const payload = buildPCMDelayPayload({
                ...cur,
                delay: value,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                delay: value,
            });
        },
        [index, loadDelay, sendEffect, setEffectParams]
    );

    /* MAX DELAY */
    const setMaxDelay = useCallback(
        async (value) => {
            const cur = await loadDelay();
            if (!cur) return;

            const payload = buildPCMDelayPayload({
                ...cur,
                max_delay: value,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                max_delay: value,
            });
        },
        [index, loadDelay, sendEffect, setEffectParams]
    );

    /* HQ */
    const setHQ = useCallback(
        async (value) => {
            const cur = await loadDelay();
            if (!cur) return;

            const payload = buildPCMDelayPayload({
                ...cur,
                high_quality: value ? 1 : 0,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                high_quality: value ? 1 : 0,
            });
        },
        [index, loadDelay, sendEffect, setEffectParams]
    );

    return {
        data: params,
        loadDelay,
        setEnable,
        setDelay,
        setMaxDelay,
        setHQ,
    };
}

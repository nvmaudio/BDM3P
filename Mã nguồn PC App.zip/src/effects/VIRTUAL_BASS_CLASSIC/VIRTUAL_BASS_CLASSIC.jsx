import { useEffect, useState, useCallback } from "react";
import { useVIRTUAL_BASS_CLASSIC } from "./useVIRTUAL_BASS_CLASSIC";

export default function VIRTUAL_BASS_CLASSIC({ index, name }) {
  const { data, loadVBClassic, setEnable, setFCut, setIntensity } =
    useVIRTUAL_BASS_CLASSIC(index);

  const [local, setLocal] = useState({
    f_cut: 120,
    intensity: 50,
  });

  const [open, setOpen] = useState(false);

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) loadVBClassic();
  }, [data, loadVBClassic]);

  /* ================= SYNC ================= */
  useEffect(() => {
    if (data) {
      setLocal({
        f_cut: data.f_cut,
        intensity: data.intensity,
      });
    }
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = async (e) => {
    e.stopPropagation();
    await setEnable(!enable);
  };

  /* ================= UPDATE ================= */
  const update = useCallback(
    (field, v) => {
      setLocal((prev) => {
        let value = v;

        if (field === "f_cut") {
          value = Math.max(30, Math.min(300, v));
          setFCut(value);
        }

        if (field === "intensity") {
          value = Math.max(0, Math.min(100, v));
          setIntensity(value);
        }

        return { ...prev, [field]: value };
      });
    },
    [setFCut, setIntensity],
  );

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* ================= HEADER ================= */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer select-none"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
            ${enable ? "bg-blue-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
              ${enable ? "translate-x-4" : "translate-x-1"}`}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`transition-transform ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* ================= BODY ================= */}
      {open && (
        <div className="px-4 py-4">
          <div
            className={`
              ${!enable && "opacity-50"}
              flex flex-col sm:flex-row sm:flex-wrap gap-4 sm:gap-6
            `}
          >
            <InlineInput
              label="Cutoff"
              value={local.f_cut}
              min={30}
              max={300}
              unit="Hz"
              enable={enable}
              onChange={(v) => update("f_cut", v)}
            />

            <InlineInput
              label="Intensity"
              value={local.intensity}
              min={0}
              max={100}
              unit="%"
              enable={enable}
              onChange={(v) => update("intensity", v)}
            />
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= INLINE INPUT (DISPLAY STATE) ================= */
function InlineInput({
  label,
  value,
  min,
  max,
  unit,
  enable = true,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  /* Sync external value */
  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div
      className="flex items-center gap-2 w-full sm:w-auto"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="text-sm w-[80px] text-right shrink-0">{label}</div>

      <input
        type="text"
        value={display}
        disabled={!enable}
        onChange={handleChange}
        onBlur={handleBlur}
        className="
          w-[90px]
          px-2 py-[2px]
          text-sm
          text-white
          text-center
          rounded-md
          bg-gradient-to-b from-[#657a42] to-[#0e0e3c]
          border border-[#4e6a75]
          outline-none
          focus:ring-2 focus:ring-blue-400
        "
      />

      <div className="text-sm w-[40px] shrink-0">{unit}</div>
    </div>
  );
}

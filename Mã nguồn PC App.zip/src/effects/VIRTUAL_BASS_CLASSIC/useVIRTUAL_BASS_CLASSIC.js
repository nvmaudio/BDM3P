import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

// ===== parse =====
export   function parseVBClassic(index, buf) {
    const readS16 = (lo, hi) => {
        let v = lo | (hi << 8);
        if (v & 0x8000) v -= 0x10000;
        return v;
    };

    const enable = buf[1] === 1;

    const f_cut = readS16(buf[3], buf[4]);
    const intensity = readS16(buf[5], buf[6]);

    return {
        index,
        enable,
        f_cut,
        intensity,
        raw: Array.from(buf),
    };
}

// ===== build =====
export function buildVirtualBassClassicPayload({
    enable,
    f_cut,
    intensity,
}) {
    const clamp = (v, min, max) =>
        Math.max(min, Math.min(max, v));

    f_cut = clamp(f_cut, 30, 300);
    intensity = clamp(intensity, 0, 100);

    const buf = new Uint8Array(7);
    buf[0] = 0xff;

    // enable u16
    buf[1] = enable ? 1 : 0;
    buf[2] = 0;

    const writeS16 = (v, off) => {
        if (v < 0) v += 0x10000;
        buf[off] = v & 0xff;
        buf[off + 1] = (v >> 8) & 0xff;
    };

    writeS16(f_cut, 3);
    writeS16(intensity, 5);

    return buf;
}

// ===== hook =====
export function useVIRTUAL_BASS_CLASSIC(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore(
        (s) => s.effect_params[index]
    );

    const setEffectParams =
        useEffectStore((s) => s.setEffectParams);

    // LOAD
    const loadVBClassic = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res || res.length < 7) return null;

        const parsed = parseVBClassic(index, res);
        setEffectParams(index, parsed);
        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);

    // ENABLE
    const setEnable = useCallback(async (enable) => {
        const cur = await loadVBClassic();

        const payload = buildVirtualBassClassicPayload({
            ...cur,
            enable,
        });

        sendEffect(index, payload);

        setEffectParams(index, {
            ...cur,
            enable,
        });
    }, [index, loadVBClassic, sendEffect, setEffectParams]);

    // update
    const updateParam = useCallback(async (field, value) => {
        const cur = await loadVBClassic();

        const payload = buildVirtualBassClassicPayload({
            ...cur,
            [field]: value,
        });

        sendEffect(index, payload);

        setEffectParams(index, {
            ...cur,
            [field]: value,
        });
    }, [index, loadVBClassic, sendEffect, setEffectParams]);

    return {
        data: params,

        loadVBClassic,
        setEnable,

        setFCut: (v) => updateParam("f_cut", v),
        setIntensity: (v) => updateParam("intensity", v),
    };
}

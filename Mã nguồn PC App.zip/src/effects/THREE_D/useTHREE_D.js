import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

/* ================= PARSE ================= */
export  function parseThreeD(index, buf) {
    const readS16 = (lo, hi) => {
        let v = lo | (hi << 8);
        if (v & 0x8000) v -= 0x10000;
        return v;
    };

    const enable = buf[1] === 1;
    const intensity = readS16(buf[3], buf[4]);

    return {
        index,
        enable,
        intensity,
        raw: Array.from(buf),
    };
}

/* ================= BUILD ================= */
export function buildThreeDPayload({ enable, intensity }) {
    const clamp = (v, min, max) =>
        Math.max(min, Math.min(max, v));

    intensity = clamp(intensity ?? 0, 0, 100);

    const buf = new Uint8Array(5);

    buf[0] = 0xff;

    // enable u16
    buf[1] = enable ? 1 : 0;
    buf[2] = 0;

    // intensity s16
    let v = intensity;
    if (v < 0) v += 0x10000;

    buf[3] = v & 0xff;
    buf[4] = (v >> 8) & 0xff;

    return buf;
}

function buildEnable(enable) {
    const buf = new Uint8Array(3);
    buf[0] = 0;
    buf[1] = enable ? 1 : 0;
    buf[2] = 0;
    return buf;
}

function buildIntensity(v) {
    v = Math.max(0, Math.min(100, v));

    const buf = new Uint8Array(3);
    buf[0] = 1;

    if (v < 0) v += 0x10000;
    buf[1] = v & 0xff;
    buf[2] = (v >> 8) & 0xff;

    return buf;
}

/* ================= HOOK ================= */
export function useTHREE_D(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore(
        (s) => s.effect_params[index]
    );

    const setEffectParams =
        useEffectStore((s) => s.setEffectParams);

    /* LOAD */
    const load = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res || res.length < 5) return null;

        const parsed = parseThreeD(index, res);
        setEffectParams(index, parsed);
        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);

    /* ENABLE */
    const setEnable = useCallback(async (enable) => {
        const cur = await load();
        if (!cur) return;

        sendEffect(index, buildEnable(enable));

        setEffectParams(index, {
            ...cur,
            enable,
        });
    }, [index, load, sendEffect, setEffectParams]);

    /* INTENSITY */
    const setIntensity = useCallback(async (v) => {
        const cur = await load();
        if (!cur) return;

        sendEffect(index, buildIntensity(v));

        setEffectParams(index, {
            ...cur,
            intensity: v,
        });
    }, [index, load, sendEffect, setEffectParams]);

    /* FULL SYNC */
    const sync = useCallback(async (obj) => {
        const cur = await load();
        if (!cur) return;

        const payload = buildThreeDPayload({
            ...cur,
            ...obj,
        });

        sendEffect(index, payload);

        setEffectParams(index, {
            ...cur,
            ...obj,
        });
    }, [index, load, sendEffect, setEffectParams]);

    return {
        data: params,
        load,

        setEnable,
        setIntensity,
        sync,
    };
}

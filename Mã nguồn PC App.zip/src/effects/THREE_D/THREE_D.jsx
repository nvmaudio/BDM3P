import { useEffect, useState, useCallback } from "react";
import { useTHREE_D } from "./useTHREE_D";

export default function THREE_D({ index, name }) {
  const { data, load, setEnable, setIntensity } = useTHREE_D(index);

  const [local, setLocal] = useState({
    intensity: 0,
  });

  const [open, setOpen] = useState(false);

  /* ================= LOAD ================= */
  useEffect(() => {
    if (!data) load();
  }, [data, load]);

  /* ================= SYNC ================= */
  useEffect(() => {
    if (data) {
      setLocal({
        intensity: data.intensity ?? 0,
      });
    }
  }, [data]);

  const enable = data?.enable ?? false;

  /* ================= POWER ================= */
  const togglePower = async (e) => {
    e.stopPropagation();
    await setEnable(!enable);
  };

  /* ================= UPDATE ================= */
  const updateIntensity = useCallback(
    (v) => {
      let value = Math.max(0, Math.min(100, v));
      setLocal((s) => ({ ...s, intensity: value }));
      setIntensity(value);
    },
    [setIntensity],
  );

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* ================= HEADER ================= */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer select-none"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          {/* POWER */}
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
            ${enable ? "bg-blue-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
              ${enable ? "translate-x-4" : "translate-x-1"}`}
            />
          </button>

          {/* TITLE */}
          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        {/* ARROW */}
        <div className={`transition-transform ${open ? "rotate-180" : ""}`}>
          ▾
        </div>
      </div>

      {/* ================= BODY ================= */}
      {open && (
        <div className="px-4 py-4">
          <div
            className={`
              ${!enable && "opacity-50"}
              flex flex-col sm:flex-row gap-6
            `}
          >
            <Inline
              label="Intensity"
              value={local.intensity}
              min={0}
              max={100}
              enable={enable}
              onChange={updateIntensity}
            />
            {" %"}
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= INLINE WITH INTERMEDIATE INPUT ================= */
function Inline({ label, value, min, max, enable, onChange }) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  /* Sync ngoài vào */
  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div
      className="flex items-center gap-2 w-full sm:w-auto"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="text-sm w-[70px] text-right shrink-0">{label}</div>

      <input
        type="text"
        value={display}
        disabled={!enable}
        onChange={handleChange}
        onBlur={handleBlur}
        className="
        w-[90px] px-2 py-[2px] text-sm text-white text-center rounded-md
        bg-gradient-to-b from-[#b92145] to-[#141516]
        border border-[#4e6a75] outline-none
        focus:ring-2 focus:ring-blue-400"
      />
    </div>
  );
}

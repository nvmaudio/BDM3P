import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";


// ================= PARSE =================
export   function parseVB(index, buf) {
    const readS16 = (lo, hi) => {
        let v = lo | (hi << 8);
        if (v & 0x8000) v -= 0x10000;
        return v;
    };

    const enable = buf[1] === 1;

    const f_cut = readS16(buf[3], buf[4]);      // 30-300
    const intensity = readS16(buf[5], buf[6]);  // 0-100
    const enhanced = readS16(buf[7], buf[8]);   // 0/1

    return {
        index,
        enable,
        f_cut,
        intensity,
        enhanced,
        raw: Array.from(buf),
    };
}


// ================= BUILD =================
export function buildVirtualBassPayload({
    enable,
    f_cut,
    intensity,
    enhanced,
}) {
    const clamp = (v, min, max) =>
        Math.max(min, Math.min(max, v));

    f_cut = clamp(f_cut, 30, 300);
    intensity = clamp(intensity, 0, 100);
    enhanced = clamp(enhanced, 0, 1);

    const buf = new Uint8Array(9);
    buf[0] = 0xff;

    // enable u16
    buf[1] = enable ? 1 : 0;
    buf[2] = 0;

    const writeS16 = (v, offset) => {
        if (v < 0) v += 0x10000;
        buf[offset] = v & 0xff;
        buf[offset + 1] = (v >> 8) & 0xff;
    };

    writeS16(f_cut, 3);
    writeS16(intensity, 5);
    writeS16(enhanced, 7);

    return buf;
}


// ================= HOOK =================
export function useVIRTUAL_BASS(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore(
        (s) => s.effect_params[index]
    );

    const setEffectParams =
        useEffectStore((s) => s.setEffectParams);

    // ===== LOAD =====
    const loadVBedVB = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res || res.length < 9) return null;

        const parsed = parseVB(index, res);
        setEffectParams(index, parsed);

        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);



    // ===== ENABLE =====
    const setEnable = useCallback(async (enable) => {
        const cur = await loadVBedVB();

        const payload = buildVirtualBassPayload({
            ...cur,
            enable,
        });

        sendEffect(index, payload);

        setEffectParams(index, {
            ...cur,
            enable,
        });
    }, [index, loadVBedVB, sendEffect, setEffectParams]);



    // ===== PARAM UPDATE =====
    const updateParam = useCallback(async (field, value) => {
        const cur = await loadVBedVB();

        const payload = buildVirtualBassPayload({
            ...cur,
            [field]: value,
        });

        sendEffect(index, payload);

        setEffectParams(index, {
            ...cur,
            [field]: value,
        });
    }, [index, loadVBedVB, sendEffect, setEffectParams]);



    return {
        data: params,

        loadVBedVB,

        setEnable,
        setFCut: (v) => updateParam("f_cut", v),
        setIntensity: (v) => updateParam("intensity", v),
        setEnhanced: (v) => updateParam("enhanced", v),
    };
}

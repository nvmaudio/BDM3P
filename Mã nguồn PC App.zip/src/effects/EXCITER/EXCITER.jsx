import { useEffect, useState } from "react";
import { useEXCITER } from "./useEXCITER";

export default function EXCITER({ index, name }) {
  const { data, load, setEnable, setCutoff, setDry, setWet } =
    useEXCITER(index);

  const [local, setLocal] = useState({
    f_cut: 0,
    dry: 0,
    wet: 0,
  });

  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!data) load();
  }, [data]);

  useEffect(() => {
    if (data) {
      setLocal({
        f_cut: data.f_cut,
        dry: data.dry,
        wet: data.wet,
      });
    }
  }, [data]);

  const enable = data?.enable ?? false;

  const togglePower = async (e) => {
    e.stopPropagation();
    await setEnable(!enable);
  };

  const update = (k, v) => {
    setLocal((s) => ({ ...s, [k]: v }));

    if (k === "f_cut") setCutoff(v);
    if (k === "dry") setDry(v);
    if (k === "wet") setWet(v);
  };

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* header */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
            ${enable ? "bg-blue-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
            ${enable ? "translate-x-4" : "translate-x-1"}`}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`${open ? "rotate-180" : ""}`}>▾</div>
      </div>

      {/* body */}
      {open && (
        <div className="px-4 py-4">
          {!data && <div className="text-sm text-gray-400">Loading...</div>}

          {data && (
            <div
              className={`
              ${!enable && "opacity-50"}
              flex
              flex-wrap
              gap-6
              items-start
            `}
            >
              <Inline
                label="Cutoff"
                value={local.f_cut}
                unit="Hz"
                min={300}
                max={10000}
                step={1}
                title="Range: 300 → 10000 Hz. Tần số cắt của Exciter. Chỉ các tín hiệu trên mức này mới được thêm harmonic."
                enable={enable}
                onChange={(v) => update("f_cut", v)}
              />

              <Inline
                label="Dry"
                value={local.dry}
                unit="%"
                min={0}
                max={100}
                step={1}
                title="Range: 0 → 100%. Mức tín hiệu gốc (Dry) được trộn vào đầu ra."
                enable={enable}
                onChange={(v) => update("dry", v)}
              />

              <Inline
                label="Wet"
                value={local.wet}
                unit="%"
                min={0}
                max={100}
                step={1}
                title="Range: 0 → 100%. Mức tín hiệu đã qua xử lý được trộn vào đầu ra."
                enable={enable}
                onChange={(v) => update("wet", v)}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Inline({
  label,
  value,
  unit,
  min,
  max,
  step = 1,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  /* Sync khi value từ ngoài đổi */
  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  /* ===== HANDLE CHANGE ===== */
  const handleChange = (e) => {
    const v = e.target.value;

    // cho phép trạng thái nhập trung gian
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    // nếu đang nhập dở thì chưa emit
    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  /* ===== HANDLE BLUR ===== */
  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center gap-2">
      <div className="text-sm w-[90px] text-right">{label}</div>

      <input
        type="text"
        inputMode="decimal"
        value={display}
        step={step}
        disabled={!enable}
        title={title}
        onChange={handleChange}
        onBlur={handleBlur}
        className="
          w-[110px] px-2 py-[4px] text-sm text-white text-center rounded-md
          bg-gradient-to-b from-[#112e3a] to-[#113a0a]
          border border-[#4e6a75] outline-none
        "
      />

      <div className="text-xs w-10">{unit}</div>
    </div>
  );
}

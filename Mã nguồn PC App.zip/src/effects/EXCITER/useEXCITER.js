import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

/* ===== parse ===== */
export function parseEXCITER(index, buf) {
    const readS16 = (lo, hi) => {
        let v = lo | (hi << 8);
        if (v & 0x8000) v -= 0x10000;
        return v;
    };

    const enable = buf[1] === 1;

    const f_cut = readS16(buf[3], buf[4]);
    const dry = readS16(buf[5], buf[6]);
    const wet = readS16(buf[7], buf[8]);

    return {
        index,
        enable,
        f_cut,
        dry,
        wet,
        raw: Array.from(buf),
    };
}

/* ===== buildExciterPayload payload ===== */
export function buildExciterPayload({
    enable,
    f_cut,
    dry,
    wet,
}) {
    const clamp = (v, min, max) =>
        Math.max(min, Math.min(max, v));

    dry = clamp(dry, 0, 80);
    wet = clamp(wet, 0, 80);

    const buf = new Uint8Array(9);
    buf[0] = 0xff;

    buf[1] = enable ? 1 : 0;
    buf[2] = 0;

    const writeS16 = (v, off) => {
        if (v < 0) v += 0x10000;
        buf[off] = v & 0xff;
        buf[off + 1] = (v >> 8) & 0xff;
    };

    writeS16(f_cut, 3);
    writeS16(dry, 5);
    writeS16(wet, 7);

    return buf;
}

/* ===== HOOK ===== */
export function useEXCITER(index) {
    const { sendEffect, sendAndWaitEffect } =
        useEffects();

    const params = useEffectStore(
        (s) => s.effect_params[index]
    );

    const setEffectParams =
        useEffectStore((s) => s.setEffectParams);

    /* LOAD */
    const load = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res || res.length < 9) return null;

        const parsed = parseEXCITER(index, res);
        setEffectParams(index, parsed);
        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);

    /* ENABLE */
    const setEnable = useCallback(async (enable) => {
        const cur = await load();

        const payload = buildExciterPayload({
            ...cur,
            enable,
        });

        sendEffect(index, payload);

        setEffectParams(index, {
            ...cur,
            enable,
        });
    }, [index, load, sendEffect, setEffectParams]);

    /* UPDATE */
    const update = useCallback(async (field, val) => {
        const cur = await load();

        const payload = buildExciterPayload({
            ...cur,
            [field]: val,
        });

        sendEffect(index, payload);

        setEffectParams(index, {
            ...cur,
            [field]: val,
        });
    }, [index, load, sendEffect, setEffectParams]);

    return {
        data: params,
        load,

        setEnable,
        setCutoff: (v) => update("f_cut", v),
        setDry: (v) => update("dry", v),
        setWet: (v) => update("wet", v),
    };
}

import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

/* ================= PARSE ================= */

function readS16(lo, hi) {
    let v = lo | (hi << 8);
    if (v & 0x8000) v -= 0x10000;
    return v;
}
function readU16(lo, hi) {
    return lo | (hi << 8);
}

export function parseDRC(index, buf) {
    const enable = buf[1] === 1;
    let o = 3;

    const mode = readU16(buf[o++], buf[o++]);
    const cf_type = readU16(buf[o++], buf[o++]);
    const q_l = readU16(buf[o++], buf[o++]);
    const q_h = readU16(buf[o++], buf[o++]);

    const fc = [
        readS16(buf[o++], buf[o++]),
        readS16(buf[o++], buf[o++]),
    ];

    const read4 = () => {
        const a = [];
        for (let i = 0; i < 4; i++) a.push(readS16(buf[o++], buf[o++]));
        return a;
    };

    return {
        index,
        enable,
        mode,
        cf_type,
        q_l,
        q_h,
        fc,
        threshold: read4(),
        ratio: read4(),
        attack_tc: read4(),
        release_tc: read4(),
        pregain: read4(),
    };
}

/* ================= BUILD ================= */

function writeU16(buf, o, v) {
    buf[o] = v & 0xff;
    buf[o + 1] = (v >> 8) & 0xff;
}
function writeS16(buf, o, v) {
    if (v < -32768) v = -32768;
    if (v > 32767) v = 32767;
    buf[o] = v & 0xff;
    buf[o + 1] = (v >> 8) & 0xff;
}

export function buildDRCPayload(p) {
    const buf = new Uint8Array(55);

    buf[0] = 0xff;
    buf[1] = p.enable ? 1 : 0;
    buf[2] = 0;

    let o = 3;

    writeU16(buf, o, p.mode); o += 2;
    writeU16(buf, o, p.cf_type); o += 2;
    writeU16(buf, o, p.q_l); o += 2;
    writeU16(buf, o, p.q_h); o += 2;

    writeS16(buf, o, p.fc[0]); o += 2;
    writeS16(buf, o, p.fc[1]); o += 2;

    const write4 = (arr) => {
        for (let i = 0; i < 4; i++) {
            writeS16(buf, o, arr[i]);
            o += 2;
        }
    };

    write4(p.threshold);
    write4(p.ratio);
    write4(p.attack_tc);
    write4(p.release_tc);
    write4(p.pregain);

    return buf;
}

/* ================= HOOK ================= */

export function useDRC(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();
    const params = useEffectStore((s) => s.effect_params[index]);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);

    /* ---------- LOAD ---------- */

    const loadDRC = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res) return null;

        const parsed = parseDRC(index, res);
        setEffectParams(index, parsed);
        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);

    /* ---------- SEND ---------- */

    const sendFull = useCallback(
        (next) => {
            const payload = buildDRCPayload(next);
            sendEffect(index, payload);
            setEffectParams(index, next);
        },
        [index, sendEffect, setEffectParams],
    );

    /* ================= BASIC SET ================= */

    const setEnable = useCallback(
        async (v) => {
            const cur = await loadDRC();
            if (!cur) return;
            sendFull({ ...cur, enable: v });
        },
        [loadDRC, sendFull],
    );

    const setMode = useCallback(
        async (v) => {
            const cur = await loadDRC();
            if (!cur) return;
            sendFull({ ...cur, mode: v });
        },
        [loadDRC, sendFull],
    );

    const setCfType = useCallback(
        async (v) => {
            const cur = await loadDRC();
            if (!cur) return;
            sendFull({ ...cur, cf_type: v });
        },
        [loadDRC, sendFull],
    );

    const setFc = useCallback(
        async (i, v) => {
            const cur = await loadDRC();
            if (!cur) return;
            const fc = [...cur.fc];
            fc[i] = v;
            sendFull({ ...cur, fc });
        },
        [loadDRC, sendFull],
    );

    const setQ = useCallback(
        async (i, v) => {
            const cur = await loadDRC();
            if (!cur) return;
            if (i === 0) sendFull({ ...cur, q_l: v });
            else sendFull({ ...cur, q_h: v });
        },
        [loadDRC, sendFull],
    );

    /* ================= BAND SET ================= */

    const setBand = useCallback(
        async (band, field, val) => {
            const cur = await loadDRC();
            if (!cur) return;
            const arr = [...cur[field]];
            arr[band] = val;
            sendFull({ ...cur, [field]: arr });
        },
        [loadDRC, sendFull],
    );

    return {
        data: params,
        loadDRC,

        /* BASIC */
        setEnable,
        setMode,
        setCfType,
        setFc,
        setQ,

        /* BAND */
        setThreshold: (b, v) => setBand(b, "threshold", v),
        setRatio: (b, v) => setBand(b, "ratio", v),
        setAttack: (b, v) => setBand(b, "attack_tc", v),
        setRelease: (b, v) => setBand(b, "release_tc", v),
        setPregain: (b, v) => setBand(b, "pregain", v),
    };
}

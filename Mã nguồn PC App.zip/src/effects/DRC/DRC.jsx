import { useEffect, useState, useMemo, useRef } from "react";
import { useDRC } from "./useDRC";

/* ================= MODE ================= */

const MODE = {
  FULLBAND: 0,
  BAND2: 1,
  BAND2_FB: 2,
  BAND3: 3,
  BAND3_FB: 4,
};

const TAB_LABEL = ["Low", "Mid", "High", "Full"];

function getBandUsage(mode) {
  switch (mode) {
    case MODE.FULLBAND:
      return [false, false, false, true];
    case MODE.BAND2:
      return [true, true, false, false];
    case MODE.BAND2_FB:
      return [true, true, false, true];
    case MODE.BAND3:
      return [true, true, true, false];
    case MODE.BAND3_FB:
      return [true, true, true, true];
    default:
      return [true, true, true, true];
  }
}

/* ================= COMPONENT ================= */

export default function DRC({ index, name }) {
  const {
    data,
    loadDRC,
    setEnable,
    setMode,
    setCfType,
    setFc,
    setQ,
    setThreshold,
    setRatio,
    setAttack,
    setRelease,
    setPregain,
  } = useDRC(index);

  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState(0);

  const [local, setLocal] = useState({
    fc: [200, 2000],
    q: [70, 70],
    threshold: [0, 0, 0, 0],
    ratio: [100, 100, 100, 100],
    attack: [100, 100, 100, 100],
    release: [100, 100, 100, 100],
    pregain: [0, 0, 0, 0],
  });

  /* ================= LOAD ================= */

  useEffect(() => {
    if (!data) loadDRC();
  }, [data]);

  useEffect(() => {
    if (!data) return;

    setLocal({
      fc: [...data.fc],
      q: [data.q_l, data.q_h],
      threshold: [...data.threshold],
      ratio: [...data.ratio],
      attack: [...data.attack_tc],
      release: [...data.release_tc],
      pregain: [...data.pregain],
    });
  }, [data]);

  const enable = data?.enable ?? false;
  const mode = data?.mode ?? 0;
  const cfType = data?.cf_type ?? 0;

  const bandUse = getBandUsage(mode);

  /* reset tab nếu band không tồn tại */
  useEffect(() => {
    if (!bandUse[tab]) {
      const first = bandUse.findIndex((v) => v);
      setTab(first === -1 ? 0 : first);
    }
  }, [mode]);

  /* ================= UPDATE ================= */

  const updateBand = (field, val, setter) => {
    if (!enable) return;
    const arr = [...local[field]];
    arr[tab] = val;
    setLocal((s) => ({ ...s, [field]: arr }));
    setter(tab, val);
  };

  /* ================= GRAPH ================= */

  /* ================= GRAPH DATA ================= */

  const curvePoints = useMemo(() => {
    const pts = [];

    const thr = local.threshold[tab] / 100; // DSP → dB
    const ratio = Math.max(1, local.ratio[tab]); // linear (1..1000)
    const pregain =
      local.pregain[tab] > 0 ? 20 * Math.log10(local.pregain[tab] / 4096) : -90;

    for (let x = -90; x <= 0; x += 1) {
      let y = x;

      if (x > thr) {
        y = thr + (x - thr) / ratio;
      }

      y += pregain; // apply pregain shift

      // clamp graph range
      if (y < -90) y = -90;
      if (y > 20) y = 20;

      pts.push({ x, y });
    }

    return pts;
  }, [local, tab]);

  /* ================= UI ================= */

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setEnable(!enable);
            }}
            className={`w-9 h-5 flex items-center rounded-full
            ${enable ? "bg-blue-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full
              ${enable ? "translate-x-4" : "translate-x-1"}`}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={open ? "rotate-180" : ""}>▾</div>
      </div>

      {/* BODY */}
      {open && data && (
        <div className={`${!enable && "opacity-50"} p-4`}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* GRAPH */}
            <div className="bg-black rounded-lg p-3 border">
              <CurveGraph points={curvePoints} />
            </div>

            {/* CONTROL */}
            <div className="bg-gray-50 border rounded-lg p-3 flex flex-col gap-4">
              {/* MODE */}
              <Row label="Mode">
                <select
                  value={mode}
                  disabled={!enable}
                  onChange={(e) => setMode(Number(e.target.value))}
                  className="input"
                >
                  <option value={0}>Fullband</option>
                  <option value={1}>2 Band</option>
                  <option value={2}>2 Band + Full</option>
                  <option value={3}>3 Band</option>
                  <option value={4}>3 Band + Full</option>
                </select>
              </Row>

              {/* CROSSOVER */}
              {mode !== MODE.FULLBAND && (
                <>
                  <Row label="Crossover">
                    <select
                      value={cfType}
                      disabled={!enable}
                      onChange={(e) => setCfType(Number(e.target.value))}
                      className="input"
                      title="Chọn kiểu bộ lọc phân tần. Linkwitz-Riley cho tổng pha phẳng, Butterworth có độ dốc chuẩn."
                    >
                      <option value={0}>Linkwitz-Riley</option>
                      <option value={1}>Butterworth</option>
                    </select>
                  </Row>

                  <Inline
                    label="Fc Low"
                    value={local.fc[0]}
                    min={20}
                    max={2000}
                    step={1}
                    unit="Hz"
                    title="Range: 20 → 2000 Hz. Tần số cắt thấp của bộ phân tần."
                    onChange={(v) => {
                      const arr = [...local.fc];
                      arr[0] = v;
                      setLocal((s) => ({ ...s, fc: arr }));
                      setFc(0, v);
                    }}
                  />

                  {mode >= MODE.BAND3 && (
                    <Inline
                      label="Fc High"
                      value={local.fc[1]}
                      min={500}
                      max={20000}
                      step={1}
                      unit="Hz"
                      title="Range: 500 → 20000 Hz. Tần số cắt cao của bộ phân tần."
                      onChange={(v) => {
                        const arr = [...local.fc];
                        arr[1] = v;
                        setLocal((s) => ({ ...s, fc: arr }));
                        setFc(1, v);
                      }}
                    />
                  )}

                  <Inline
                    label="Q Low"
                    value={+(local.q[0] / 1024).toFixed(3)}
                    min={0.1}
                    max={5}
                    step={0.01}
                    unit=""
                    title="Range: 0.1 → 5. Độ dốc / độ sắc của bộ lọc thấp. Q cao → dốc hơn, nhọn hơn."
                    onChange={(v) => {
                      const dsp = Math.round(v * 1024);

                      const arr = [...local.q];
                      arr[0] = dsp;

                      setLocal((s) => ({ ...s, q: arr }));
                      setQ(dsp, local.q[1]); // ⚠ setQ(low, high)
                    }}
                  />

                  {mode >= MODE.BAND3 && (
                    <Inline
                      label="Q High"
                      value={local.q[1] / 100}
                      min={0.1}
                      max={5}
                      step={0.01}
                      unit=""
                      title="Range: 0.1 → 5. Độ dốc / độ sắc của bộ lọc cao. Q cao → dốc hơn, nhọn hơn."
                      onChange={(v) => {
                        const arr = [...local.q];
                        arr[1] = Math.round(v * 100);
                        setLocal((s) => ({ ...s, q: arr }));
                        setQ(1, arr[1]);
                      }}
                    />
                  )}
                </>
              )}

              {/* TABS */}
              <div className="flex gap-1">
                {bandUse.map((use, i) =>
                  use ? (
                    <button
                      key={i}
                      onClick={() => setTab(i)}
                      className={`flex-1 py-1 text-xs rounded
                      ${tab === i ? "bg-blue-500 text-white" : "bg-gray-200"}`}
                    >
                      {TAB_LABEL[i]}
                    </button>
                  ) : null,
                )}
              </div>

              {/* BAND PARAM */}
              {bandUse[tab] && (
                <>
                  {/* ================= PREGAIN ================= */}
                  <Inline2
                    label="Pregain"
                    step={0.1}
                    min={-90}
                    max={18}
                    value={
                      local.pregain[tab] > 0
                        ? +(20 * Math.log10(local.pregain[tab] / 4096)).toFixed(
                            2,
                          )
                        : -90
                    }
                    unit="dB"
                    title="Range: -90 → 18 dB. Tăng/giảm mức tín hiệu trước khi vào compressor."
                    onChange={(db) => {
                      const snap = Math.round(db * 10) / 10; // bước 0.1 dB
                      const linear = Math.pow(10, snap / 20);
                      const dsp = Math.max(1, Math.round(linear * 4096)); // tránh =0 mute
                      updateBand("pregain", dsp, setPregain);
                    }}
                  />

                  {/* ================= THRESHOLD ================= */}
                  <Inline2
                    label="Threshold"
                    step={0.1}
                    min={-90}
                    max={0}
                    value={+(local.threshold[tab] / 100).toFixed(2)}
                    unit="dB"
                    title="Range: -90 → 0 dB. Ngưỡng bắt đầu nén. Khi tín hiệu vượt mức này, compressor sẽ hoạt động."
                    onChange={(v) => {
                      const snap = Math.round(v * 10) / 10;
                      const dsp = Math.round(snap * 100); // firmware ×100
                      updateBand("threshold", dsp, setThreshold);
                    }}
                  />

                  {/* ================= RATIO ================= */}
                  <Inline
                    label="Ratio"
                    step={0.1}
                    min={1}
                    max={1000}
                    value={+local.ratio[tab].toFixed(1)}
                    unit="x"
                    title="Range: 1 → 1000. Tỷ lệ nén. Ví dụ 4:1 nghĩa là cứ 4 dB vượt ngưỡng thì đầu ra chỉ tăng 1 dB."
                    onChange={(v) => {
                      const snap = Math.round(v * 10) / 10;
                      const dsp = Math.round(snap); // firmware không ×100
                      updateBand("ratio", dsp, setRatio);
                    }}
                  />

                  {/* ================= ATTACK ================= */}
                  <Inline
                    label="Attack"
                    step={1}
                    min={0}
                    max={7500}
                    value={local.attack[tab]}
                    unit="ms"
                    title="Range: 0 → 7500 ms. Thời gian compressor bắt đầu giảm gain sau khi tín hiệu vượt Threshold."
                    onChange={(v) => {
                      const dsp = Math.round(v);
                      updateBand("attack", dsp, setAttack);
                    }}
                  />

                  {/* ================= RELEASE ================= */}
                  <Inline
                    label="Release"
                    step={1}
                    min={0}
                    max={7500}
                    value={local.release[tab]}
                    unit="ms"
                    title="Range: 0 → 7500 ms. Thời gian compressor trở về trạng thái bình thường sau khi tín hiệu giảm xuống dưới Threshold."
                    onChange={(v) => {
                      const dsp = Math.round(v);
                      updateBand("release", dsp, setRelease);
                    }}
                  />
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= SMALL UI ================= */

function Row({ label, children }) {
  return (
    <div className="flex items-center gap-2">
      <div className="text-sm w-[90px]">{label}</div>
      {children}
    </div>
  );
}

function Inline({
  label,
  value,
  unit,
  step = 0.1,
  min = -120,
  max = 120,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    Number.isFinite(value) ? value.toString() : "",
  );

  /* sync khi value từ ngoài thay đổi */
  useEffect(() => {
    if (Number.isFinite(value)) {
      setDisplay(value.toString());
    }
  }, [value]);

  /* ===== HANDLE CHANGE ===== */
  const handleChange = (e) => {
    const v = e.target.value;

    // cho phép trạng thái trung gian khi nhập
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    // nếu đang nhập dở thì chưa emit
    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  /* ===== HANDLE BLUR ===== */
  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center gap-2">
      <div className="text-sm w-[90px]">{label}</div>

      <input
        type="text"
        inputMode="decimal"
        value={display}
        step={step}
        title={title}
        disabled={!enable}
        onChange={handleChange}
        onBlur={handleBlur}
        className="w-[100px] px-2 py-[4px] text-sm rounded bg-white border focus:outline-none focus:ring-2 focus:ring-blue-400"
      />

      <div className="text-xs w-[40px]">{unit}</div>
    </div>
  );
}

function Inline2({
  label,
  value,
  unit,
  step = 0.1,
  min = -120,
  max = 120,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    Number.isFinite(value) ? value.toString() : "",
  );

  /* sync khi value từ ngoài thay đổi */
  useEffect(() => {
    if (Number.isFinite(value)) {
      setDisplay(value.toString());
    }
  }, [value]);

  /* ===== HANDLE CHANGE ===== */
  const handleChange = (e) => {
    const v = e.target.value;

    // cho phép trạng thái trung gian khi nhập
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    // nếu đang nhập dở thì chưa emit
    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  /* ===== HANDLE BLUR ===== */
  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center gap-2">
      <div className="text-sm w-[90px]">{label}</div>

      <input
        type="text"
        value={display}
        step={step}
        title={title}
        disabled={!enable}
        onChange={handleChange}
        onBlur={handleBlur}
        className="w-[100px] px-2 py-[4px] text-sm rounded bg-white border focus:outline-none focus:ring-2 focus:ring-blue-400"
      />

      <div className="text-xs w-[40px]">{unit}</div>
    </div>
  );
}

function CurveGraph({ points }) {
  const containerRef = useRef(null);
  const [size, setSize] = useState({ w: 0, h: 0 });

  /* ================= RESIZE OBSERVER ================= */
  useEffect(() => {
    if (!containerRef.current) return;

    const observer = new ResizeObserver((entries) => {
      const rect = entries[0].contentRect;

      const width = rect.width;
      const height = rect.width * 0.62; // giữ tỉ lệ 420:260 ≈ 0.62

      setSize({
        w: width,
        h: height,
      });
    });

    observer.observe(containerRef.current);

    return () => observer.disconnect();
  }, []);

  const w = size.w;
  const h = size.h;

  if (!w || !h) {
    return <div ref={containerRef} className="w-full h-[200px]" />;
  }

  /* ================= SCALE ================= */

  const dbMinX = -90;
  const dbMaxX = 0;

  const dbMinY = -90;
  const dbMaxY = 20;

  const scaleX = (db) => ((db - dbMinX) / (dbMaxX - dbMinX)) * w;

  const scaleY = (db) => h - ((db - dbMinY) / (dbMaxY - dbMinY)) * h;

  /* ================= PATH ================= */

  const path = points
    .map((p, i) => {
      const x = scaleX(p.x);
      const y = scaleY(p.y);
      return `${i === 0 ? "M" : "L"}${x},${y}`;
    })
    .join(" ");

  const gridX = [-80, -60, -40, -20, 0];
  const gridY = [-80, -60, -40, -20, 0, 10, 20];

  /* ================= RENDER ================= */

  return (
    <div ref={containerRef} className="w-full">
      <svg width={w} height={h} className="border bg-black rounded-lg">
        {/* ===== GRID X ===== */}
        {gridX.map((db) => {
          const x = scaleX(db);
          return (
            <g key={"x" + db}>
              <line x1={x} y1={0} x2={x} y2={h} stroke="#333" />
              <text
                x={x}
                y={h - 4}
                fill="#888"
                fontSize="10"
                textAnchor="middle"
              >
                {db}
              </text>
            </g>
          );
        })}

        {/* ===== GRID Y ===== */}
        {gridY.map((db) => {
          const y = scaleY(db);
          return (
            <g key={"y" + db}>
              <line x1={0} y1={y} x2={w} y2={y} stroke="#333" />
              <text x={4} y={y - 2} fill="#888" fontSize="10">
                {db}
              </text>
            </g>
          );
        })}

        {/* ===== UNITY LINE ===== */}
        <line
          x1={scaleX(-90)}
          y1={scaleY(-90)}
          x2={scaleX(0)}
          y2={scaleY(0)}
          stroke="#555"
          strokeDasharray="4 3"
        />

        {/* ===== CURVE ===== */}
        <path d={path} stroke="lime" strokeWidth="2" fill="none" />

        {/* ===== AXIS LABEL ===== */}
        <text x={w - 40} y={h - 6} fill="#aaa" fontSize="10">
          dB In
        </text>

        <text x={6} y={12} fill="#aaa" fontSize="10">
          dB Out
        </text>
      </svg>
    </div>
  );
}

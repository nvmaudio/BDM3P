import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";


// ================= PARSE =================
export function parseExpander(index, buf) {
    const readS16 = (lo, hi) => {
        let v = lo | (hi << 8);
        if (v & 0x8000) v -= 0x10000;
        return v;
    };

    //      buf[0] = 0xff
    //      buf[1-2] enable

    const enable = Boolean(buf[1]); 

    const threshold = readS16(buf[3], buf[4]);
    const ratioRaw = readS16(buf[5], buf[6]);
    const attack = readS16(buf[7], buf[8]);
    const release = readS16(buf[9], buf[10]);

    return {
        index,
        enable,

        threshold,          // dB * 100
        ratio: ratioRaw,    // raw (1 → 1000)

        attack,             // ms
        release,            // ms

        raw: Array.from(buf),
    };
}


// ================= BUILD =================
export function buildExpanderPayload({
    enable,
    threshold,
    ratio,
    attack,
    release,
}) {
    const clamp = (v, min, max) =>
        Math.max(min, Math.min(max, v));

    threshold = clamp(threshold, -9000, 0);
    ratio = clamp(ratio, 1, 1000);
    attack = clamp(attack, 0, 7500);
    release = clamp(release, 0, 7500);

    const buf = new Uint8Array(11);

    buf[0] = 0xff;

    // enable u16
    buf[1] = enable ? 1 : 0;
    buf[2] = 0;

    const writeS16 = (v, offset) => {
        if (v < 0) v += 0x10000;
        buf[offset] = v & 0xff;
        buf[offset + 1] = (v >> 8) & 0xff;
    };

    writeS16(threshold, 3);
    writeS16(ratio, 5);
    writeS16(attack, 7);
    writeS16(release, 9);

    return buf;
}


// ================= HOOK =================
export function useEXPANDER(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore(
        (s) => s.effect_params[index]
    );

    const setEffectParams =
        useEffectStore((s) => s.setEffectParams);

    // ===== LOAD =====
    const loadExpander = useCallback(
        async () => {
            if (params) return params;

            const res = await sendAndWaitEffect(index);
            if (!res || res.length < 11) return null;

            const parsed = parseExpander(index, res);

            setEffectParams(index, parsed);

            return parsed;
        },
        [index, params, sendAndWaitEffect, setEffectParams]
    );


    // ===== ENABLE =====
    const setEnable = useCallback(
        async (enable) => {
            const cur = await loadExpander();

            const payload =
                buildExpanderPayload({
                    ...cur,
                    enable,
                });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                enable,
            });
        },
        [index, loadExpander, sendEffect, setEffectParams]
    );


    // ===== PARAM SETTERS =====
    const updateParam = useCallback(
        async (field, value) => {
            const cur = await loadExpander();

            const payload =
                buildExpanderPayload({
                    ...cur,
                    [field]: value,
                });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                [field]: value,
            });
        },
        [index, loadExpander, sendEffect, setEffectParams]
    );

    return {
        data: params,

        loadExpander,

        setEnable,
        setThreshold: (v) => updateParam("threshold", v),
        setRatio: (v) => updateParam("ratio", v),
        setAttack: (v) => updateParam("attack", v),
        setRelease: (v) => updateParam("release", v),
    };
}

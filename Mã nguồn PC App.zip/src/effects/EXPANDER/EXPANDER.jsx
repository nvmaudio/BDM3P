import { useEffect, useState } from "react";
import { useEXPANDER } from "./useEXPANDER";

export default function Expander({ index, name }) {
  const {
    data,
    loadExpander,
    setEnable,
    setThreshold,
    setRatio,
    setAttack,
    setRelease,
  } = useEXPANDER(index);

  const [local, setLocal] = useState({
    threshold: -4500,
    ratio: 300,
    attack: 2,
    release: 100,
  });

  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!data) loadExpander();
  }, [data]);

  useEffect(() => {
    if (data) {
      setLocal({
        threshold: data.threshold,
        ratio: data.ratio,
        attack: data.attack,
        release: data.release,
      });
    }
  }, [data]);

  const enable = data?.enable ?? false;

  const togglePower = async (e) => {
    e.stopPropagation();
    await setEnable(!enable);
  };

  const update = (field, v) => {
    setLocal((s) => ({ ...s, [field]: v }));

    if (field === "threshold") setThreshold(v);
    if (field === "ratio") setRatio(v);
    if (field === "attack") setAttack(v);
    if (field === "release") setRelease(v);
  };

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-4 py-3 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-10 h-5 flex items-center rounded-full transition ${
              enable ? "bg-blue-500" : "bg-gray-300"
            }`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition ${
                enable ? "translate-x-5" : "translate-x-1"
              }`}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div
          className={`text-gray-500 transition-transform ${
            open ? "rotate-180" : ""
          }`}
        >
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className="px-4 py-5">
          <div className={`flex flex-wrap gap-4 ${!enable && "opacity-50"}`}>
            <Inline
              label="Ratio"
              value={local.ratio / 100}
              unit=""
              min={1}
              max={1000}
              step={0.1}
              title="Range: 1 → 1000. Expansion Ratio. Ví dụ 1:4 nghĩa là tín hiệu thấp hơn Threshold 4 dB sẽ giảm thêm 1 dB."
              enable={enable}
              onChange={(v) => update("ratio", Math.round(v * 100))}
            />

            <Inline2
              label="Threshold"
              value={local.threshold / 100}
              unit="dB"
              min={-90}
              max={0}
              step={0.1}
              title="Range: -90 → 0 dB. Mức ngưỡng bắt đầu Expander. Tín hiệu thấp hơn mức này sẽ bị giảm gain."
              enable={enable}
              onChange={(v) => update("threshold", Math.round(v * 100))}
            />

            <Inline
              label="Attack"
              value={local.attack}
              min={0}
              max={7500}
              step={1}
              unit="ms"
              title="Range: 0 → 7500 ms. Thời gian expander bắt đầu giảm gain sau khi tín hiệu xuống dưới Threshold. Attack nhanh = cắt nhanh."
              enable={enable}
              onChange={(v) => update("attack", v)}
            />

            <Inline
              label="Release"
              value={local.release}
              min={0}
              max={7500}
              step={1}
              unit="ms"
              title="Range: 0 → 7500 ms. Thời gian expander trả lại mức bình thường khi tín hiệu vượt lên trên Threshold."
              enable={enable}
              onChange={(v) => update("release", v)}
            />
          </div>
        </div>
      )}
    </div>
  );
}

/* ===================================================== */
/* ================== INLINE COMPONENT ================= */
/* ===================================================== */

function Inline({
  label,
  value,
  unit,
  min,
  max,
  step = 1,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex-1 min-w-[180px] max-w-full flex items-center gap-2">
      <div className="text-sm text-gray-800 w-[80px] text-right shrink-0">
        {label}
      </div>

      <input
        type="text"
        inputMode="decimal"
        value={display}
        step={step}
        disabled={!enable}
        title={title}
        onChange={handleChange}
        onBlur={handleBlur}
        className="flex-1 min-w-[70px] px-2 py-1 text-sm text-white font-medium text-center rounded-md bg-gradient-to-b from-[#112e3a] to-[#113a0a] border border-[#4e6a75] outline-none"
      />

      <div className="text-sm text-gray-700 w-[40px] shrink-0">{unit}</div>
    </div>
  );
}

function Inline2({
  label,
  value,
  unit,
  min,
  max,
  step = 1,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex-1 min-w-[180px] max-w-full flex items-center gap-2">
      <div className="text-sm text-gray-800 w-[80px] text-right shrink-0">
        {label}
      </div>

      <input
        type="text"
        value={display}
        step={step}
        disabled={!enable}
        title={title}
        onChange={handleChange}
        onBlur={handleBlur}
        className="flex-1 min-w-[70px] px-2 py-1 text-sm text-white font-medium text-center rounded-md bg-gradient-to-b from-[#112e3a] to-[#113a0a] border border-[#4e6a75] outline-none"
      />

      <div className="text-sm text-gray-700 w-[40px] shrink-0">{unit}</div>
    </div>
  );
}

import { useEffect, useState } from "react";
import { useSTEREO_WIDENER } from "./useSTEREO_WIDENER";

export default function STEREO_WIDENER({ index, name }) {
  const { data, loadStereoWidener, setEnable, setShaping } =
    useSTEREO_WIDENER(index);

  const [local, setLocal] = useState({
    shaping: 0,
  });

  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!data) loadStereoWidener();
  }, [data]);

  useEffect(() => {
    if (data) {
      setLocal({
        shaping: data.shaping,
      });
    }
  }, [data]);

  const enable = data?.enable ?? false;

  const togglePower = async (e) => {
    e.stopPropagation();
    await setEnable(!enable);
  };

  const update = (v) => {
    setLocal({ shaping: v });
    setShaping(v);
  };

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          {/* POWER */}
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
            ${enable ? "bg-blue-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
              ${enable ? "translate-x-4" : "translate-x-1"}`}
            />
          </button>

          {/* TITLE */}
          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`${open ? "rotate-180" : ""}`}>▾</div>
      </div>

      {/* BODY */}
      {open && (
        <div className="px-4 py-4">
          {!data && <div className="text-sm text-gray-400">Loading...</div>}

          {data && (
            <div className={`${!enable && "opacity-50"} flex gap-6`}>
              <Inline
                label="Shaping"
                value={local.shaping}
                enable={enable}
                onChange={update}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Inline({ label, value, enable, onChange }) {
  return (
    <div className="flex items-center gap-2">
      <div className="text-sm w-[80px] text-right text-gray-700">{label}</div>

      <select
        value={value}
        disabled={!enable}
        onChange={(e) => onChange(Number(e.target.value))}
        className="
            w-[120px] px-2 py-[4px] text-sm text-white rounded-md
            bg-gradient-to-b from-[#240402] to-[#1b1f76]
            border border-[#4e6a75] outline-none"
      >
        <option className="text-gray-700" value={0}>
          Normal
        </option>
        <option className="text-gray-700" value={1}>
          Wide
        </option>
      </select>
    </div>
  );
}

import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

// ===== parse từ DSP =====
export function parseStereoWidener(index, buf) {
    const readS16 = (lo, hi) => {
        let v = lo | (hi << 8);
        if (v & 0x8000) v -= 0x10000;
        return v;
    };

    const enable = buf[1] === 1;

    const shaping = readS16(buf[3], buf[4]);

    return {
        index,
        enable,
        shaping,
        raw: Array.from(buf),
    };
}

// ===== build payload =====
export function buildStereoWidenerPayload({ enable, shaping }) {
    const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

    shaping = clamp(shaping, 0, 1);

    const buf = new Uint8Array(5);

    buf[0] = 0xff;

    // enable u16
    buf[1] = enable ? 1 : 0;
    buf[2] = 0;

    const writeS16 = (v, off) => {
        if (v < 0) v += 0x10000;
        buf[off] = v & 0xff;
        buf[off + 1] = (v >> 8) & 0xff;
    };

    writeS16(shaping, 3);

    return buf;
}

// ===== hook =====
export function useSTEREO_WIDENER(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore((s) => s.effect_params[index]);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);

    // LOAD
    const loadStereoWidener = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res || res.length < 5) return null;

        const parsed = parseStereoWidener(index, res);
        setEffectParams(index, parsed);
        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);

    // ENABLE
    const setEnable = useCallback(
        async (enable) => {
            const cur = await loadStereoWidener();

            const payload = buildStereoWidenerPayload({
                ...cur,
                enable,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                enable,
            });
        },
        [index, loadStereoWidener, sendEffect, setEffectParams]
    );

    // SHAPING
    const setShaping = useCallback(
        async (value) => {
            const cur = await loadStereoWidener();

            const payload = buildStereoWidenerPayload({
                ...cur,
                shaping: value,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                shaping: value,
            });
        },
        [index, loadStereoWidener, sendEffect, setEffectParams]
    );

    return {
        data: params,
        loadStereoWidener,

        setEnable,
        setShaping,
    };
}

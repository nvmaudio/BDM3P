import { useEffect, useState, useRef, useCallback } from "react";
import { useDAC0Volume } from "./useDAC0Volume";

export default function DAC0Volume({ index, name }) {
  const {
    data,
    loadDAC0,
    setLeftVolume,
    setRightVolume,
    setStereoVolume,
    MIN_DB,
    MAX_DB,
  } = useDAC0Volume(index);

  const [open, setOpen] = useState(false);
  const [link, setLink] = useState(true);

  const [localL, setLocalL] = useState(MIN_DB ?? -60);
  const [localR, setLocalR] = useState(MIN_DB ?? -60);

  const debounceL = useRef(null);
  const debounceR = useRef(null);

  /* ================= LOAD ================= */

  useEffect(() => {
    if (!data) loadDAC0();
  }, [data, loadDAC0]);

  /* ================= SYNC DEVICE ================= */

  useEffect(() => {
    if (!data) return;

    if (typeof data.lVol === "number") setLocalL(clamp(data.lVol));

    if (typeof data.rVol === "number") setLocalR(clamp(data.rVol));
  }, [data]);

  /* ================= UTILS ================= */

  const clamp = (v) => Math.min(MAX_DB, Math.max(MIN_DB, Number(v)));

  /* ================= SEND ================= */

  const sendLeft = useCallback(
    (v) => {
      clearTimeout(debounceL.current);
      debounceL.current = setTimeout(() => {
        setLeftVolume(v);
      }, 120);
    },
    [setLeftVolume],
  );

  const sendRight = useCallback(
    (v) => {
      clearTimeout(debounceR.current);
      debounceR.current = setTimeout(() => {
        setRightVolume(v);
      }, 120);
    },
    [setRightVolume],
  );

  const sendStereo = useCallback(
    (v) => {
      clearTimeout(debounceL.current);
      debounceL.current = setTimeout(() => {
        setStereoVolume(v);
      }, 120);
    },
    [setStereoVolume],
  );

  /* ================= HANDLERS ================= */

  const onLeftChange = (v) => {
    const value = clamp(v);

    setLocalL(value);

    if (link) {
      setLocalR(value);
      sendStereo(value);
    } else {
      sendLeft(value);
    }
  };

  const onRightChange = (v) => {
    const value = clamp(v);
    setLocalR(value);
    sendRight(value);
  };

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="text-sm font-semibold">{name} (0x09)</div>
        <div className={`${open ? "rotate-180" : ""}`}>▾</div>
      </div>

      {/* BODY */}
      {open && (
        <div className="px-4 py-4 flex flex-col gap-6">
          {/* LINK TOGGLE */}
          <div className="flex items-center gap-3">
            <label className="text-sm font-medium">Stereo Link</label>

            <button
              onClick={() => setLink((v) => !v)}
              className={`w-9 h-5 flex items-center rounded-full transition
                ${link ? "bg-blue-500" : "bg-gray-300"}`}
            >
              <div
                className={`w-4 h-4 bg-white rounded-full shadow transform transition
                ${link ? "translate-x-4" : "translate-x-1"}`}
              />
            </button>
          </div>

          <Channel
            label="Left 🔊"
            value={localL}
            min={MIN_DB}
            max={MAX_DB}
            onChange={onLeftChange}
          />

          <Channel
            label="Right 🔊"
            value={localR}
            min={MIN_DB}
            max={MAX_DB}
            onChange={onRightChange}
          />
        </div>
      )}
    </div>
  );
}

/* ================= Channel ================= */

function Channel({ label, value, min, max, onChange, disabled }) {
  const safeValue = typeof value === "number" && !isNaN(value) ? value : min;

  const clamp = (v) => Math.min(max, Math.max(min, Number(v)));

  const handleSlider = (e) => {
    const v = clamp(e.target.value);
    onChange(v);
  };

  const handleInline = (v) => {
    const clamped = clamp(v);
    onChange(clamped);
  };

  return (
    <div
      className={`flex items-center gap-4 w-full ${
        disabled ? "opacity-50" : ""
      }`}
    >
      {/* LABEL */}
      <div className="w-[90px] text-sm font-medium">{label}</div>

      {/* SLIDER */}
      <input
        type="range"
        min={min}
        max={max}
        step={0.1}
        value={safeValue}
        onChange={handleSlider}
        disabled={disabled}
        className="flex-1 h-2 accent-blue-500"
      />

      {/* INLINE */}
      <Inline
        value={safeValue}
        unit="dB"
        min={min}
        max={max}
        step={0.1}
        enable={!disabled}
        onChange={handleInline}
      />
    </div>
  );
}

/* ================= Inline ================= */

function Inline({
  value,
  unit,
  min,
  max,
  step = 1,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center gap-2 w-full lg:w-auto">
      <input
        type="text"
        value={display}
        step={step}
        disabled={!enable}
        title={title}
        onChange={handleChange}
        onBlur={handleBlur}
        className="w-[90px] px-2 py-1 text-sm text-white font-medium text-center rounded-md bg-gradient-to-b from-[#112e3a] to-[#113a0a] border border-[#4e6a75] outline-none"
      />
      <div className="text-sm w-[40px]">{unit}</div>
    </div>
  );
}

import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

/* =========================================================
   CONSTANTS
========================================================= */

const index = 0x09;
const MAX_RAW = 0x3fff;   // theo driver
const Q12 = 4096;
const MIN_DB = -60;
const MAX_DB = 12;

/* =========================================================
   CONVERT
========================================================= */

function rawToDb(raw) {
    if (!raw) return MIN_DB;
    const linear = raw / Q12;
    return 20 * Math.log10(linear);
}

function dbToRaw(db) {
    if (db <= MIN_DB) return 0;

    const linear = Math.pow(10, db / 20);
    let raw = Math.round(linear * Q12);

    if (raw > MAX_RAW) raw = MAX_RAW;
    if (raw < 0) raw = 0;

    return raw;
}

/* =========================================================
   PARSE FROM ASK (len == 0)
   Offset theo Communication_Effect_0x09
========================================================= */

export function parseDAC0(buf) {
    const lRaw = buf[7] | (buf[8] << 8);
    const rRaw = buf[9] | (buf[10] << 8);

    return {
        lRaw,
        rRaw,
        lVol: rawToDb(lRaw),
        rVol: rawToDb(rRaw),
        raw: Array.from(buf),
    };
}

/* =========================================================
   BUILD COMMAND
========================================================= */

function buildVolumeCommand(id, raw) {
    const buf = new Uint8Array(3);
    buf[0] = id;          // 3 = L, 4 = R
    buf[1] = raw & 0xff;
    buf[2] = (raw >> 8) & 0xff;
    return buf;
}

/* =========================================================
   HOOK
========================================================= */

export function useDAC0Volume(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore((s) => s.effect_params[index]);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);

    /* ================= LOAD ================= */

    const loadDAC0 = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res || res.length < 15) return null;

        const parsed = parseDAC0(res);
        setEffectParams(index, parsed);
        console.log(parsed);

        return parsed;
    }, [params, sendAndWaitEffect, setEffectParams]);

    /* ================= SET LEFT ================= */

    const setLeftVolume = useCallback(
        async (volumeDb) => {
            const raw = dbToRaw(volumeDb);
            const payload = buildVolumeCommand(3, raw);

            sendEffect(index, payload);

            setEffectParams(index, (prev) => ({
                ...prev,
                lVol: volumeDb,
                lRaw: raw,
            }));
        },
        [sendEffect, setEffectParams]
    );

    /* ================= SET RIGHT ================= */

    const setRightVolume = useCallback(
        async (volumeDb) => {
            const raw = dbToRaw(volumeDb);
            const payload = buildVolumeCommand(4, raw);

            sendEffect(index, payload);

            setEffectParams(index, (prev) => ({
                ...prev,
                rVol: volumeDb,
                rRaw: raw,
            }));
        },
        [sendEffect, setEffectParams]
    );

    /* ================= SET BOTH (SYNC) ================= */

    const setStereoVolume = useCallback(
        async (volumeDb) => {
            const raw = dbToRaw(volumeDb);

            sendEffect(index, buildVolumeCommand(3, raw));
            sendEffect(index, buildVolumeCommand(4, raw));

            setEffectParams(index, (prev) => ({
                ...prev,
                lVol: volumeDb,
                rVol: volumeDb,
                lRaw: raw,
                rRaw: raw,
            }));
        },
        [sendEffect, setEffectParams]
    );

    return {
        data: params,

        loadDAC0,

        setLeftVolume,
        setRightVolume,
        setStereoVolume,

        MIN_DB,
        MAX_DB,
    };
}
import { useEffect, useState } from "react";
import { useCOMPANDER } from "./useCOMPANDER";

export default function Compander({ index, name }) {
  const {
    data,
    loadCOMPANDER,
    setCOMPANDEREnable,
    setThreshold,
    setSlopeBelow,
    setSlopeAbove,
    setAttack,
    setRelease,
    setPregain,
  } = useCOMPANDER(index);

  const [local, setLocal] = useState({
    threshold: -3000,
    slope_below: 1000,
    slope_above: 1000,
    attack: 10,
    release: 100,
    pregain: 0,
  });

  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!data) loadCOMPANDER();
  }, [data]);

  useEffect(() => {
    if (data) {
      setLocal({
        threshold: data.threshold,
        slope_below: data.slope_below,
        slope_above: data.slope_above,
        attack: data.alpha_attack,
        release: data.alpha_release,
        pregain: data.pregain,
      });
    }
  }, [data]);

  const enable = data?.enable ?? false;

  const togglePower = async (e) => {
    e.stopPropagation();
    await setCOMPANDEREnable(!enable);
  };

  const update = (field, v) => {
    setLocal((s) => ({ ...s, [field]: v }));

    if (field === "threshold") setThreshold(v);
    if (field === "slope_below") setSlopeBelow(v);
    if (field === "slope_above") setSlopeAbove(v);
    if (field === "attack") setAttack(v);
    if (field === "release") setRelease(v);
    if (field === "pregain") setPregain(v);
  };

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 backdrop-blur border border-gray-200 rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50/70 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`
              w-9 h-5 flex items-center rounded-full transition
              ${enable ? "bg-blue-500" : "bg-gray-300"}
            `}
          >
            <div
              className={`
                w-4 h-4 bg-white rounded-full shadow transform transition
                ${enable ? "translate-x-4" : "translate-x-1"}
              `}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div
          className={`
            text-gray-500 transition-transform
            ${open ? "rotate-180" : ""}
          `}
        >
          ▾
        </div>
      </div>

      {/* BODY */}
      {open && (
        <div className="px-4 py-4">
          {data && (
            <div
              className={`
                ${!enable && "opacity-50"}
                grid
                grid-cols-1
                sm:grid-cols-2
                lg:grid-cols-4
                gap-x-3
                gap-y-3
                items-center
              `}
            >
              {/* ===== COL 1 ===== */}
              <InlineInput2
                label="Threshold"
                value={local.threshold / 100}
                step={0.01}
                min={-90}
                max={0}
                unit="dB"
                title="Range: -90dB → 0dB, Vượt threshold COMPANDER sẽ nén xuống"
                enable={enable}
                onChange={(v) => update("threshold", Math.round(v * 100))}
              />

              {/* ===== COL 2 ===== */}
              <InlineInput1
                label="Ratio Below"
                value={local.slope_below / 100}
                step={0.1}
                min={0.1}
                max={100}
                title="Range: 0.1 → 100. Điều chỉnh mức xử lý khi tín hiệu nằm dưới Threshold (expansion / gate mềm)."
                enable={enable}
                onChange={(v) => update("slope_below", Math.round(v * 100))}
              />

              {/* ===== COL 3 ===== */}
              <InlineInput1
                label="Attack Time"
                value={local.attack}
                min={0}
                max={32767}
                unit="ms"
                title="Range: 0 → 32767 ms. Thời gian bắt đầu nén sau khi tín hiệu vượt Threshold."
                enable={enable}
                onChange={(v) => update("attack", v)}
              />

              {/* ===== COL 4 ===== */}
              <InlineInput1
                label="Pregain"
                value={local.pregain / 100}
                step={0.1}
                min={-72}
                max={18}
                unit="dB"
                title="Range: -72 → +18 dB. Tăng/giảm mức tín hiệu trước khi vào bộ nén."
                enable={enable}
                onChange={(v) => update("pregain", Math.round(v * 100))}
              />

              {/* ===== ROW 2 ===== */}
              <div className="hidden lg:block" />

              <InlineInput1
                label="Ratio Above"
                value={local.slope_above / 100}
                step={0.1}
                min={0.1}
                max={100}
                title="Range: 0.1 → 100. Tỷ lệ nén khi tín hiệu vượt Threshold."
                enable={enable}
                onChange={(v) => update("slope_above", Math.round(v * 100))}
              />

              <InlineInput1
                label="Release Time"
                value={local.release}
                min={0}
                max={32767}
                unit="ms"
                title="Range: 0 → 32767 ms. Thời gian compressor trở về trạng thái bình thường sau khi tín hiệu giảm xuống dưới Threshold."
                enable={enable}
                onChange={(v) => update("release", v)}
              />

              <div className="hidden lg:block" />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function InlineInput1({
  label,
  value,
  step = 1,
  min,
  max,
  unit,
  enable = true,
  onChange,
  title,
}) {
  const [display, setDisplay] = useState(value?.toString() ?? "");

  useEffect(() => {
    setDisplay(value?.toString() ?? "");
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    // cho phép trạng thái nhập trung gian
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    // nếu đang nhập dang dở thì chưa emit
    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center gap-2">
      {/* LABEL */}
      <div className="text-sm text-gray-800 w-[70px] text-right">{label}</div>

      {/* INPUT */}
      <input
        type="text"
        inputMode="decimal"
        step={step}
        value={display}
        title={title}
        disabled={!enable}
        onChange={handleChange}
        onBlur={handleBlur}
        className="
          w-[90px]
          px-2 py-[2px]
          text-sm
          text-white
          font-medium
          text-center
          rounded-md
          bg-gradient-to-b
          from-[#2eb6ed]
          to-[#071e05]
          border border-[#4e6a75]
          outline-none
        "
      />

      {/* UNIT */}
      <div className="text-sm text-gray-700 w-[40px]">{unit}</div>
    </div>
  );
}

function InlineInput2({
  label,
  value,
  min,
  max,
  unit,
  enable = true,
  onChange,
  title,
}) {
  const [display, setDisplay] = useState(value?.toString() ?? "");

  useEffect(() => {
    setDisplay(value?.toString() ?? "");
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;

    // cho phép trạng thái nhập trung gian
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    // nếu đang nhập dang dở thì chưa emit
    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center gap-2">
      {/* LABEL */}
      <div className="text-sm text-gray-800 w-[70px] text-right">{label}</div>

      {/* INPUT */}
      <input
        type="text"
        value={display}
        disabled={!enable}
        title={title}
        onChange={handleChange}
        onBlur={handleBlur}
        className="
          w-[90px]
          px-2 py-[2px]
          text-sm
          text-white
          font-medium
          text-center
          rounded-md
          bg-gradient-to-b
          from-[#2eb6ed]
          to-[#071e05]
          border border-[#4e6a75]
          outline-none
        "
      />

      {/* UNIT */}
      <div className="text-sm text-gray-700 w-[40px]">{unit}</div>
    </div>
  );
}

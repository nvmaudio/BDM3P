import { useCallback, useRef } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

/* ================= PARSE ================= */
export function parseCompander(index, buf) {
    if (!buf || buf.length < 14) return null;

    const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
    let o = 1;

    const enable = Boolean(dv.getUint8(o));

    o += 2;

    const threshold = dv.getInt16(o, true); o += 2;
    const slope_below = dv.getInt16(o, true); o += 2;
    const slope_above = dv.getInt16(o, true); o += 2;
    const alpha_attack = dv.getInt16(o, true); o += 2;
    const alpha_release = dv.getInt16(o, true); o += 2;
    const pregain = dv.getInt16(o, true);

    return {
        index,
        enable,
        threshold,
        slope_below,
        slope_above,
        alpha_attack,
        alpha_release,
        pregain,
        raw: Array.from(buf),
    };
}

/* ================= BUILD SINGLE CMD ================= */
function buildCmd(cmd, value) {
    const buf = new Uint8Array(3);
    const dv = new DataView(buf.buffer);

    buf[0] = cmd;
    dv.setInt16(1, value, true);
    return buf;
}

/* ================= BUILD FULL ================= */
export function buildCompanderPayload(data) {
    const buf = new Uint8Array(15);
    const dv = new DataView(buf.buffer);

    buf[0] = 0xff;
    dv.setUint16(1, data.enable ? 1 : 0, true);

    let o = 3;
    dv.setInt16(o, data.threshold, true); o += 2;
    dv.setInt16(o, data.slope_below, true); o += 2;
    dv.setInt16(o, data.slope_above, true); o += 2;
    dv.setInt16(o, data.alpha_attack, true); o += 2;
    dv.setInt16(o, data.alpha_release, true); o += 2;
    dv.setInt16(o, data.pregain, true);

    return buf;
}


/* ================= HOOK ================= */
export function useCOMPANDER(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore((s) => s.effect_params[index]);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);

    /* ========= ANTI FLOOD ========= */
    const debounceRef = useRef({});
    const queueRef = useRef([]);
    const sendingRef = useRef(false);

    /* ===== SEND QUEUE (40ms/packet chống reset DSP) ===== */
    const processQueue = async () => {
        if (sendingRef.current) return;
        sendingRef.current = true;

        while (queueRef.current.length > 0) {
            const pkt = queueRef.current.shift();
            sendEffect(index, pkt);
            await new Promise(r => setTimeout(r, 40)); // DSP safe delay
        }

        sendingRef.current = false;
    };

    const safeSend = (pkt) => {
        queueRef.current.push(pkt);
        processQueue();
    };

    /* ===== LOAD ===== */
    const loadCOMPANDER = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res) return null;

        const parsed = parseCompander(index, res);
        if (!parsed) return null;

        setEffectParams(index, parsed);
        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);

    /* ===== ENABLE ===== */
    const setCOMPANDEREnable = useCallback(async (enable) => {
        const cur = await loadCOMPANDER();
        if (!cur) return;

        if (cur.enable === enable) return;

        safeSend(buildCmd(0, enable ? 1 : 0));
        setEffectParams(index, { ...cur, enable });
    }, [index, loadCOMPANDER, setEffectParams]);

    /* ===== GENERIC PARAM SAFE ===== */
    const setParam = useCallback((cmd, key, value) => {
        clearTimeout(debounceRef.current[key]);
        debounceRef.current[key] = setTimeout(async () => {
            const cur = await loadCOMPANDER();
            if (!cur) return;

            if (cur[key] === value) return; // tránh spam giống nhau

            // giới hạn theo firmware C (anti crash)
            if (key === "threshold") value = Math.max(-9000, Math.min(0, value));
            if (key === "slope_below") value = Math.max(1, Math.min(10000, value));
            if (key === "slope_above") value = Math.max(1, Math.min(10000, value));
            if (key === "alpha_attack") value = Math.max(0, Math.min(32767, value));
            if (key === "alpha_release") value = Math.max(0, Math.min(32767, value));
            if (key === "pregain") value = Math.max(-7200, Math.min(1800, value));

            safeSend(buildCmd(cmd, value));
            setEffectParams(index, { ...cur, [key]: value });

        }, 120); // debounce chống spam UI
    }, [index, loadCOMPANDER, setEffectParams]);

    /* ===== FULL SEND SAFE ===== */
    const sendFull = useCallback(async (data) => {
        safeSend(buildCompanderPayload(data));
        setEffectParams(index, data);
    }, [index, setEffectParams]);

    return {
        data: params,
        loadCOMPANDER,

        setCOMPANDEREnable,
        setThreshold: (v) => setParam(1, "threshold", v),
        setSlopeBelow: (v) => setParam(2, "slope_below", v),
        setSlopeAbove: (v) => setParam(3, "slope_above", v),
        setAttack: (v) => setParam(4, "alpha_attack", v),
        setRelease: (v) => setParam(5, "alpha_release", v),
        setPregain: (v) => setParam(6, "pregain", v),

        sendFull,
    };
}

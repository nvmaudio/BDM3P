import { useEffect, useState, useCallback } from "react";
import { useDYNAMIC_EQ } from "./useDYNAMIC_EQ";

import { useEQ } from "./../EQ/useEQ";

export default function DYNAMIC_EQ({ index, name }) {
  const {
    data,
    loadDynamicEQ,
    setEnable,
    setLow,
    setNormal,
    setHigh,
    setAttack,
    setRelease,
  } = useDYNAMIC_EQ(index);

  const {
    data: data2,
    loadEQ: loadEQ2,
    setEnable: setEnable2,
  } = useEQ(index - 2);

  const {
    data: data1,
    loadEQ: loadEQ1,
    setEnable: setEnable1,
  } = useEQ(index - 1);

  const [local, setLocal] = useState({
    low: 0,
    normal: 0,
    high: 0,
    attack: 0,
    release: 0,
  });

  const [open, setOpen] = useState(false);

  /* LOAD */
  useEffect(() => {
    if (!data) {
      loadDynamicEQ();
    }
  }, [data]);

  useEffect(() => {
    if (!data1) loadEQ1();
    if (!data2) loadEQ2();

    if (data && data1 && data2) {
      if (data.enable && (!data1.enable || !data2.enable)) {
        setEnable(false);
      }
    }
  }, [data, data1, data2]);

  /* SYNC LOCAL */
  useEffect(() => {
    if (data) {
      setLocal({
        low: data.low,
        normal: data.normal,
        high: data.high,
        attack: data.attack,
        release: data.release,
      });
    }
  }, [data]);

  const enable = data?.enable ?? false;

  /* POWER */
  const togglePower = useCallback(
    async (e) => {
      e.stopPropagation();

      if (!enable) {
        if (!data1 || !data2) {
          alert("Chưa load xong EQ");
          return;
        }

        // chưa bật 2 EQ trên
        if (!data1.enable || !data2.enable) {
          alert("Phải bật 2 EQ phía trên trước");
          return;
        }
      }

      await setEnable(!enable);
    },
    [data2, data1, setEnable, enable],
  );

  /* UPDATE */
  const update = (key, v) => {
    const next = { ...local, [key]: v };
    setLocal(next);

    if (key === "low") setLow(v);
    if (key === "normal") setNormal(v);
    if (key === "high") setHigh(v);
    if (key === "attack") setAttack(v);
    if (key === "release") setRelease(v);
  };

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          {/* POWER */}
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
            ${enable ? "bg-blue-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
              ${enable ? "translate-x-4" : "translate-x-1"}`}
            />
          </button>

          {/* TITLE */}
          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`${open ? "rotate-180" : ""}`}>▾</div>
      </div>

      {/* BODY */}
      {open && (
        <div className="px-4 py-4">
          {!data && <div className="text-sm text-gray-400">Loading...</div>}

          {data && (
            <div className={`${!enable && "opacity-50"} flex flex-col gap-4`}>
              {/* ROW 1 */}
              <div className="flex flex-wrap gap-6">
                <Inline2
                  label="Low Threshold"
                  value={local.low / 100}
                  unit="dB"
                  min={-90}
                  max={0}
                  step={0.1}
                  title="Range: -90 → 0 dB. Ngưỡng mức thấp. EQ DynamicEQLP hoạt động."
                  enable={enable}
                  onChange={(v) => update("low", Math.round(v * 100))}
                />

                <Inline2
                  label="Normal Thr"
                  value={local.normal / 100}
                  unit="dB"
                  min={-90}
                  max={0}
                  step={0.1}
                  title="Range: -90 → 0 dB. Ngưỡng mức trung bình. Giữ âm thanh gốc"
                  enable={enable}
                  onChange={(v) => update("normal", Math.round(v * 100))}
                />

                <Inline2
                  label="High Thr"
                  value={local.high / 100}
                  unit="dB"
                  min={-90}
                  max={0}
                  step={0.1}
                  title="Range: -90 → 0 dB. Ngưỡng mức cao. EQ DynamicEQHP hoạt động."
                  enable={enable}
                  onChange={(v) => update("high", Math.round(v * 100))}
                />
              </div>

              {/* ROW 2 */}
              <div className="flex flex-wrap gap-6">
                <Inline
                  label="Attack"
                  value={local.attack}
                  unit="ms"
                  min={0}
                  max={2000}
                  step={1}
                  title="Range: 0 → 2000 ms. Thời gian hệ thống bắt đầu giảm gain khi tín hiệu vượt Threshold."
                  enable={enable}
                  onChange={(v) => update("attack", v)}
                />

                <Inline
                  label="Release"
                  value={local.release}
                  unit="ms"
                  min={0}
                  max={2000}
                  step={1}
                  title="Range: 0 → 2000 ms. Thời gian hệ thống trở về mức gain bình thường sau khi tín hiệu giảm xuống dưới Threshold."
                  enable={enable}
                  onChange={(v) => update("release", v)}
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Inline({
  label,
  value,
  unit,
  min,
  max,
  step = 1,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  /* Sync khi value từ ngoài đổi */
  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  /* ===== HANDLE CHANGE ===== */
  const handleChange = (e) => {
    const v = e.target.value;

    // cho phép trạng thái nhập trung gian
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    // nếu đang nhập dở thì chưa emit
    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  /* ===== HANDLE BLUR ===== */
  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center gap-2">
      <div className="text-sm w-[90px] text-right">{label}</div>

      <input
        type="text"
        inputMode="decimal"
        value={display}
        step={step}
        disabled={!enable}
        title={title}
        onChange={handleChange}
        onBlur={handleBlur}
        className="
          w-[110px] px-2 py-[4px] text-sm text-white text-center rounded-md
          bg-gradient-to-b from-[#112e3a] to-[#113a0a]
          border border-[#4e6a75] outline-none
        "
      />

      <div className="text-xs w-10">{unit}</div>
    </div>
  );
}

function Inline2({
  label,
  value,
  unit,
  min,
  max,
  step = 1,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  /* Sync khi value từ ngoài đổi */
  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  /* ===== HANDLE CHANGE ===== */
  const handleChange = (e) => {
    const v = e.target.value;

    // cho phép trạng thái nhập trung gian
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    // nếu đang nhập dở thì chưa emit
    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  /* ===== HANDLE BLUR ===== */
  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center gap-2">
      <div className="text-sm w-[90px] text-right">{label}</div>

      <input
        type="text"
        value={display}
        step={step}
        disabled={!enable}
        title={title}
        onChange={handleChange}
        onBlur={handleBlur}
        className="
          w-[110px] px-2 py-[4px] text-sm text-white text-center rounded-md
          bg-gradient-to-b from-[#112e3a] to-[#113a0a]
          border border-[#4e6a75] outline-none
        "
      />

      <div className="text-xs w-10">{unit}</div>
    </div>
  );
}

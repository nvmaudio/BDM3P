import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";

function readS16(lo, hi) {
    let v = lo | (hi << 8);
    if (v & 0x8000) v -= 0x10000;
    return v;
}

/* ================= PARSE ================= */
export function parseDynamicEQ(index, buf) {
    const enable = buf[1] === 1;

    const low = readS16(buf[3], buf[4]);
    const normal = readS16(buf[5], buf[6]);
    const high = readS16(buf[7], buf[8]);
    const attack = readS16(buf[9], buf[10]);
    const release = readS16(buf[11], buf[12]);

    return {
        index,
        enable,
        low,
        normal,
        high,
        attack,
        release,
        raw: Array.from(buf),
    };
}

/* ================= BUILD ================= */
export function buildDynamicEQPayload({
    enable,
    low,
    normal,
    high,
    attack,
    release,
}) {
    const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

    low = clamp(low, -9000, 0);
    normal = clamp(normal, -9000, 0);
    high = clamp(high, -9000, 0);
    attack = clamp(attack, 0, 2000);
    release = clamp(release, 0, 2000);

    const buf = new Uint8Array(13);
    buf[0] = 0xff;

    // enable u16
    buf[1] = enable ? 1 : 0;
    buf[2] = 0;

    const writeS16 = (v, off) => {
        if (v < 0) v += 0x10000;
        buf[off] = v & 0xff;
        buf[off + 1] = (v >> 8) & 0xff;
    };

    writeS16(low, 3);
    writeS16(normal, 5);
    writeS16(high, 7);
    writeS16(attack, 9);
    writeS16(release, 11);

    return buf;
}

/* ================= HOOK ================= */
export function useDYNAMIC_EQ(index) {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const params = useEffectStore((s) => s.effect_params[index]);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);

    /* ===== LOAD ===== */
    const loadDynamicEQ = useCallback(async () => {
        if (params) return params;

        const res = await sendAndWaitEffect(index);
        if (!res || res.length < 13) return null;

        const parsed = parseDynamicEQ(index, res);

        if (!parsed) return null;

        setEffectParams(index, parsed);
        return parsed;
    }, [index, params, sendAndWaitEffect, setEffectParams]);

    /* ===== ENABLE ===== */
    const setEnable = useCallback(
        async (enable) => {
            const cur = await loadDynamicEQ();

            const payload = buildDynamicEQPayload({
                ...cur,
                enable,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                enable,
            });
        },
        [index, loadDynamicEQ, sendEffect, setEffectParams]
    );

    /* ===== LOW ===== */
    const setLow = useCallback(
        async (value) => {
            const cur = await loadDynamicEQ();

            if (value > cur.normal) return;

            const payload = buildDynamicEQPayload({
                ...cur,
                low: value,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                low: value,
            });
        },
        [index, loadDynamicEQ, sendEffect, setEffectParams]
    );

    /* ===== NORMAL ===== */
    const setNormal = useCallback(
        async (value) => {
            const cur = await loadDynamicEQ();

            if (value > cur.high) return;
            if (value < cur.low) return;

            const payload = buildDynamicEQPayload({
                ...cur,
                normal: value,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                normal: value,
            });
        },
        [index, loadDynamicEQ, sendEffect, setEffectParams]
    );

    /* ===== HIGH ===== */
    const setHigh = useCallback(
        async (value) => {
            const cur = await loadDynamicEQ();

            if (value < cur.normal) return;

            const payload = buildDynamicEQPayload({
                ...cur,
                high: value,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                high: value,
            });
        },
        [index, loadDynamicEQ, sendEffect, setEffectParams]
    );

    /* ===== ATTACK ===== */
    const setAttack = useCallback(
        async (value) => {
            const cur = await loadDynamicEQ();

            const payload = buildDynamicEQPayload({
                ...cur,
                attack: value,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                attack: value,
            });
        },
        [index, loadDynamicEQ, sendEffect, setEffectParams]
    );

    /* ===== RELEASE ===== */
    const setRelease = useCallback(
        async (value) => {
            const cur = await loadDynamicEQ();

            const payload = buildDynamicEQPayload({
                ...cur,
                release: value,
            });

            sendEffect(index, payload);

            setEffectParams(index, {
                ...cur,
                release: value,
            });
        },
        [index, loadDynamicEQ, sendEffect, setEffectParams]
    );

    return {
        data: params,
        loadDynamicEQ,

        setEnable,
        setLow,
        setNormal,
        setHigh,
        setAttack,
        setRelease,
    };
}

import { useEffect, useState, useRef, useCallback } from "react";
import { useGain } from "./useGain";

export default function Gain({ index, name }) {
  const { data, loadGain, setGainEnable, setGainVolume } = useGain(index);

  const [open, setOpen] = useState(false);
  const [localVolume, setLocalVolume] = useState(-60);
  const debounceRef = useRef(null);

  /* ===== LOAD ===== */
  useEffect(() => {
    if (!data) loadGain();
  }, [data, loadGain]);

  /* ===== SYNC ===== */
  useEffect(() => {
    if (data) setLocalVolume(data.volume);
  }, [data]);

  const enable = data?.enable ?? false;

  /* ===== DEBOUNCE SEND ===== */
  const sendVolume = useCallback(
    (v) => {
      clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => {
        setGainVolume(v);
      }, 120);
    },
    [setGainVolume],
  );

  /* ===== EVENTS ===== */
  const togglePower = async (e) => {
    e.stopPropagation();
    await setGainEnable(!enable);
  };

  const clamp = (v) => Math.min(12, Math.max(-90, v));

  const onSliderChange = (e) => {
    const value = Number(e.target.value);
    setLocalVolume(value);
    sendVolume(value);
  };

  const onInputChange = (v) => {
    if (v === "") {
      setLocalVolume("");
      return;
    }

    const num = clamp(Number(v));
    setLocalVolume(num);
    sendVolume(num);
  };

  if (!data) {
    return <div className="p-3 text-sm text-gray-400">Loading {name}</div>;
  }

  return (
    <div className="w-full bg-gray-200 border rounded-2xl shadow-sm overflow-hidden">
      {/* HEADER */}
      <div
        className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b cursor-pointer"
        onClick={() => setOpen((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={togglePower}
            className={`w-9 h-5 flex items-center rounded-full transition
            ${enable ? "bg-blue-500" : "bg-gray-300"}`}
          >
            <div
              className={`w-4 h-4 bg-white rounded-full shadow transform transition
              ${enable ? "translate-x-4" : "translate-x-1"}`}
            />
          </button>

          <div className="text-sm font-semibold">
            {name} (0x{index.toString(16).padStart(2, "0")})
          </div>
        </div>

        <div className={`${open ? "rotate-180" : ""}`}>▾</div>
      </div>

      {/* BODY */}
      {open && (
        <div className="px-4 py-4">
          <div
            className={`
              ${!enable && "opacity-50"}
              flex flex-col gap-3
              lg:flex-row lg:items-center
            `}
          >
            {/* LABEL */}
            <div className="text-sm font-medium lg:w-[120px]">Volume 🔊</div>

            {/* SLIDER */}
            <input
              type="range"
              min={-60}
              max={12}
              step={0.1}
              value={localVolume === "" ? -60 : localVolume}
              onChange={onSliderChange}
              disabled={!enable}
              className="w-full lg:flex-1 h-2 accent-blue-500"
            />

            {/* INPUT */}
            <Inline
              value={localVolume}
              unit="dB"
              min={-90}
              max={12}
              step={0.1}
              title="Range: -90 → 12 dB."
              enable={enable}
              onChange={onInputChange}
            />
          </div>
        </div>
      )}
    </div>
  );
}

/* ================= Inline ================= */

function Inline({
  value,
  unit,
  min,
  max,
  step = 1,
  enable = true,
  title,
  onChange,
}) {
  const [display, setDisplay] = useState(
    value !== undefined && value !== null ? value.toString() : "",
  );

  useEffect(() => {
    if (value !== undefined && value !== null) {
      setDisplay(value.toString());
    }
  }, [value]);

  const handleChange = (e) => {
    const v = e.target.value;
    if (!/^[-]?\d*\.?\d*$/.test(v)) return;

    setDisplay(v);

    if (v === "" || v === "-" || v === "." || v === "-.") return;

    const num = Number(v);
    if (!isNaN(num)) onChange(num);
  };

  const handleBlur = () => {
    if (
      display === "" ||
      display === "-" ||
      display === "." ||
      display === "-."
    )
      return;

    let num = Number(display);

    if (!isNaN(min)) num = Math.max(min, num);
    if (!isNaN(max)) num = Math.min(max, num);

    setDisplay(num.toString());
    onChange(num);
  };

  return (
    <div className="flex items-center gap-2 w-full lg:w-auto">
      <input
        type="text"
        value={display}
        step={step}
        disabled={!enable}
        title={title}
        onChange={handleChange}
        onBlur={handleBlur}
        className="w-[90px] px-2 py-1 text-sm text-white font-medium text-center rounded-md bg-gradient-to-b from-[#112e3a] to-[#113a0a] border border-[#4e6a75] outline-none"
      />

      <div className="text-sm w-[40px]">{unit}</div>
    </div>
  );
}

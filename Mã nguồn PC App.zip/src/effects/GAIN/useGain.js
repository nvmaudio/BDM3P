import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";
import { useEffectStore } from "@store/useEffectStore";


// ================= PARSE =================
export function parseGain(index, buf) {

    const enable = Boolean(buf[1]);

    const mute = buf[3] | (buf[4] << 8);
    const gainRaw = buf[5] | (buf[6] << 8);
    const gainFloat = gainRaw / 4096;
    const volume = gainFloat <= 0 ? -60 : 20 * Math.log10(gainFloat);

    return {
        index,
        enable,
        mute,
        gainRaw,
        volume,
        raw: Array.from(buf),
    };
}


// ================= BUILD =================
export function buildGainPayload(p = {}) {
    const { enable = false, volume = 0 } = p;

    // ===== dB → linear =====
    const gainFloat = Math.pow(10, volume / 20);

    // ===== linear → Q12 =====
    let gainRaw = Math.round(gainFloat * 4096);

    // ===== Auto mute nếu volume quá thấp =====
    if (volume <= -60) {
        gainRaw = 0;
    }

    // ===== Clamp 16-bit =====
    gainRaw = Math.max(0, Math.min(0xffff, gainRaw));

    // ===== Mute flag =====
    const mute = gainRaw === 0 ? 1 : 0;

    const buf = new Uint8Array(7);

    buf[0] = 0xff;

    // Enable (uint16 LE)
    buf[1] = enable ? 1 : 0;
    buf[2] = 0x00;

    // Param struct (uint16 LE)
    buf[3] = mute & 0xff;
    buf[4] = (mute >> 8) & 0xff;

    buf[5] = gainRaw & 0xff;
    buf[6] = (gainRaw >> 8) & 0xff;

    return buf;
}


// ================= HOOK =================
export function useGain(index) {
    const { sendEffect, sendAndWaitEffect, } = useEffects();

    const params = useEffectStore((s) => s.effect_params[index]);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);

    // ===== LOAD =====
    const loadGain =
        useCallback(
            async () => {
                if (params) return params;
                const res = await sendAndWaitEffect(index);
                if (!res || res.length < 5) return null;
                const parsed = parseGain(index, res);
                setEffectParams(index, parsed);
                return parsed;
            },
            [
                index,
                params,
                sendAndWaitEffect,
                setEffectParams,
            ]
        );


    // ===== ENABLE =====
    const setGainEnable =
        useCallback(
            async (enable) => {
                const cur = await loadGain();
                const payload = buildGainPayload({...cur, enable});
                sendEffect(index, payload);
                setEffectParams(
                    index,
                    {
                        ...cur,
                        enable,
                    }
                );
            },
            [
                index,
                loadGain,
                sendEffect,
                setEffectParams,
            ]
        );


    // ===== VOLUME =====
    const setGainVolume =
        useCallback(
            async (volume) => {
                const cur = await loadGain();
                const payload = buildGainPayload({...cur, volume});
                sendEffect(index, payload);
                setEffectParams(
                    index,
                    {
                        ...cur,
                        volume,
                    }
                );
            },
            [
                index,
                loadGain,
                sendEffect,
                setEffectParams,
            ]
        );


    return {
        data: params,

        loadGain,

        setGainEnable,
        setGainVolume,
    };
}

import { create } from "zustand";
import { DeviceManager } from "@core/DeviceManager";

export const useEffectStore = create((set, get) => {
    const dm = DeviceManager.getInstance();

    // Reset khi disconnect
    dm.on("connectChange", ({ connected }) => {
        if (!connected) {
            set({
                effect_list: [],
                effect_params: [],
            });
        }
    });

    return {
        /* ================= META ================= */

        effect_list: [],

        setAll_Effect: (list) =>
            set(() => ({
                effect_list: list,
            })),

        /* ================= PARAM CACHE ================= */

        // cache theo index
        effect_params: {
            // [index]: { param... }
        },

        // set full param của 1 effect
        setEffectParams: (index, params) =>
            set((s) => ({
                effect_params: {
                    ...s.effect_params,
                    [index]: params,
                },
            })),

        // update 1 field param
        updateEffectParam: (index, key, value) =>
            set((s) => ({
                effect_params: {
                    ...s.effect_params,
                    [index]: {
                        ...s.effect_params[index],
                        [key]: value,
                    },
                },
            })),

        // check đã có cache chưa
        hasEffectParams: (index) => {
            return !!get().effect_params[index];
        },

        // get param
        getEffectParams: (index) => {
            return get().effect_params[index];
        },

        // clear 1 effect
        clearEffectParams: (index) =>
            set((s) => {
                const copy = { ...s.effect_params };
                delete copy[index];
                return { effect_params: copy };
            }),

        reset: () => set(() => ({
            effect_list: [],
            effect_params: {},
        })),
    };
});

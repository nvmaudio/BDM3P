import { create } from "zustand";
import { DeviceManager } from "@core/DeviceManager";

export const useDeviceStore = create((set) => {
    const dm = DeviceManager.getInstance();

    dm.on("connectChange", ({ type, connected }) => {
        if (!connected) {
            set({
                mode: connected ? type : "none",
                connected,
                connecting: false,
                data: {}
            });
        }
    });

    return {

        mode: "none",        // 'hid' | 'ble' | 'none'
        connected: false,
        connecting: false,

        setMode: (mode) => set({ mode }),
        setConnected: (connected) => set({ connected }),
        setConnecting: (connecting) => set({ connecting }),
    };
});

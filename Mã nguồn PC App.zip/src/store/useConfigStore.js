import { create } from "zustand";
import { DeviceManager } from "@core/DeviceManager";

export const useConfigStore = create((set) => {
    const dm = DeviceManager.getInstance();

    dm.on("connectChange", ({ type, connected }) => {
        if (!connected) {
            set({
                data: {}
            });
        }
    });

    return {
        data: {},

        setField: (key, value) => set((s) => ({
            data: {
                ...s.data,
                [key]: value,
            },
        })),

        setAll: (obj) => set((s) => ({
            data: {
                ...s.data,
                ...obj,
            },
        })),

        reset: () => set({
            data: {},
            connected: false,
        }),

        pushVrLog: (bytes) => set((s) => ({
            data: {
                ...s.data,
                Vr_log: bytes,
            },
        })),
    };
});
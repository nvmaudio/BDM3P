import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import { useDeviceStore } from "@store/useDeviceStore";
import { useDeviceConnection } from "@hooks/useDeviceConnection";
import { useEffects } from "@hooks/useEffects";

import StatusBar from "./StatusBar";

/* ===== LUCIDE ICONS ===== */
import {
  SlidersHorizontal,
  AudioWaveform,
  Speaker,
  Subtitles,
  Settings2,
  PlugZap,
  Bluetooth,
} from "lucide-react";

/* ================= TABS CONFIG ================= */
const tabs = [
  {
    id: "gain",
    label: "Gain đầu vào",
    icon: SlidersHorizontal,
    colorClass: "text-red-500",
  },
  {
    id: "preamp",
    label: "Preamp EQ",
    icon: AudioWaveform,
    colorClass: "text-purple-500",
  },
  {
    id: "dac0",
    label: "Đầu ra R+L",
    icon: Speaker,
    colorClass: "text-yellow-500",
  },
  {
    id: "dacx",
    label: "Đầu ra SUB",
    icon: Subtitles,
    colorClass: "text-green-500",
  },
];

/* ===== TABS ===== */
import Tab_Gain_In from "./tab/Tab_Gain_In";
import Tab_Preamp from "./tab/Tab_Preamp";
import Tab_Dac0 from "./tab/Tab_Dac0";
import Tab_dacx from "./tab/Tab_dacx";

const tabMap = {
  gain: Tab_Gain_In,
  preamp: Tab_Preamp,
  dac0: Tab_Dac0,
  dacx: Tab_dacx,
};

/* ================= UTILS ================= */
function bytesToString(bytes) {
  return String.fromCharCode(...bytes);
}

function bytesToHexString(bytes) {
  return Array.from(bytes)
    .reverse() // little endian → big endian
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
}

function hexStringToBytes(hex) {
  const bytes = [];
  for (let c = 0; c < hex.length; c += 2) {
    bytes.push(parseInt(hex.substr(c, 2), 16));
  }
  return new Uint8Array(bytes);
}

/* ================= COMPONENT ================= */
export default function Home() {
  const { mode } = useDeviceStore();
  const { connected, disconnect } = useDeviceConnection();
  const { sendAndWait, loadEffectList } = useEffects();

  const nav = useNavigate();

  const [activeTab, setActiveTab] = useState("gain");
  const [Board_name, setBoard_name] = useState("....");
  const [id, setID] = useState("....");


  useEffect(() => {
    const init = async () => {
      if (!connected) return;

      try {
        // 1. Lấy chip ID
        const payload = await sendAndWait(0x00);
        const chipId = bytesToHexString(payload);
        setID(chipId);

        const payload1 = await sendAndWait(0x01);
        setBoard_name(bytesToString(payload1));

        // 3. Activate chip
        const activateCheck = await sendAndWait(0x02);
        console.log("ACTIVATE:", activateCheck[0]);

        if (activateCheck[0] === 0) {
          const res = await fetch(
            `https://nvmaudio.id.vn/api.php?action=get_chip_info&update=2&id_chip=${chipId}`,
          );
          const data = await res.json();

          if (data.error) {
            alert(
              "Chip chưa được đăng ký! Vui lòng liên hệ admin và cung cấp ID " +
                chipId,
            );
            return;
          }

          const encHex = data.id_chip_enc_hex;
          const encBytes = hexStringToBytes(encHex);

          const activate = await sendAndWait(0x00, encBytes);
          console.log("ACTIVATE RESULT:", activate);

          if (activate?.[0] === 1) alert("Kích hoạt thành công ✅");
          else alert("Kích hoạt thất bại ❌");
        }
      } catch (e) {
        console.error(e);
      }
    };

    init();
  }, [connected, sendAndWait]);

  /* ================= DISCONNECT ================= */
  const handleDisconnect = () => {
    disconnect();
  };

  const ActiveTab = tabMap[activeTab] || (() => <p>Tab chưa có</p>);

  /* ================= UI ================= */
  return (
    <div className="w-screen h-screen bg-gradient-to-br from-slate-100 to-slate-200 text-slate-800 flex flex-col">
      {/* ================= HEADER ================= */}
      <div className="fixed top-0 left-0 w-full h-[60px] flex items-center justify-between px-6 bg-white/70 backdrop-blur-xl border-b border-slate-200 shadow-sm z-50">
        {/* LEFT */}
        <div className="flex items-center gap-4 font-semibold">
          <span className="text-lg">TOOL DSP</span>
          <span className="text-sm text-slate-500">
            {Board_name} • ID:{id}
          </span>
        </div>

        {/* RIGHT */}
        <div className="flex items-center gap-3">
          {/* STATUS */}
          <div
            className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${
              connected
                ? "bg-emerald-100 text-emerald-700"
                : "bg-rose-100 text-rose-700"
            }`}
          >
            {mode === "hid" ? <PlugZap size={16} /> : <Bluetooth size={16} />}
            <>Connected • {mode?.toUpperCase()}</>
          </div>

          {/* SETTINGS */}
          <button
            onClick={() => nav("/caidat")}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-xl shadow hover:bg-blue-600 transition"
          >
            <Settings2 size={16} />
            Cài đặt
          </button>

          {/* DISCONNECT */}
          {connected && (
            <button
              onClick={handleDisconnect}
              className="px-4 py-2 bg-rose-500 text-white rounded-xl shadow hover:bg-rose-600 transition"
            >
              Ngắt kết nối
            </button>
          )}
        </div>
      </div>

      {/* ================= BODY ================= */}
      <div className="flex flex-1 pt-[60px] overflow-hidden gap-4">
        {/* SIDEBAR */}
        <div className="w-50 py-4 pl-4 text-base flex flex-col justify-between">
          {/* MENU */}
          <div className="space-y-2">
            <div className="h-full bg-white/70 backdrop-blur-xl rounded-2xl border border-slate-200 shadow-sm p-3 space-y-2">
              {tabs.map((t) => {
                const Icon = t.icon;
                const isActive = activeTab === t.id;

                return (
                  <button
                    key={t.id}
                    disabled={!connected}
                    onClick={() => setActiveTab(t.id)}
                    className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl text-left transition ${
                      isActive
                        ? "bg-blue-500 text-white shadow"
                        : "hover:bg-slate-100"
                    } ${!connected && "opacity-40 cursor-not-allowed"}`}
                  >
                    <Icon
                      size={18}
                      className={isActive ? "text-white" : t.colorClass}
                    />
                    {t.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* STATUS BAR */}
          <StatusBar />
        </div>

        {/* CONTENT */}
        <div className="flex-1 py-4 pr-4 overflow-auto">
          <div className="bg-white/70 backdrop-blur-xl rounded-2xl border border-slate-200 shadow-sm p-6">
            <ActiveTab />
          </div>
        </div>
      </div>
    </div>
  );
}

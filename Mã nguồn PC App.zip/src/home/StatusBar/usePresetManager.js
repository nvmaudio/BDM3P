import { useCallback, useState, useMemo } from "react";
import { useEffectStore } from "@store/useEffectStore";
import { useEffects, effect_list1 } from "@hooks/useEffects";

import { buildCompanderPayload } from "../../effects/COMPANDER/useCOMPANDER";
import { buildDRCPayload } from "../../effects/DRC/useDRC";
import { buildDynamicEQPayload } from "../../effects/DYNAMIC_EQ/useDYNAMIC_EQ";
import { buildExpanderPayload } from "../../effects/EXPANDER/useEXPANDER";
import { buildEQPayload } from "../../effects/EQ/useEQ";
import { buildEQPayload1 } from "../../effects/EQ/useEQ";
import { buildGainPayload } from "../../effects/GAIN/useGain";
import { buildPCMDelayPayload } from "../../effects/PCM_DELAY/usePCM_DELAY";
import { buildPhaseControlPayload } from "../../effects/PHASE_CONTROL/usePHASE_CONTROL";
import { buildStereoWidenerPayload } from "../../effects/STEREO_WIDENER/useSTEREO_WIDENER";
import { buildThreeDPayload } from "../../effects/THREE_D/useTHREE_D";
import { buildExciterPayload } from "../../effects/EXCITER/useEXCITER";
import { buildVirtualBassPayload } from "../../effects/VIRTUAL_BASS/useVIRTUAL_BASS";
import { buildVirtualBassClassicPayload } from "../../effects/VIRTUAL_BASS_CLASSIC/useVIRTUAL_BASS_CLASSIC";

export function usePresetManager() {
    const { sendEffect } = useEffects();
    const setEffectParams = useEffectStore((s) => s.setEffectParams);
    const [loading, setLoading] = useState(false);

    // ===== normalize enable → boolean =====
    const normalizeEnableDeep = (obj) => {
        if (Array.isArray(obj)) return obj.map(normalizeEnableDeep);

        if (obj && typeof obj === "object") {
            return Object.entries(obj).reduce((acc, [key, value]) => {
                acc[key] =
                    key === "enable"
                        ? Boolean(value)
                        : normalizeEnableDeep(value);
                return acc;
            }, {});
        }

        return obj;
    };

    // ===== Builder theo TYPE =====
    const builderByType = useMemo(
        () => ({
            GAIN_CONTROL: buildGainPayload,
            EXPANDER: buildExpanderPayload,
            EQ: buildEQPayload,
            EQ1: buildEQPayload1,
            COMPANDER: buildCompanderPayload,
            VIRTUAL_BASS: buildVirtualBassPayload,
            VIRTUAL_BASS_CLASSIC: buildVirtualBassClassicPayload,
            THREE_D: buildThreeDPayload,
            EXCITER: buildExciterPayload,
            STEREO_WIDENER: buildStereoWidenerPayload,
            DYNAMIC_EQ: buildDynamicEQPayload,
            DRC: buildDRCPayload,
            PHASE_CONTROL: buildPhaseControlPayload,
            PCM_DELAY: buildPCMDelayPayload,
        }),
        []
    );

    // ===== Map cmdIndex → type =====
    const typeByCmd = useMemo(() => {
        const map = new Map();
        for (const e of effect_list1) {
            map.set(e.cmdIndex, e.type);
        }
        return map;
    }, []);

    const importPreset = useCallback(
        async (fileOrObject) => {
            try {
                setLoading(true);

                let presetData;

                if (fileOrObject instanceof File) {
                    const text = await fileOrObject.text();
                    presetData = JSON.parse(text);
                } else {
                    presetData = fileOrObject;
                }

                if (!presetData || typeof presetData !== "object") {
                    throw new Error("Invalid preset format");
                }

                const entries = Object.values(presetData);

                for (const effect of entries) {
                    if (!effect || typeof effect !== "object") continue;
                    if (typeof effect.index !== "number") continue;

                    const cmdIndex = effect.index;
                    const type = typeByCmd.get(cmdIndex);
                    if (!type) continue;

                    const builder = builderByType[type];
                    if (!builder) continue;

                    const normalized = normalizeEnableDeep(effect);

                    console.log(normalized);

                    // 1️⃣ Update store (UI cũng dùng cmdIndex)
                    setEffectParams(cmdIndex, normalized);

                    // 2️⃣ Build payload
                    const payload = builder(normalized);
                    if (!payload) continue;

                    // 3️⃣ Send firmware
                    await sendEffect(cmdIndex, payload);
                }
            } catch (err) {
                console.error("Import preset error:", err);
            } finally {
                setLoading(false);
            }
        },
        [setEffectParams, sendEffect, builderByType, typeByCmd]
    );

    return {
        importPreset,
        loading,
    };
}
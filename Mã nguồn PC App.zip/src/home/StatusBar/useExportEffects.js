import { useEffectStore } from "@store/useEffectStore";
import { useEffects, effect_list1 } from "@hooks/useEffects";

import { parseCompander } from "../../effects/COMPANDER/useCOMPANDER";
import { parseDRC } from "../../effects/DRC/useDRC";
import { parseDynamicEQ } from "../../effects/DYNAMIC_EQ/useDYNAMIC_EQ";
import { parseEQ } from "../../effects/EQ/useEQ";
import { parseEXCITER } from "../../effects/EXCITER/useEXCITER";
import { parseExpander } from "../../effects/EXPANDER/useEXPANDER";
import { parseGain } from "../../effects/GAIN/useGain";
import { parseDelay } from "../../effects/PCM_DELAY/usePCM_DELAY";
import { parsePhase } from "../../effects/PHASE_CONTROL/usePHASE_CONTROL";
import { parseStereoWidener } from "../../effects/STEREO_WIDENER/useSTEREO_WIDENER";
import { parseThreeD } from "../../effects/THREE_D/useTHREE_D";
import { parseVB } from "../../effects/VIRTUAL_BASS/useVIRTUAL_BASS";
import { parseVBClassic } from "../../effects/VIRTUAL_BASS_CLASSIC/useVIRTUAL_BASS_CLASSIC";

// ==========================
// Parser Map
// ==========================
const parserMap = {
    GAIN_CONTROL: parseGain,
    EXPANDER: parseExpander,
    EQ: parseEQ,
    EQ1: parseEQ,
    COMPANDER: parseCompander,
    VIRTUAL_BASS: parseVB,
    VIRTUAL_BASS_CLASSIC: parseVBClassic,
    THREE_D: parseThreeD,
    EXCITER: parseEXCITER,
    STEREO_WIDENER: parseStereoWidener,
    DYNAMIC_EQ: parseDynamicEQ,
    DRC: parseDRC,
    PHASE_CONTROL: parsePhase,
    PCM_DELAY: parseDelay,
};


export function useExportEffects() {
    const { sendAndWaitEffect } = useEffects();

    const effectParams = useEffectStore((s) => s.effect_params);
    const setEffectParams = useEffectStore((s) => s.setEffectParams);

    // ==========================
    // Load tất cả effect nếu chưa có
    // ==========================
    const loadAllEffects = async () => {

        for (const effect of effect_list1) {
            const { cmdIndex, type } = effect;

            const state = useEffectStore.getState();
            if (state.effect_params[cmdIndex]) continue;

            const res = await sendAndWaitEffect(cmdIndex);
            if (!res) continue;

            const parser = parserMap[type];

            if (typeof parser !== "function") {
                console.warn("Missing parser for type:", type);
                continue;
            }

            const parsed = parser(cmdIndex, res);

            setEffectParams(cmdIndex, parsed);
        }
    };


    const removeRawFieldsDeep = (obj) => {
        if (Array.isArray(obj)) {
            return obj.map(removeRawFieldsDeep);
        }

        if (obj !== null && typeof obj === "object") {
            const result = {};

            for (const key in obj) {
                // Bỏ mọi field chứa raw
                if (key.toLowerCase() === "raw") continue;

                result[key] = removeRawFieldsDeep(obj[key]);
            }

            return result;
        }

        return obj;
    };

    // ==========================
    // Export ra file JSON
    // ==========================
    const exportToFile = async () => {
        console.log("exportToFile");
        await loadAllEffects();
        console.log("loadAllEffects done");
        const data = useEffectStore.getState().effect_params;

        const cleaned = removeRawFieldsDeep(data);

        const blob = new Blob(
            [JSON.stringify(cleaned, null, 2)],
            { type: "application/json" }
        );


        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "effects_backup.json";
        a.click();
        URL.revokeObjectURL(url);
    };

    return {
        exportToFile,
    };
}
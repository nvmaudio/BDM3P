import { useCallback } from "react";
import { useEffects } from "@hooks/useEffects";

import { useEffectStore } from "@store/useEffectStore";


import { create } from "zustand";

export const useStatusStore = create((set) => ({
    CPU: null,
    SYS: null,

    setCPU: (v) => set({ CPU: v }),
    setSYS: (v) => set({ SYS: v }),
}));


const STATUS_INDEX = 0x02;


// ================= PARSE =================
function parseCPU(buf) {
    const readU16 = (lo, hi) => lo | (hi << 8);

    return {
        usedRamKB: readU16(buf[1], buf[2]),
        cpuMips: readU16(buf[3], buf[4]),
        autoRefresh: buf[5],
        cpuMaxFreqMHz: readU16(buf[6], buf[7]),
        cpuMaxRamKB: readU16(buf[8], buf[9]),

        cpuPercent: Math.round(
            (readU16(buf[3], buf[4]) /
                readU16(buf[6], buf[7])) *
            100
        ),

        raw: Array.from(buf),
    };
}

function parseSYS(buf) {
    return {
        sysMode: buf[1],        // 0 PC / 1 BT / 2 AUX
        effectMode: buf[2],     // 2..5
        volume: buf[3],
        bass: buf[4],
        mid: buf[5],
        treb: buf[6],

        raw: Array.from(buf),
    };
}


// ================= HOOK =================
export function useSTATUS() {
    const { sendEffect, sendAndWaitEffect } = useEffects();

    const CPUInfo = useStatusStore((s) => s.CPU);
    const SYSInfo = useStatusStore((s) => s.SYS);

    const setCPU = useStatusStore((s) => s.setCPU);
    const setSYS = useStatusStore((s) => s.setSYS);

    const { reset } = useEffectStore.getState();


    // ===== LOAD CPU INFO =====
    const loadCPU = useCallback(async () => {
        const res = await sendAndWaitEffect(STATUS_INDEX);
        if (!res || res.length < 10) return null;

        const parsed = parseCPU(res);
        setCPU(parsed);

        return parsed;
    }, [sendAndWaitEffect, setCPU]);


    // ===== LOAD SYS =====
    const loadSYS = useCallback(async () => {
        const res = await sendAndWaitEffect(STATUS_INDEX, [0]);
        if (!res || res.length < 7) return null;

        const parsed = parseSYS(res);

        const hasChanged = !SYSInfo || parsed.sysMode !== SYSInfo.sysMode || parsed.effectMode !== SYSInfo.effectMode;

        if (hasChanged) {
            reset();
            if (parsed) setSYS(parsed);
        } else {

        }
        return parsed;
    }, [sendAndWaitEffect, setSYS, reset, SYSInfo]);


    const save_effect = useCallback(async () => {
        await sendEffect(0xfd);
    }, [sendEffect]);


    // ===== SET MODE =====
    const setSysMode = useCallback(
        async (sysMode) => {
            const cur = SYSInfo || (await loadSYS());
            if (!cur) return;
            await sendEffect(STATUS_INDEX, [1, sysMode]);
            await setSYS({ ...cur, sysMode, });


            const block = (ms) => {
                const start = Date.now();
                while (Date.now() - start < ms) { }
            };
            block(500);

            reset();
        },
        [SYSInfo, loadSYS, sendEffect, setSYS]
    );


    // ===== SET EFFECT MODE =====
    const setEffectMode = useCallback(
        async (effectMode) => {
            const cur = SYSInfo || (await loadSYS());
            if (!cur) return;
            await sendEffect(STATUS_INDEX, [2, effectMode]);
            setSYS({ ...cur, effectMode });
            const block = (ms) => {
                const start = Date.now();
                while (Date.now() - start < ms) { }
            };
            block(500);
            reset();
        },
        [SYSInfo, loadSYS, sendEffect, setSYS]
    );


    return {
        CPUInfo,
        SYSInfo,

        loadCPU,
        loadSYS,

        setSysMode,
        setEffectMode,

        save_effect,
    };
}

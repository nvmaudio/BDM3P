import { useEffect, useRef } from "react";

import { useSTATUS } from "./StatusBar/useSTATUS";
import { useExportEffects } from "./StatusBar/useExportEffects";
import { usePresetManager } from "./StatusBar/usePresetManager";

import { Save, Upload, Download } from "lucide-react";

export const SYS_MODE_FW = {
  BT: 1, // ModeBtAudioPlay
  LINE: 4, // ModeLineAudioPlay
  USB: 5, // ModeUsbDevicePlay
};

export const SYS_MODE_LABEL = {
  1: "Bluetooth",
  4: "AUX",
  5: "PCmode",
};

export default function StatusBar() {
  const { exportToFile } = useExportEffects();
  const { importPreset, loading } = usePresetManager();

  const {
    CPUInfo,
    SYSInfo,
    loadCPU,
    loadSYS,
    setSysMode,
    setEffectMode,
    save_effect,
  } = useSTATUS();

  useEffect(() => {
    loadCPU();
    loadSYS();

    const t = setInterval(() => {
      loadCPU();
      loadSYS();
    }, 1000);

    return () => clearInterval(t);
  }, [loadCPU, loadSYS]);

  const fileRef = useRef(null);

  // ===== EXPORT =====
  const handleExport = () => {
    if (!SYSInfo) return;
    exportToFile();
  };

  // ===== IMPORT =====
  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const text = await file.text();
      const json = JSON.parse(text);

      // 1️⃣ Import effect params + send xuống DSP
      await importPreset(json);

      alert("Thêm data vào thành công. Cần lưu lại nếu ưng ý !");
    } catch (err) {
      console.error("Import preset failed", err);
      alert("Invalid preset file ❌");
    } finally {
      e.target.value = "";
    }
  };

  // ===== SAVE (force push SYSInfo -> device/store) =====
  const handleSave = async () => {
    if (!SYSInfo) return;
    save_effect();
    alert("Flash completed ✅");
  };

  const modes = [
    { label: "Bluetooth", value: SYS_MODE_FW.BT },
    { label: "AUX", value: SYS_MODE_FW.LINE },
    { label: "PCmode", value: SYS_MODE_FW.USB },
  ];

  const effects = [2, 3, 4, 5];

  const cpu = CPUInfo?.cpuPercent ?? 0;

  const activeMode = SYSInfo?.sysMode ?? 0;
  const activeEffect = SYSInfo?.effectMode ?? 3;

  return (
    <div
      className="mt-5 rounded-3xl p-4
      bg-gradient-to-br from-white/80 to-white/40
      backdrop-blur-xl border border-white/40
      shadow-[0_8px_30px_rgba(0,0,0,0.12)]
      text-sm space-y-3"
    >
      {/* PRESET BUTTONS */}
      {/* PRESET BUTTONS */}
      <div className="flex gap-2 pt-2">
        {/* SAVE */}
        <button
          onClick={handleSave}
          className="flex items-center gap-1 px-3 py-1 rounded-xl
               bg-blue-500 text-white shadow
               hover:scale-105 active:scale-95 transition"
        >
          <Save size={16} />
          Save
        </button>

        {/* IMPORT */}
        <button
          disabled={loading}
          onClick={() => fileRef.current.click()}
          className="flex items-center gap-1 px-3 py-1 rounded-xl
            bg-slate-200 hover:bg-slate-300
            active:scale-95 transition disabled:opacity-50"
        >
          <Upload size={16} />
          {loading ? "Loading..." : "Import"}
        </button>

        {/* EXPORT */}
        <button
          onClick={handleExport}
          className="flex items-center gap-1 px-3 py-1 rounded-xl
               bg-slate-200 hover:bg-slate-300
               active:scale-95 transition"
        >
          <Download size={16} />
          Export
        </button>

        <input
          ref={fileRef}
          type="file"
          accept="application/json"
          hidden
          onChange={handleImport}
        />
      </div>

      {/* MODE */}
      <div>
        <div className="font-semibold mb-1 text-slate-700">Mode</div>
        <div className="flex gap-2">
          {modes.map((m) => (
            <button
              key={m.value}
              onClick={() => setSysMode(m.value)}
              className={`px-3 py-1 rounded-xl border transition-all
                ${
                  activeMode === m.value
                    ? "bg-blue-500 text-white border-blue-500 shadow-md scale-105"
                    : "bg-white/60 hover:bg-white border-slate-200"
                }`}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* EFFECT */}
      <div>
        <div className="font-semibold mb-1 text-slate-700">Effect</div>
        <div className="flex gap-2">
          {effects.map((e) => (
            <button
              key={e}
              onClick={() => setEffectMode(e)}
              className={`px-3 py-1 rounded-xl border transition-all
                ${
                  activeEffect === e
                    ? "bg-purple-500 text-white border-purple-500 shadow-md scale-105"
                    : "bg-white/60 hover:bg-white border-slate-200"
                }`}
            >
              {e}
            </button>
          ))}
        </div>
      </div>

      {/* CPU */}
      <div>
        <div className="flex justify-between mb-1">
          <span className="font-semibold text-slate-700">CPU</span>
          <span className="font-bold">{cpu}%</span>
        </div>

        <div className="h-2 w-full bg-slate-200 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-300 ${
              cpu > 80
                ? "bg-red-500"
                : cpu > 50
                  ? "bg-yellow-500"
                  : "bg-green-500"
            }`}
            style={{ width: `${cpu}%` }}
          />
        </div>
      </div>
    </div>
  );
}

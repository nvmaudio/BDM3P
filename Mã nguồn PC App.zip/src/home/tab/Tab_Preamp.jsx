import { useState, useEffect } from "react";

import { useEffects } from "@hooks/useEffects";
import EffectRenderer from "@effects/EffectRenderer";

import { useSystemConfig } from "@hooks/useSystemConfig";

export default function Tab_Preamp() {
  const { data, loadData, onData, pushVrLog } = useSystemConfig();

  const { effect_list } = useEffects();
  const groupEffects = effect_list?.filter((e) => e.group === 1) || [];

  useEffect(() => {
    loadData();
  }, [loadData]);

  if (!data?.Pre_en) {
    return (
      <div className="mx-auto max-w-[1000px] p-2 text-base">
        <div className="flex flex-col items-center gap-3">
          <div className="w-full max-w-[900px]">
            <p className="text-gray-500">
              Chưa bật Preamp chỉnh Bass Mid Treb! Có thể mở bằng Cài đặt &gt;
              Cài đặt Nhanh
            </p>
          </div>
        </div>
      </div>
    );
  }

  const { Vr_en, Pre_en, Pre_mode, Buoc_eq, Vr_log } = data;

  return (
    <div className="mx-auto max-w-[1000px] p-2 text-base">
      {groupEffects.length === 0 ? (
        <p className="text-gray-500">Không có effect nào trong group 0.</p>
      ) : (
        <div className="flex flex-col items-center gap-3">
          {groupEffects.map((effect) => (
            <div key={effect.index} className="w-full max-w-[900px]">
              <EffectRenderer effect_data={effect} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

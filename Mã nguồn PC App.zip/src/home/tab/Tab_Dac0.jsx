import { useEffects } from "@hooks/useEffects";
import EffectRenderer from "@effects/EffectRenderer";

export default function Tab_Dac0() {
  const { effect_list } = useEffects();

  const groupEffects = effect_list?.filter((e) => e.group === 2) || [];

  return (
    <div className="mx-auto max-w-[1000px] p-2 text-base">
      {groupEffects.length === 0 ? (
        <p className="text-gray-500">Không có effect nào trong group 0.</p>
      ) : (
        <div className="flex flex-col items-center gap-3">
          {groupEffects.map((effect) => (
            <div key={effect.index} className="w-full max-w-[900px]">
              <EffectRenderer effect_data={effect} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

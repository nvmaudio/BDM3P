import { useEffect, useState, useRef, useCallback } from "react";

import { useDeviceConnection } from "@hooks/useDeviceConnection";
import { useDeviceStore } from "@store/useDeviceStore";

export default function KetNoi() {
  const { connected, connecting, connect, disconnect, sendAndWait } =
    useDeviceConnection();

  const setConnected = useDeviceStore((s) => s.setConnected);

  const [showPinModal, setShowPinModal] = useState(false);
  const [pin, setPin] = useState("");

  const [err, setErr] = useState("");
  const [fadeIn, setFadeIn] = useState(false);

  const connectingRef = useRef({ hid: false, ble: false });

  /* ================= FADE ================= */
  useEffect(() => {
    const t = setTimeout(() => setFadeIn(true), 100);
    return () => clearTimeout(t);
  }, []);

  /* ================= ACTIONS ================= */
  const handleHidConnect = async () => {
    if (connectingRef.current.hid) return;

    connectingRef.current.hid = true;
    setErr("");

    try {
      const ok = await connect("hid");

      if (!ok) setErr("Không tìm thấy HID hoặc connect thất bại");
    } catch (e) {
      console.error(e);
      setErr("Lỗi khi kết nối HID");
    }

    connectingRef.current.hid = false;
  };

  const handleBleConnect = async () => {
    if (connectingRef.current.ble) return;

    connectingRef.current.ble = true;
    setErr("");

    try {
      const ok = await connect("ble");
      if (!ok) {
        setErr("Không tìm thấy BLE hoặc connect thất bại");
      } else {
        setShowPinModal(true); // mở modal nhập PIN
      }
    } catch (e) {
      console.error(e);
      setErr("Lỗi khi kết nối BLE");
    }

    connectingRef.current.ble = false;
  };

  const handleSubmitPin = useCallback(async () => {
    console.log(pin.length, pin);
    if (pin.length !== 4) return;

    const encoder = new TextEncoder();
    const pinBytes = encoder.encode(pin);

    const oke = await sendAndWait(202, pinBytes);

    if (oke[0] == 1) {
      setPin("");
      setShowPinModal(false);
      setConnected(true);
    } else {
      setShowPinModal(false);
      disconnect();
      setErr("Sai mật khẩu!");
      setPin("");
    }
  }, [sendAndWait,pin]);

  /* ================= HIDE ================= */
  if (connected) return null;

  /* ================= UI (GIỮ NGUYÊN) ================= */
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-gradient-to-br from-purple-200 via-pink-100 to-indigo-100">
      {showPinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="w-[320px] rounded-2xl bg-white p-6 shadow-2xl">
            <div className="mb-4 text-lg font-semibold text-center">
              Nhập mật khẩu 4 số
            </div>

            <input
              type="password"
              inputMode="numeric"
              maxLength={4}
              value={pin}
              onChange={(e) => {
                const v = e.target.value.replace(/\D/g, "");
                setPin(v);
              }}
              className="w-full rounded-lg border p-3 text-center text-2xl tracking-widest"
              autoFocus
            />

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => {
                  setShowPinModal(false);
                  disconnect();
                }}
                className="flex-1 rounded-lg bg-gray-200 py-2"
              >
                Hủy
              </button>

              <button
                onClick={handleSubmitPin}
                className="flex-1 rounded-lg bg-indigo-600 py-2 text-white"
              >
                Xác nhận
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating glow blobs */}
      <div className="animate-blob1 absolute left-[-250px] top-[-250px] h-[700px] w-[700px] rounded-full bg-purple-400/30 blur-[180px]" />
      <div className="animate-blob2 absolute bottom-[-250px] right-[-250px] h-[600px] w-[600px] rounded-full bg-indigo-400/30 blur-[180px]" />
      <div className="animate-blob3 absolute left-[50%] top-[50%] h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-pink-300/20 blur-[200px]" />

      {/* Main glass container */}
      <div
        className={`will-change-transform,opacity relative z-10 flex transform flex-col items-center rounded-[40px] border border-white/30 bg-white/50 px-20 py-12 shadow-[0_40px_120px_rgba(0,0,0,0.15)] backdrop-blur-3xl transition-all duration-1000 ${
          fadeIn ? "scale-100 opacity-100" : "scale-90 opacity-0"
        }`}
      >
        {/* LOGO */}
        <div className="flex items-center gap-16">
          <img
            src="/img/logo/ant.png"
            className="w-32 opacity-90 drop-shadow-xl transition duration-500 hover:scale-110 md:w-36"
          />
          <div className="h-20 w-[3px] animate-pulse bg-gradient-to-b from-transparent via-gray-300 to-transparent" />
          <img
            src="/img/logo/nvm.png"
            className="w-40 opacity-90 drop-shadow-xl transition duration-500 hover:scale-110 md:w-44"
          />
        </div>

        {/* TITLE */}
        <div className="mb-2 text-3xl font-extrabold tracking-wide text-white drop-shadow-lg">
          NVM AUDIO FACTORY TOOL
        </div>
        <div className="mb-12 text-sm text-gray-500">Quản lý Kết nối</div>

        {/* BUTTONS */}
        <div
          className={`flex gap-8 opacity-0 ${fadeIn ? "animate-buttons-fade" : ""} will-change-opacity`}
        >
          {/* USB HID */}
          <button
            onClick={handleHidConnect}
            disabled={connecting}
            className={`group relative transform overflow-hidden rounded-2xl border border-white/60 bg-white/70 px-12 py-5 shadow-lg backdrop-blur-xl transition duration-300 will-change-transform before:absolute before:inset-0 before:bg-gradient-to-r before:from-blue-400/0 before:via-blue-400/20 before:to-blue-400/0 before:opacity-0 before:blur-xl before:transition-opacity before:duration-500 hover:scale-105 group-hover:before:opacity-100 
              ${
                connectingRef.current.hid
                  ? "cursor-not-allowed opacity-40 hover:scale-100"
                  : "cursor-pointer"
              }`}
          >
            <span className="relative text-lg font-semibold text-gray-800">
              {connectingRef.current.hid ? "Đang kết nối..." : "USB (Cable)"}
            </span>
          </button>

          {/* BLE */}
          <button
            onClick={handleBleConnect}
            className={`group relative transform overflow-hidden rounded-2xl bg-gradient-to-br from-purple-500 to-indigo-600 px-12 py-5 text-lg font-semibold text-white shadow-2xl transition duration-300 will-change-transform before:absolute before:inset-0 before:bg-white/20 before:opacity-0 before:blur-xl before:transition-opacity before:duration-500 hover:scale-105 group-hover:before:opacity-100
             ${
               connectingRef.current.hid
                 ? "cursor-not-allowed opacity-40 hover:scale-100"
                 : "cursor-pointer"
             }`}
          >
            <span className="relative text-lg font-semibold text-gray-800">
              {connectingRef.current.ble ? "Đang kết nối..." : "BLE (Wireless)"}
            </span>
          </button>
        </div>

        {/* ERROR */}
        {err && <div className="mt-6 text-sm text-red-500">{err}</div>}

        {/* FOOTER */}
        <div className="mt-14 text-sm tracking-widest text-gray-400">
          ANT × NVM Factory Tool v4.0
        </div>
      </div>

      {/* ANIMATION */}
      <style>{`
        @keyframes blob1 {
          0%,100%{transform:translate(0,0) scale(1);}
          33%{transform:translate(30px,-50px) scale(1.1);}
          66%{transform:translate(-20px,20px) scale(0.9);}
        }
        @keyframes blob2 {
          0%,100%{transform:translate(0,0) scale(1);}
          33%{transform:translate(-40px,20px) scale(1.1);}
          66%{transform:translate(20px,-30px) scale(0.9);}
        }
        @keyframes blob3 {
          0%,100%{transform:translate(0,0) scale(1);}
          33%{transform:translate(50px,30px) scale(1.1);}
          66%{transform:translate(-30px,-20px) scale(0.9);}
        }

        .animate-blob1 {animation: blob1 8s infinite ease-in-out;}
        .animate-blob2 {animation: blob2 10s infinite ease-in-out;}
        .animate-blob3 {animation: blob3 12s infinite ease-in-out;}

        @keyframes buttons-fade {
          from {opacity:0;}
          to {opacity:1;}
        }
        .animate-buttons-fade {
          animation: buttons-fade 0.7s forwards;
          animation-delay: 0.4s;
        }
      `}</style>
    </div>
  );
}

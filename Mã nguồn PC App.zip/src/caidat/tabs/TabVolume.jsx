import { useSystemConfig } from "@hooks/useSystemConfig";

export default function TabVolume() {
  const { data, update, save } = useSystemConfig();

  if (!data) {
    return <div className="flex justify-start">loading</div>;
  }

  const { Volume_tong, Nho_volume, Dongbo_volume, Key_en, Vr_en } = data;

  const onChangeNhoVolume = (v) => {
    if (v) {
      update("Nho_volume", 1);
      update("Dongbo_volume", 0);
    } else {
      update("Nho_volume", 0);
    }
  };

  const onChangeDongBo = (v) => {
    if (v) {
      update("Dongbo_volume", 1);
      update("Nho_volume", 0);
    } else {
      update("Dongbo_volume", 0);
    }
  };

  const rangeClass =
    "w-full h-2 cursor-pointer rounded-lg bg-gray-200 accent-blue-600";

  return (
    <div className="mx-auto max-w-[1000px] space-y-3 p-2 text-base">
      {/* TITLE */}
      <h2 className="text-2xl font-bold text-gray-800 drop-shadow-sm">
        Cấu hình Volume
      </h2>

      {/* CARD */}
      <div className="divide-y divide-gray-300 overflow-hidden rounded-2xl border border-gray-200 bg-gradient-to-br from-white to-gray-50 shadow-2xl">
        {/* VOLUME TỔNG */}
        <FormRow label="Volume tổng">
          <input
            type="range"
            min={0}
            max={16}
            value={Volume_tong}
            onChange={(e) => update("Volume_tong", Number(e.target.value))}
            className={rangeClass}
            title={`Điều chỉnh âm lượng tổng: ${Volume_tong}`}
          />
          <span className="ml-3 w-6 text-sm text-gray-700">{Volume_tong}</span>
        </FormRow>

        {/* NHỚ VOLUME */}
        <FormRow
          label="Nhớ volume"
          title="Nhớ volume khi tắt/mở thiết bị, chỉ hoạt động khi phím bấm bật và tắt Biến trở"
        >
          <Switch
            checked={Nho_volume === 1}
            onChange={onChangeNhoVolume}
            disabled={Key_en === 0 && Vr_en === 1}
            title="Nhớ volume khi tắt/mở thiết bị, chỉ hoạt động khi phím bấm bật và tắt Biến trở"
          />
        </FormRow>

        {/* ĐỒNG BỘ VOLUME BLUETOOTH */}
        <FormRow
          label="Đồng bộ volume Bluetooth"
          title="Đồng bộ volume với thiết bị Bluetooth chỉ hoạt động khi tắt Biến trở"
        >
          <Switch
            checked={Dongbo_volume === 1}
            onChange={onChangeDongBo}
            disabled={Vr_en === 1}
            title="Đồng bộ volume với thiết bị Bluetooth chỉ hoạt động khi tắt Biến trở"
          />
        </FormRow>
      </div>

      {/* SAVE BUTTON */}
      <button
        onClick={save}
        className="transform rounded-2xl bg-gradient-to-r from-blue-500 to-blue-600 px-6 py-2 font-medium text-white shadow-lg transition hover:scale-105 hover:shadow-xl"
      >
        Lưu cấu hình
      </button>
    </div>
  );
}

/* ================= ROW ================= */
function FormRow({ label, children, title }) {
  return (
    <div className="grid grid-cols-1 items-center gap-4 px-5 py-4 md:grid-cols-2">
      <div className="font-medium text-gray-700" title={title}>
        {label}
      </div>
      <div className="flex items-center justify-start gap-2">{children}</div>
    </div>
  );
}

/* ================= SWITCH ================= */
function Switch({ checked, onChange, disabled, title }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      title={title}
      className={`flex h-6 w-12 items-center rounded-full p-0.5 transition ${
        checked ? "bg-blue-600" : "bg-slate-300"
      }`}
    >
      <div
        className={`h-5 w-5 rounded-full bg-white shadow transition ${
          checked ? "translate-x-5" : ""
        }`}
      />
    </button>
  );
}

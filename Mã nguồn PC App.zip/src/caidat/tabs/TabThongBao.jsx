import { useSystemConfig } from "@hooks/useSystemConfig";

const NOTIFY_ITEMS = [
  "BT mode",
  "AUX mode",
  "PC mode",
  "Connect",
  "Disconnect",
  "TWS Connect",
  "Vol max",
  "BT Pair",
];

export default function TabThongBao() {
  const { data, update, save } = useSystemConfig();

  if (!data) {
    return <div className="p-6 text-gray-500">Loading...</div>;
  }

  const setItemField = (index, value) => {
    const newItems = [...data.Item_thong_bao];
    newItems[index] = value ? 1 : 0;
    update("Item_thong_bao", newItems);
  };

  return (
    <div className="mx-auto max-w-[1000px] space-y-4 p-4">
      {/* ===== TITLE ===== */}
      <h2 className="text-xl font-semibold text-gray-800">
        Cấu hình Thông báo
      </h2>

      {/* ===== MAIN CARD ===== */}
      <div className="rounded-3xl border border-gray-200 bg-white/80 backdrop-blur shadow-xl">
        {/* ===== ENABLE ===== */}
        <RowWin11 label="Bật nhạc thông báo">
          <Switch
            checked={data.Thong_bao_en === 1}
            onChange={(v) => update("Thong_bao_en", v ? 1 : 0)}
          />
        </RowWin11>

        {/* ===== VOLUME ===== */}
        <RowWin11 label="Volume thông báo">
          <div className="flex w-full items-center gap-3">
            <input
              type="range"
              min={0}
              max={16}
              value={data.Volume_thong_bao}
              onChange={(e) =>
                update("Volume_thong_bao", Number(e.target.value))
              }
              disabled={data.Thong_bao_en === 0}
              className="h-2 w-full cursor-pointer rounded-lg bg-gray-200 accent-blue-600"
            />
            <span className="w-8 text-sm text-gray-700">
              {data.Volume_thong_bao}
            </span>
          </div>
        </RowWin11>

        {/* ===== LIST ===== */}
        <div className="border-t border-gray-200 p-4">
          <div className="mb-3 text-sm font-medium text-gray-600">
            Danh sách âm báo
          </div>

          {/* ===== GRID 2 COL ===== */}
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {NOTIFY_ITEMS.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between rounded-xl border border-gray-200 bg-white px-4 py-2 shadow-sm hover:bg-gray-50"
              >
                <span className="text-sm text-gray-700">{item}</span>

                <Switch
                  checked={data.Item_thong_bao[idx] === 1}
                  onChange={(v) => setItemField(idx, v)}
                  disabled={data.Thong_bao_en === 0}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ===== ACTION ===== */}
      <div className="flex justify-end">
        <button
          onClick={save}
          className="rounded-xl bg-blue-600 px-6 py-2 text-white shadow hover:bg-blue-700 active:scale-95 transition"
        >
          Lưu cấu hình
        </button>
      </div>
    </div>
  );
}

/* ================= ROW ================= */
function RowWin11({ label, children }) {
  return (
    <div className="grid grid-cols-1 items-center gap-4 border-b border-gray-200 px-6 py-5 md:grid-cols-2">
      <div className="text-sm font-medium text-gray-700">{label}</div>
      <div className="flex items-center gap-2">{children}</div>
    </div>
  );
}

/* ================= SWITCH ================= */
function Switch({ checked, onChange, disabled }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`flex h-6 w-12 items-center rounded-full p-0.5 transition
        ${checked ? "bg-blue-600" : "bg-gray-300"}
        ${disabled ? "cursor-not-allowed opacity-40" : "cursor-pointer"}
      `}
    >
      <div
        className={`h-5 w-5 rounded-full bg-white shadow transition
          ${checked ? "translate-x-6" : ""}
        `}
      />
    </button>
  );
}

import { useSystemConfig } from "@hooks/useSystemConfig";

const selectKey = [
  { value: "0", text: "NONE" },
  { value: "1", text: "PLAY_PAUSE" },
  { value: "2", text: "PRE" },
  { value: "3", text: "NEXT" },
  { value: "4", text: "MUSIC_VOLUP" },
  { value: "5", text: "MUSIC_VOLDOWN" },
  { value: "6", text: "3D" },
  { value: "7", text: "VB_DAC0" },
  { value: "8", text: "VB_Classic_DAC0" },
  { value: "9", text: "VB_DACX" },
  { value: "10", text: "VB_Classic_DACX" },
  { value: "11", text: "EFFECTMODE" },
  { value: "12", text: "MODE" },
  { value: "13", text: "BT_PAIRING" },
  { value: "14", text: "BT_PAIRING_CLEAR_DATA" },
  { value: "15", text: "BT_CLEAR_BT_LIST" },
  { value: "16", text: "BT_TWS_PAIRING" },
  { value: "17", text: "BT_TWS_CLEAR_LIST" },
  { value: "18", text: "MUTE_ON_OFF" },
];

// Chỉ lấy những row cần hiển thị
const Item_index = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

export default function TabKey() {
  const { data, update, save } = useSystemConfig();

  if (!data) {
    return <div className="flex justify-start">loading</div>;
  }

  const { Key_matrix, Key_en } = data;

  // Update trực tiếp Key_matrix
  const updateItem = (rowIndex, colIndex, value) => {
    update("Key_matrix", (prev) =>
      prev.map((row, ri) =>
        ri === rowIndex
          ? row.map((col, ci) => (ci === colIndex ? Number(value) : col))
          : row,
      ),
    );
  };

  const resetDefault = () => {
    const newMatrix = [
      [0, 12, 16, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 11, 7, 0, 0],
      [0, 2, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 3, 0, 0, 0],
      [0, 1, 14, 0, 0],
    ];
    update("Key_matrix", newMatrix);
  };

  const resetDefaultWithVol = () => {
    const newMatrix = [
      [0, 12, 16, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 11, 7, 0, 0],
      [0, 2, 5, 5, 5],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0],
      [0, 3, 4, 4, 4],
      [0, 1, 14, 0, 0],
    ];
    update("Key_matrix", newMatrix);
  };

  return (
    <div className="h-full max-w-[1000px] space-y-3 p-2 text-base mx-auto">
      <h2 className="text-xl font-bold text-gray-800 drop-shadow-sm mb-4">
        Cấu hình Phím Bấm
      </h2>

      <div className="flex flex-col h-[calc(100%-4rem)] divide-y divide-gray-300 rounded-2xl border border-gray-200 bg-gradient-to-br from-white to-gray-50 shadow-2xl overflow-hidden">
        {/* Scrollable content */}
        <div className="flex-1 overflow-auto p-6 space-y-6">
          {/* Bật/Tắt Key */}
          <div className="flex items-center gap-3">
            <span className="font-medium text-gray-700">Phím Bấm</span>
            <Switch
              checked={Key_en === 1}
              onChange={(v) => update("Key_en", v ? 1 : 0)}
              title="Chỉ thay đổi được ở Cài đặt nhanh!"
              disabled
            />
            <span className="text-gray-700">{Key_en ? "Bật" : "Tắt"}</span>
          </div>

          {/* Table Key */}
          <div className="overflow-x-auto rounded-lg border">
            <table className="min-w-full border-collapse border border-gray-300 text-center text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="border px-2 py-1">Số Key</th>
                  <th className="border px-2 py-1">Nhấn Nhả</th>
                  <th className="border px-2 py-1">Nhấn giữ</th>
                  <th className="border px-2 py-1">Vẫn giữ</th>
                  <th className="border px-2 py-1">Nhả giữ</th>
                </tr>
              </thead>
              <tbody>
                {Item_index.map((rowIndex, keyIdx) => {
                  const row = Key_matrix[rowIndex] || [];
                  return (
                    <tr
                      key={rowIndex}
                      className="transition even:bg-gray-50 hover:bg-gray-100"
                    >
                      <td className="border px-2 py-1">{`Key ${keyIdx + 1}`}</td>
                      {row.slice(1).map((col, ci) => (
                        <td key={ci} className="border px-2 py-1">
                          <select
                            value={col}
                            onChange={(e) =>
                              updateItem(rowIndex, ci + 1, e.target.value)
                            }
                            disabled={Key_en === 0}
                            className="w-full rounded border px-1 py-0.5 text-sm focus:outline-none focus:ring-1 focus:ring-blue-400"
                            style={{ color: col === 0 ? "black" : "#0033cc" }}
                          >
                            {selectKey.map((opt) => (
                              <option key={opt.value} value={opt.value}>
                                {opt.text}
                              </option>
                            ))}
                          </select>
                        </td>
                      ))}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex justify-center gap-3 py-4 bg-gray-50 border-t border-gray-200">
          <button
            onClick={save}
            className="rounded-lg bg-green-600 px-4 py-2 text-white hover:bg-green-700"
          >
            Lưu Lại
          </button>
          <button
            onClick={resetDefault}
            className="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
          >
            Về mặc định
          </button>
          <button
            onClick={resetDefaultWithVol}
            className="rounded-lg bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700"
          >
            Về mặc định (Có dùng VOLUP/VOLDOWN)
          </button>
        </div>
      </div>
    </div>
  );
}

/* ================= SWITCH ================= */
function Switch({ checked, onChange, disabled, title }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`flex h-5 w-10 items-center rounded-full p-0.5 transition ${
        checked ? "bg-blue-600" : "bg-slate-300"
      } ${disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"}`}
      title={title}
    >
      <div
        className={`h-4 w-4 rounded-full bg-white shadow transition-transform ${
          checked ? "translate-x-5" : ""
        }`}
      />
    </button>
  );
}

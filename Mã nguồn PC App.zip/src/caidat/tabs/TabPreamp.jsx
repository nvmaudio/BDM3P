import { useSystemConfig } from "@hooks/useSystemConfig";

export default function TabPreamp() {
  const { data, update, save } = useSystemConfig();

  if (!data) {
    return <div className="flex justify-start">loading</div>;
  }

  const { Vr_en, Pre_en, Pre_mode, Buoc_eq, Vr_log } = data;

  return (
    <div className="mx-auto max-w-[1000px] space-y-3 p-2 text-base">
      <h2 className="mt-0 text-md font-bold text-gray-800 drop-shadow-sm">
        Cấu hình Preamp + Biến Trở
      </h2>

      {/* Bảng giá trị hiện tại */}
      <div className="mt-2 rounded-lg border">
        <table className="min-w-full border-collapse border border-gray-300 text-center text-sm">
          <thead className="bg-gray-100">
            <tr>
              <th className="border px-2 py-1">Tên Biến Trở / Preamp</th>
              <th className="border px-2 py-1">Chức năng</th>
              <th className="border px-2 py-1">Giá trị hiện tại</th>
            </tr>
          </thead>
          <tbody>
            <tr className="even:bg-gray-50">
              <td className="border px-2 py-1">VOLUME</td>
              <td className="border px-2 py-1">
                Điều chỉnh âm lượng tổng
                {Pre_mode === 1 ? " ( Biến Trở )" : " (App + Key)"}
              </td>
              <td className="border px-2 py-1">{Vr_log[0]}</td>
            </tr>

            <tr className="even:bg-gray-50">
              <td className="border px-2 py-1">Bass</td>
              <td className="border px-2 py-1">
                Điều chỉnh âm lượng giải tần thấp{" "}
                {Pre_mode === 1 ? "( Biến Trở )" : "(App)"}
              </td>
              <td className="border px-2 py-1">{Vr_log[1]}</td>
            </tr>

            <tr className="even:bg-gray-50">
              <td className="border px-2 py-1">MID</td>
              <td className="border px-2 py-1">
                Điều chỉnh âm lượng giải tần trung{" "}
                {Pre_mode === 1 ? "( Biến Trở )" : "(App)"}
              </td>
              <td className="border px-2 py-1">{Vr_log[2]}</td>
            </tr>

            <tr className="even:bg-gray-50">
              <td className="border px-2 py-1">Treble</td>
              <td className="border px-2 py-1">
                Điều chỉnh âm lượng giải tần cao{" "}
                {Pre_mode === 1 ? "( Biến Trở )" : "(App)"}
              </td>
              <td className="border px-2 py-1">{Vr_log[3]}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Enable Biến Trở */}
      <div className="mt-4 flex items-center gap-3">
        <span className="font-medium text-gray-700">Biến Trở</span>
        <Switch
          checked={Vr_en === 1}
          onChange={(v) => update("Vr_en", v ? 1 : 0)}
          disabled
          title="Chỉ thay đổi được ở Cài đặt nhanh!"
        />
        <span className="text-gray-700">{Vr_en === 1 ? "Bật" : "Tắt"}</span>
      </div>

      {/* Enable Preamp */}
      <div className="mt-4 flex items-center gap-3">
        <span className="font-medium text-gray-700">Preamp</span>
        <Switch
          checked={Pre_en === 1}
          onChange={(v) => update("Pre_en", v ? 1 : 0)}
          disabled
          title="Chỉ thay đổi được ở Cài đặt nhanh!"
        />
        <span className="text-gray-700">{Pre_en === 1 ? "Bật" : "Tắt"}</span>
      </div>

      {/* Preamp mode */}
      <div className="mt-4 flex items-center gap-3">
        <label className="w-48 text-gray-700">Chọn Preamp mode</label>
        <select
          value={Pre_mode}
          onChange={(e) => update("Pre_mode", Number(e.target.value))}
          disabled={Pre_en === 0}
          className={`flex-1 rounded border px-2 py-1 text-sm focus:outline-none focus:ring-1 ${
            Pre_en === 0
              ? "cursor-not-allowed border-gray-300 bg-gray-100 text-gray-400"
              : "border-blue-400 bg-white text-blue-700 focus:ring-blue-400"
          } `}
        >
          <option value={0}>Điều chỉnh bằng APP + Key</option>
          <option disabled={Vr_en === 0} value={1}>
            Điều chỉnh bằng Biến trở
          </option>
        </select>
      </div>

      {/* Độ lớn thay đổi */}
      <div className="mt-2 flex items-center gap-3">
        <label className="w-48 text-gray-700">Độ lớn thay đổi</label>
        <input
          type="number"
          value={Buoc_eq}
          onChange={(e) => update("Buoc_eq", Number(e.target.value))}
          disabled={Pre_en === 0}
          min={3}
          max={10}
          step={1}
          className="flex-1 rounded border px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-400"
        />
      </div>

      {/* Button lưu */}
      <div className="mt-4 flex justify-center">
        <button
          onClick={save}
          className="rounded-lg bg-green-600 px-4 py-2 text-white hover:bg-green-700"
        >
          Lưu Lại
        </button>
      </div>

      {/* Ghi chú khách hàng */}
      <div className="mt-4 rounded border bg-gray-50 p-3 text-sm">
        <p className="mb-1 font-semibold">Ghi chú:</p>
        <ul className="list-disc pl-5">
          <li>
            <em className="text-blue-500">Biến trở</em> chỉnh được: Volume tổng
            + Preamp (Bass, Mid, Treble) khi chọn Preamp là Biến trở Bass, Mid,
            Treble.
          </li>
          <li>
            <em className="text-blue-500">App</em> có thể chỉnh được: Preamp
            (Bass, Mid, Treble) , có thể chỉnh Volume khi không dùng Biến trở
          </li>
          <li>
            <em className="text-blue-500">Preamp</em> Chỉnh{" "}
            <em className="text-red-500">tần số</em> và{" "}
            <em className="text-red-500"> độ cắt </em> ở tab Preamp trong Hiệu
            ứng âm thanh
          </li>
        </ul>
      </div>
    </div>
  );
}

/* ================= SWITCH ================= */
function Switch({ checked, onChange, disabled, title }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`flex h-5 w-10 items-center rounded-full p-0.5 transition ${
        checked ? "bg-blue-600" : "bg-slate-300"
      } ${disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"}`}
      title={title}
    >
      <div
        className={`h-4 w-4 rounded-full bg-white shadow transition ${
          checked ? "translate-x-5" : ""
        }`}
      />
    </button>
  );
}

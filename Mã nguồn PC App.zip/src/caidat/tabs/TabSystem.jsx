import { Music2, Zap, Sliders, CheckCircle2 } from "lucide-react";
import { useState } from "react";

import { useSystemConfig } from "@hooks/useSystemConfig";

export default function TabSystem() {
  const [step, setStep] = useState(1);

  const { data, update, save } = useSystemConfig();

  if (!data) {
    return <div className="flex justify-start">loading</div>;
  }

  const steps = [
    { id: 1, label: "Audio Class", icon: Music2, color: "blue" },
    { id: 2, label: "Phím Bấm", icon: Zap, color: "amber" },
    { id: 3, label: "Biến trở", icon: Zap, color: "vr" },
    { id: 4, label: "Preamp điều chỉnh", icon: Sliders, color: "purple" },
    { id: 5, label: "Hoàn tất", icon: CheckCircle2, color: "emerald" },
  ];

  const AUDIO_MODES = [
    { value: 0, title: "2.0 Stereo", note: "Loa trái và phải R/L" },
    { value: 1, title: "2.1 Subwoofer", note: "L + R + Sub" },
    { value: 2, title: "Mono", note: "2 loa cùng tín hiệu R = L" },
    { value: 3, title: "1.1", note: "Mono EQ riêng R / L" },
    { value: 4, title: "3 Way", note: "EQ riêng R / L / Sub" },
  ];

  const PREAMP_MODES = [
    { value: 0, code: "APP", title: "App", note: "Điều chỉnh bằng Mobile App" },
    { value: 1, code: "VR", title: "VR", note: "Điều chỉnh bằng biến trở" },
  ];

  const getAudioMode = () =>
    AUDIO_MODES.find((x) => x.value === data.Audio_mode);
  const getPreampMode = () =>
    PREAMP_MODES.find((x) => x.value === data.Pre_mode);

  const next = () => setStep((s) => Math.min(s + 1, steps.length));
  const back = () => setStep((s) => Math.max(s - 1, 1));

  const finish = async () => {
    if (data.Vr_en === 1) {
      await update("Dongbo_volume", 0);
      await update("Nho_volume", 0);
    } else {
      await update("Pre_mode", 0);
    }
    if (data.Key_en === 0) {
      await update("Nho_volume", 0);
    }
    await save();
  };

  /* ===============================COLOR MAP=============================== */
  const colorMap = (color, active) => {
    const colors = {
      blue: {
        active: "bg-blue-600 text-white border-blue-600",
        inactive: "bg-blue-50 text-blue-600 border-blue-200",
      },
      amber: {
        active: "bg-amber-500 text-white border-amber-500",
        inactive: "bg-amber-50 text-amber-600 border-amber-200",
      },
      vr: {
        active: "bg-orange-300 text-white border-orange-600",
        inactive: "bg-orange-50 text-orange-600 border-orange-200",
      },
      purple: {
        active: "bg-purple-600 text-white border-purple-600",
        inactive: "bg-purple-50 text-purple-600 border-purple-200",
      },
      emerald: {
        active: "bg-emerald-600 text-white border-emerald-600",
        inactive: "bg-emerald-50 text-emerald-600 border-emerald-200",
      },
    };
    if (!colors[color]) return "";
    return active ? colors[color].active : colors[color].inactive;
  };

  /* ===============================UI =============================== */
  return (
    <div className="space-y-6 p-4 ">
      <div
        className="grid gap-4 max-w-[1000px] mx-auto"
        style={{ gridTemplateColumns: `repeat(${steps.length},1fr)` }}
      >
        {steps.map((s) => {
          const Icon = s.icon;
          const active = step === s.id;
          return (
            <div
              key={s.id}
              className={`flex flex-col items-center gap-2 rounded-xl border p-3 text-sm font-medium transition ${colorMap(s.color, active)}`}
            >
              <Icon size={18} />
              {s.label}
            </div>
          );
        })}
      </div>

      <div className="min-h-[260px] max-w-[1000px] mx-auto rounded-2xl border bg-white p-6 shadow-sm">
        {/* STEP 1: AUDIO */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="font-medium">Chọn chế độ âm thanh</div>
            <div className="grid grid-cols-[repeat(auto-fit,minmax(150px,200px))] gap-3">
              {AUDIO_MODES.map((m) => {
                const active = data.Audio_mode === m.value;
                return (
                  <button
                    key={m.value}
                    onClick={() => update("Audio_mode", m.value)}
                    className={`rounded-2xl border p-4 text-left transition ${active ? "border-blue-600 bg-blue-600 text-white shadow" : "bg-gray-50 hover:bg-gray-100"}`}
                  >
                    <div className="font-medium">{m.title}</div>
                    <div
                      className={`text-sm ${active ? "text-blue-100" : "text-gray-500"}`}
                    >
                      {m.note}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* STEP 2: KEY */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="font-medium">Có sử dụng phím bấm vật lý không?</div>
            <button
              onClick={() => update("Key_en", data.Key_en ? 0 : 1)}
              className={`flex w-full items-center justify-between rounded-xl border p-4 transition ${data.Key_en ? "border-amber-500 bg-amber-50" : "bg-gray-50"}`}
            >
              <div className="flex items-center gap-3">
                <Zap
                  className={data.Key_en ? "text-amber-600" : "text-gray-400"}
                />
                <div>
                  <div className="font-medium">Phím bấm</div>
                  <div className="text-xs text-gray-500">
                    Điều khiển bằng nút vật lý
                  </div>
                </div>
              </div>
              <div
                className={`h-6 w-11 rounded-full p-1 transition ${data.Key_en ? "bg-amber-500" : "bg-gray-300"}`}
              >
                <div
                  className={`h-4 w-4 rounded-full bg-white transition ${data.Key_en ? "translate-x-5" : ""}`}
                />
              </div>
            </button>
          </div>
        )}

        {/* STEP 3: VR */}
        {step === 3 && (
          <div className="space-y-4">
            <div className="font-medium">Cấu hình Biến trở</div>
            <button
              onClick={() => update("Vr_en", data.Vr_en ? 0 : 1)}
              className={`flex w-full items-center justify-between rounded-xl border p-4 transition ${data.Vr_en ? "border-amber-500 bg-amber-50" : "bg-gray-50"}`}
            >
              <div className="flex items-center gap-3">
                <Zap
                  className={data.Vr_en ? "text-amber-600" : "text-gray-400"}
                />
                <div>
                  <div className="font-medium">Sử dụng Biến trở</div>
                  <div className="text-xs text-gray-500">
                    Điều chỉnh bằng biến trở
                  </div>
                </div>
              </div>
              <div
                className={`h-6 w-11 rounded-full p-1 transition ${data.Vr_en ? "bg-amber-500" : "bg-gray-300"}`}
              >
                <div
                  className={`h-4 w-4 rounded-full bg-white transition ${data.Vr_en ? "translate-x-5" : ""}`}
                />
              </div>
            </button>
          </div>
        )}

        {/* STEP 4: PREAMP */}
        {step === 4 && (
          <div className="space-y-6">
            <div className="space-y-3">
              <div className="font-medium">Có dùng EQ / Preamp không?</div>
              <button
                onClick={() => update("Pre_en", data.Pre_en ? 0 : 1)}
                className={`flex w-full items-center justify-between rounded-xl border p-4 transition ${data.Pre_en ? "border-purple-500 bg-purple-50" : "bg-gray-50"}`}
              >
                <div className="flex items-center gap-3">
                  <Sliders
                    className={
                      data.Pre_en ? "text-purple-600" : "text-gray-400"
                    }
                  />
                  <div>
                    <div className="font-medium">EQ / Preamp</div>
                    <div className="text-xs text-gray-500">
                      Bass / Mid / Treble
                    </div>
                  </div>
                </div>
                <div
                  className={`h-6 w-11 rounded-full p-1 transition ${data.Pre_en ? "bg-purple-500" : "bg-gray-300"}`}
                >
                  <div
                    className={`h-4 w-4 rounded-full bg-white transition ${data.Pre_en ? "translate-x-5" : ""}`}
                  />
                </div>
              </button>
            </div>

            {data.Pre_en === 1 ? (
              <div className="space-y-3">
                <div className="font-medium">Chọn cách điều chỉnh</div>
                <div className="grid grid-cols-3 gap-4">
                  {PREAMP_MODES.map((m, idx) => {
                    const active = data.Pre_mode === m.value;
                    const disabled = data.Vr_en === 0 && idx === 1;

                    return (
                      <button
                        key={m.value}
                        onClick={() => {
                          if (disabled) return;
                          update("Pre_mode", m.value);
                        }}
                        className={`rounded-xl border p-4 text-left transition ${active ? "border-purple-600 bg-purple-600 text-white shadow" : ""} ${
                          disabled
                            ? "cursor-not-allowed border-gray-300 bg-gray-200 text-gray-400"
                            : "bg-gray-50 hover:bg-blue-400"
                        } `}
                        title={disabled ? "Cần phải bật Biến trở trước" : ""}
                      >
                        <div className="font-medium">{m.title}</div>

                        <div
                          className={`text-xs ${
                            active
                              ? "text-purple-100"
                              : disabled
                                ? "text-gray-400"
                                : "text-gray-500"
                          }`}
                        >
                          {disabled ? "Cần phải bật Biến trở trước" : m.note}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="rounded-xl border bg-gray-50 p-4 text-sm italic text-gray-400">
                Không dùng Preamp → bỏ qua cấu hình EQ
              </div>
            )}
          </div>
        )}

        {/* STEP 5: HOÀN TẤT */}
        {step === 5 && (
          <div className="space-y-4">
            <div className="font-medium">Hoàn tất cấu hình</div>
            <div className="rounded-xl border bg-gray-50 p-4 text-sm">
              <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                <div className="text-gray-600">Audio Mode</div>
                <div className="flex items-center gap-2">
                  <span className="font-medium">
                    {getAudioMode()?.title || "-"}
                  </span>
                  <span className="text-xs italic text-gray-500">
                    ({getAudioMode()?.note})
                  </span>
                </div>
                <div className="text-gray-600">Phím bấm</div>
                <div className="font-medium">
                  {data.Key_en ? "Có" : "Không"}
                </div>
                <div className="text-gray-600">Preamp điều chỉnh</div>
                <div className="font-medium">
                  {data.Pre_en ? "Có" : "Không"}
                </div>
                {data.Pre_en === 1 && (
                  <>
                    <div className="text-gray-600">Kiểu điều chỉnh</div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">
                        {getPreampMode()?.title || "-"}
                      </span>
                      <span className="text-xs italic text-gray-500">
                        ({getPreampMode()?.note})
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
            <div className="text-sm italic text-gray-500">
              Kiểm tra lại trước khi hoàn tất cấu hình
            </div>
          </div>
        )}
      </div>

      {/* NAVIGATION */}
      <div className="flex justify-between max-w-[1000px] mx-auto">
        <div>
          {step > 1 && (
            <button
              onClick={back}
              className="rounded-xl border px-4 py-2 hover:bg-gray-50"
            >
              Quay lại
            </button>
          )}
        </div>
        <div className="flex gap-2">
          {step < steps.length && (
            <button
              onClick={next}
              className="rounded-xl bg-blue-600 px-5 py-2 text-white hover:bg-blue-700"
            >
              Tiếp theo
            </button>
          )}
          {step === steps.length && (
            <button
              onClick={finish}
              className="flex items-center gap-2 rounded-xl bg-emerald-600 px-5 py-2 text-white hover:bg-emerald-700"
            >
              <CheckCircle2 size={16} />
              Hoàn tất
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

import { useSystemConfig } from "@hooks/useSystemConfig";

const AUDIO_MODES = [
  { value: 0, label: "2.0 Stereo" },
  { value: 1, label: "2.1 Sub" },
  { value: 2, label: "Mono" },
  { value: 3, label: "1.1" },
  { value: 4, label: "3 Way" },
];

const DEFAULT_MODES = [
  { value: 1, label: "Bluetooth" },
  { value: 2, label: "AUX" },
];

/* ================= UI ================= */

export default function TabBluetooth() {
  const { data, update, save } = useSystemConfig();

  if (!data) {
    return <div className="flex justify-start">loading</div>;
  }
  const {
    Delay_start,
    Audio_mode,
    Nho_mode,
    Mode_mac_dinh,
    Nho_mode_effect,
    I2s1_en,
  } = data;

  const selectClass =
    "w-full h-10 px-3 border border-gray-500 rounded-xl bg-white text-sm text-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-400 shadow-sm hover:shadow-md transition";

  const selectClassDisabled =
    "w-full h-10 px-3 border border-gray-200 rounded-xl bg-gray-100 text-gray-400 cursor-not-allowed focus:outline-none shadow-sm";

  return (
    <div className="mx-auto max-w-[1000px] space-y-3 p-2 text-base">
      {/* TITLE */}
      <h2 className="text-2xl font-bold text-gray-800 drop-shadow-sm">
        Cấu hình hệ thống
      </h2>

      {/* CARD */}
      <div className="divide-y divide-gray-300 overflow-hidden rounded-2xl border border-gray-200 bg-gradient-to-br from-white to-gray-50 shadow-2xl">
        {/* ROWS */}
        <FormRow label="Delay bật nguồn">
          <select
            value={Delay_start}
            onChange={(e) => update("Delay_start", Number(e.target.value))}
            className={selectClass}
            title="Chờ mạch công suất khởi động trước"
          >
            {Array.from({ length: 51 }, (_, i) => (
              <option key={i} value={i}>
                {i * 100} ms
              </option>
            ))}
          </select>
        </FormRow>

        <FormRow label="Audio Mode">
          <select
            value={Audio_mode}
            disabled
            className={selectClassDisabled}
            title="Chỉ sửa ở Cài đặt nhanh"
          >
            {AUDIO_MODES.map((m) => (
              <option key={m.value} value={m.value}>
                {m.label}
              </option>
            ))}
          </select>
        </FormRow>

        <FormRow label="Nhớ mode BT/AUX">
          <Switch
            checked={Nho_mode === 1}
            onChange={(v) => update("Nho_mode", v ? 1 : 0)}
            title="Khởi động lại sẽ nhớ mode cũ trước đó khi tắt"
          />
        </FormRow>

        <FormRow label="Mode mặc định">
          <select
            value={Mode_mac_dinh}
            disabled={Nho_mode === 1}
            onChange={(e) => update("Mode_mac_dinh", Number(e.target.value))}
            className={Nho_mode === 1 ? selectClassDisabled : selectClass}
            title="Khởi động lại sẽ mặc định bật mode này"
          >
            {DEFAULT_MODES.map((m) => (
              <option key={m.value} value={m.value}>
                {m.label}
              </option>
            ))}
          </select>
        </FormRow>

        <FormRow label="Nhớ Effect">
          <Switch
            checked={Nho_mode_effect === 1}
            onChange={(v) => update("Nho_mode_effect", v ? 1 : 0)}
            title="Khởi động lại sẽ mặc định bật Effect trước đó"
          />
        </FormRow>

        <FormRow label="I2S 1 ON">
          <Switch
            checked={I2s1_en === 1}
            onChange={(v) => update("I2s1_en", v ? 1 : 0)}
            title="Kết nối xuất tín hiệu chất lượng cao ra DAC ngoài"
          />
        </FormRow>
      </div>

      {/* SAVE BUTTON */}
      <button
        onClick={save}
        className="transform rounded-2xl bg-gradient-to-r from-blue-500 to-blue-600 px-6 py-2 font-medium text-white shadow-lg transition hover:scale-105 hover:shadow-xl"
      >
        Lưu cấu hình
      </button>
    </div>
  );
}

/* ================= ROW ================= */

function FormRow({ label, children }) {
  return (
    <div className="grid grid-cols-1 items-center gap-4 px-5 py-4 md:grid-cols-2">
      <div className="font-medium text-gray-700">{label}</div>
      <div className="flex justify-start">{children}</div>
    </div>
  );
}

/* ================= SWITCH ================= */

function Switch({ checked, onChange, disabled, title }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      title={title}
      className={`flex h-6 w-12 items-center rounded-full p-0.5 transition ${
        checked ? "bg-blue-600" : "bg-slate-300"
      } ${disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"}`}
    >
      <div
        className={`h-5 w-5 rounded-full bg-white shadow transition-transform ${
          checked ? "translate-x-5" : ""
        }`}
      />
    </button>
  );
}

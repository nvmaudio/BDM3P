import { useSystemConfig } from "@hooks/useSystemConfig";

const PROFILES = [
  { value: 0, label: "Tai nghe (Headset)" },
  { value: 1, label: "Thiết bị rảnh tay (Handsfree)" },
  { value: 2, label: "Loa ngoài (Loudspeaker)" },
  { value: 3, label: "Tai nghe (Headphones)" },
  { value: 4, label: "Hệ thống âm thanh Hi-Fi (Hi-Fi Audio)" },
];

const A2dp_AAC = [
  { value: 0, label: "SBC" },
  { value: 1, label: "AAC + SBC" },
];

export default function TabBluetooth() {
  const { data, update, save } = useSystemConfig();

  if (!data) {
    return <div className="flex justify-start">loading</div>;
  }

  const selectClass =
    "w-full h-10 px-3 border border-gray-500 rounded-xl bg-white text-sm text-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-400 shadow-sm hover:shadow-md transition";

  const selectClassBlue =
    "w-full h-10 px-3 border border-blue-300 rounded-xl bg-white text-sm text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 shadow-sm hover:shadow-md transition";

  const selectClassDisabled =
    "w-full h-10 px-3 border border-gray-200 rounded-xl bg-gray-100 text-gray-400 cursor-not-allowed focus:outline-none shadow-sm";

  return (
    <div className="mx-auto max-w-[1000px] space-y-3 p-2 text-base">
      <h2 className="text-xl font-bold text-gray-800 drop-shadow-sm">
        Cấu hình Bluetooth
      </h2>

      <div className="divide-y divide-gray-300 overflow-hidden rounded-2xl border border-gray-200 bg-gradient-to-br from-white to-gray-50 shadow-2xl">
        {/* Tên Bluetooth */}
        <FormRow label="Tên Bluetooth">
          <input
            type="text"
            value={data.BT_Name}
            onChange={(e) => update("BT_Name", e.target.value)}
            className={selectClassBlue}
            maxLength={40}
            title="Tên Bluetooth (tối đa 40 ký tự)"
          />
        </FormRow>

        {/* Profile */}
        <FormRow label="Profile BT">
          <select
            value={data.Profile_BT}
            onChange={(e) => update("Profile_BT", Number(e.target.value))}
            className={selectClass}
            title="Chọn profile Bluetooth"
          >
            {PROFILES.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </FormRow>

        {/* A2DP AAC */}
        <FormRow label="Định dạng âm thanh">
          <select
            value={data.A2dp_AAC}
            onChange={(e) => update("A2dp_AAC", Number(e.target.value))}
            className={selectClass}
            title="Chọn định dạng âm thanh"
          >
            {A2dp_AAC.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </FormRow>

        {/* Background type */}
        <FormRow label="Chạy nền BT">
          <Switch
            checked={data.Bt_BackgroundType === 1}
            onChange={(v) => update("Bt_BackgroundType", v ? 1 : 0)}
            title="Bật/tắt chạy nền Bluetooth"
          />
        </FormRow>

        {/* Simple pairing */}
        <FormRow label="Yêu cầu mật khẩu khi kết nối">
          <Switch
            checked={data.Bt_SimplePairingEnable === 0}
            onChange={(v) => update("Bt_SimplePairingEnable", v ? 0 : 1)}
            title="Bật/tắt simple pairing"
          />
        </FormRow>

        {/* PIN Code */}
        <FormRow label="Mã PIN Bluetooth">
          <input
            type="text"
            value={data.Bt_PinCode}
            onChange={(e) => update("Bt_PinCode", e.target.value)}
            maxLength={4}
            className={
              data?.Bt_SimplePairingEnable === 0
                ? selectClass
                : selectClassDisabled
            }
            title="Mã PIN Bluetooth (tối đa 4 ký tự),  BLE luôn cần"
          />
        </FormRow>
      </div>

      {/* SAVE BUTTON */}
      <button
        onClick={save}
        className="transform rounded-2xl bg-gradient-to-r from-blue-500 to-blue-600 px-6 py-2 font-medium text-white shadow-lg transition hover:scale-105 hover:shadow-xl"
      >
        Lưu cấu hình
      </button>
    </div>
  );
}

/* ================= ROW ================= */
function FormRow({ label, children }) {
  return (
    <div className="grid grid-cols-1 items-center gap-4 px-5 py-4 md:grid-cols-2">
      <div className="font-medium text-gray-700">{label}</div>
      <div className="flex justify-start">{children}</div>
    </div>
  );
}

/* ================= SWITCH ================= */
function Switch({ checked, onChange, disabled, title }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      title={title}
      className={`flex h-6 w-12 items-center rounded-full p-0.5 transition ${
        checked ? "bg-blue-600" : "bg-slate-300"
      } ${disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"}`}
    >
      <div
        className={`h-5 w-5 rounded-full bg-white shadow transition ${
          checked ? "translate-x-5" : ""
        }`}
      />
    </button>
  );
}

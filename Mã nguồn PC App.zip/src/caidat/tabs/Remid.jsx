import { useState, useRef, useEffect } from "react";
import { useSystemConfig } from "@hooks/useSystemConfig";
import { useDeviceStore } from "@store/useDeviceStore";

const musicFolder = "/data/mp3/";

const initialSounds = [
  { name: "BTmode", path: "BTmode.mp3" },
  { name: "AUXmode", path: "AUXmode.mp3" },
  { name: "PCmode", path: "PCmode.mp3" },
  { name: "connected", path: "connected.mp3" },
  { name: "disconnect", path: "disconnect.mp3" },
  { name: "Twsconnected", path: "Twsconnected.mp3" },
  { name: "Volmax", path: "Volmax.mp3" },
  { name: "BTpair", path: "BTpair.mp3" },
];

export default function TabRemid() {
  const { mode } = useDeviceStore();
  const { sendAndWaitRemid } = useSystemConfig();

  const { startFlash, appendLog, updateProgress, close } = useFlashStore();
  const [sounds, setSounds] = useState(initialSounds);

  const fileToBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result.split(",")[1]);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

  const handleFileChange = async (e, index) => {
    const file = e.target.files[0];
    if (!file) return;
    const tempUrl = URL.createObjectURL(file);
    const audio = new Audio(tempUrl);
    audio.addEventListener("loadedmetadata", async () => {
      if (audio.duration > 10) {
        alert("File quá 10 giây, vui lòng chọn file ngắn hơn.");
        URL.revokeObjectURL(tempUrl);
        return;
      }
      const base64Data = await fileToBase64(file);
      const logResult = await chrome.webview.hostObjects.bridge.SaveFile(
        base64Data,
        sounds[index].path,
      );
      if (logResult === "error") alert("Upload ERROR!");
      else alert("Upload Done! path: " + logResult);
      URL.revokeObjectURL(tempUrl);
    });
  };

  const flash_remid = async () => {
    try {
      if (mode !== "hid") {
        await new Promise((resolve) => {
          if (window.confirm("Chỉ hỗ trợ khi cắm cáp kết nối USB!")) {
            close();
            resolve(true);
          } else {
            resolve(false);
          }
        });

        return;
      }

      startFlash();
      appendLog("FLASH: Tạo tệp bin...");
      const data = await chrome.webview.hostObjects.bridge.Mp2ToHex(400);
      appendLog(`FLASH: Tạo tệp bin thành công, ${data.length} bytes`);

      const Flash_Cmd = { Frame: 1, BlockEnd: 2, Done: 3 };

      const BLOCK_SIZE = 4096;
      const FRAME_SIZE = 240;
      const totalBlocks = Math.ceil(data.length / BLOCK_SIZE);

      let totalFramesSent = 0;
      let totalFrames = 0;

      for (let i = 0; i < totalBlocks; i++) {
        const blockLen = Math.min(BLOCK_SIZE, data.length - i * BLOCK_SIZE);
        totalFrames += Math.ceil(blockLen / FRAME_SIZE);
      }

      for (let blockIndex = 0; blockIndex < totalBlocks; blockIndex++) {
        const blockStart = blockIndex * BLOCK_SIZE;
        const blockEnd = Math.min(blockStart + BLOCK_SIZE, data.length);
        const blockData = data.slice(blockStart, blockEnd);

        let crc = 0;
        for (let b of blockData) crc ^= b;

        const totalFramesInBlock = Math.ceil(blockData.length / FRAME_SIZE);

        for (
          let frameIndex = 0;
          frameIndex < totalFramesInBlock;
          frameIndex++
        ) {
          const frameStart = frameIndex * FRAME_SIZE;
          const frameEnd = Math.min(frameStart + FRAME_SIZE, blockData.length);
          const frameData = blockData.slice(frameStart, frameEnd);

          const payload = new Uint8Array(3 + frameData.length);
          payload[0] = frameIndex;
          payload[1] = blockIndex;
          payload[2] = frameData.length;
          payload.set(frameData, 3);

          const ok = await sendAndWaitRemid(Flash_Cmd.Frame, payload);
          if (!ok) {
            appendLog(`Error: Frame ${frameIndex} Block ${blockIndex} failed`);
            return;
          }

          await new Promise((r) => setTimeout(r, 1));

          totalFramesSent++;
          const percent = ((totalFramesSent / totalFrames) * 100).toFixed(2);
          updateProgress(percent);
          appendLog(
            `Progress: Frame ${frameIndex} Block ${blockIndex} - ${percent}%`,
          );
        }

        // Block End
        const blockEndPayload = new Uint8Array([blockIndex, crc]);
        const okBlock = await sendAndWaitRemid(
          Flash_Cmd.BlockEnd,
          blockEndPayload,
        );

        await new Promise((r) => setTimeout(r, 4));

        if (!okBlock) {
          appendLog(`Error: BlockEnd ${blockIndex} failed`);
          return;
        }
        appendLog(`Progress: Block ${blockIndex + 1}/${totalBlocks} done`);
      }

      // Done
      const doneOk = await sendAndWaitRemid(Flash_Cmd.Done, new Uint8Array([]));
      if (!doneOk) {
        appendLog("Error: Done command failed");
        return;
      }
      appendLog("Flash completed successfully!");
      updateProgress(100);

      await new Promise((r) => setTimeout(r, 3000));

      appendLog(false);

      await new Promise((resolve) => {
        if (
          window.confirm(
            "Đã flash xong nhạc thông báo.\nVui lòng khởi động lại Bo mạch để Áp Dụng!",
          )
        ) {
          close();
          resolve(true);
        } else {
          resolve(false);
        }
      });
    } catch (err) {
      appendLog(`Exception: ${err}`);

      if (window.confirm(`Lỗi.\nVui lòng nạp lại data thử lần nữa! ${err}`)) {
        close();
        resolve(true);
      } else {
        resolve(false);
      }
    }
  };

  return (
    <div className="mx-auto max-w-[1000px] p-4 space-y-4">
      <h2 className="text-xl font-semibold text-gray-800">
        Thay đổi nhạc thông báo
      </h2>

      <div className="rounded-3xl border border-gray-200 bg-white/80 backdrop-blur shadow-xl p-4">
        <h3>Âm thanh thông báo</h3>
        <table className="w-full text-center mt-2 border border-gray-300 text-sm">
          <thead>
            <tr>
              <th className="border px-2 py-1">Tên Sự kiện</th>
              <th className="border px-2 py-1">Nghe thử</th>
              <th className="border px-2 py-1">Thay đổi Tệp Tin</th>
              <th className="border px-2 py-1">Đường dẫn</th>
            </tr>
          </thead>
          <tbody>
            {sounds.map((sound, index) => (
              <tr key={index}>
                <td className="border px-2 py-1">{sound.name}</td>
                <td className="border px-2 py-1">
                  <button
                    className="px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                    onClick={() =>
                      sound.path && new Audio(musicFolder + sound.path).play()
                    }
                  >
                    Play
                  </button>
                </td>
                <td className="border px-2 py-1">
                  <input
                    type="file"
                    accept=".mp3"
                    onChange={(e) => handleFileChange(e, index)}
                  />
                </td>
                <td className="border px-2 py-1">{sound.path}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <small className="text-gray-500">Độ dài tối đa: 10 Giây</small>

        <br />
        <button
          className="mt-2 px-4 py-2 bg-yellow-400 text-black rounded-xl hover:bg-yellow-500 disabled:bg-yellow-200 disabled:cursor-not-allowed transition-colors"
          onClick={flash_remid}
        >
          Flash dữ liệu
        </button>
      </div>
    </div>
  );
}

// flashStore.js
import { create } from "zustand";

export const useFlashStore = create((set) => ({
  open: false,
  progress: 0,
  logs: [],
  startFlash: () => set({ open: true, progress: 0, logs: [] }),
  updateProgress: (p) => set({ progress: Number(p) || 0 }),
  appendLog: (log) => set((state) => ({ logs: [...state.logs, log] })),
  close: () => set({ open: false }),
}));

export function FlashModal() {
  const logRef = useRef(null);

  const { open, progress, logs } = useFlashStore();

  // Scroll log xuống cuối mỗi khi logs thay đổi
  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [logs]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-2xl shadow-xl w-[400px] max-w-full p-6 relative">
        <h3 className="text-lg font-semibold mb-4">Flash dữ liệu</h3>

        {/* Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-5 mb-4 overflow-hidden">
          <div
            className="bg-blue-600 h-5 text-white text-xs flex items-center justify-center"
            style={{ width: `${Number(progress)}%` }}
          >
            {Number(progress).toFixed(2)}%
          </div>
        </div>

        {/* Log Output */}
        <div
          ref={logRef}
          className="h-48 overflow-y-auto border border-gray-300 rounded p-2 text-sm bg-gray-50"
        >
          {logs.map((log, idx) => (
            <div key={idx}>{log}</div>
          ))}
        </div>
      </div>
    </div>
  );
}

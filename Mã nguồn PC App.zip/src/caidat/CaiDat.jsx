import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

/* ===== LUCIDE ICONS ===== */
import {
  Settings,
  Volume2,
  Bluetooth,
  Bell,
  Music,
  Key,
  Speaker,
} from "lucide-react";

/* ===== TABS ===== */
import TabVolume from "./tabs/TabVolume";
import TabBluetooth from "./tabs/TabBluetooth";
import TabKey from "./tabs/TabKey";
import TabParameter from "./tabs/TabParameter";
import TabPreamp from "./tabs/TabPreamp";
import TabSystem from "./tabs/TabSystem";
import TabThongBao from "./tabs/TabThongBao";
import TabRemid, { FlashModal } from "./tabs/Remid";

const menus = [
  {
    id: "system",
    label: "Cài Đặt Nhanh",
    icon: Settings,
    color: "text-blue-500",
    hoverBg: "hover:bg-blue-50",
    activeBg: "bg-blue-500 text-white",
  },
  {
    id: "system1",
    label: "Tham số hệ thống",
    icon: Settings,
    color: "text-orange-500",
    hoverBg: "hover:bg-orange-50",
    activeBg: "bg-orange-500 text-white",
  },
  {
    id: "volume",
    label: "Âm Lượng",
    icon: Volume2,
    color: "text-emerald-500",
    hoverBg: "hover:bg-emerald-50",
    activeBg: "bg-emerald-500 text-white",
  },
  {
    id: "bluetooth",
    label: "Bluetooth",
    icon: Bluetooth,
    color: "text-indigo-500",
    hoverBg: "hover:bg-indigo-50",
    activeBg: "bg-indigo-500 text-white",
  },
  {
    id: "thongbao",
    label: "Nhạc thông báo",
    icon: Bell,
    color: "text-yellow-500",
    hoverBg: "hover:bg-yellow-50",
    activeBg: "bg-yellow-500 text-white",
  },
  {
    id: "remid",
    label: "Thay Nhạc thông báo",
    icon: Music,
    color: "text-purple-500",
    hoverBg: "hover:bg-purple-50",
    activeBg: "bg-purple-500 text-white",
  },
  {
    id: "key",
    label: "Phím bấm",
    icon: Key,
    color: "text-pink-500",
    hoverBg: "hover:bg-pink-50",
    activeBg: "bg-pink-500 text-white",
  },
  {
    id: "preamp",
    label: "Preamp",
    icon: Speaker,
    color: "text-teal-500",
    hoverBg: "hover:bg-teal-50",
    activeBg: "bg-teal-500 text-white",
  },
];

const tabMap = {
  system: TabSystem,
  system1: TabParameter,
  volume: TabVolume,
  bluetooth: TabBluetooth,
  thongbao: TabThongBao,
  remid: TabRemid,
  key: TabKey,
  preamp: TabPreamp,
};

import { useSystemConfig } from "@hooks/useSystemConfig";

export default function CaiDatMenu() {
  const { loadData, onData, pushVrLog } = useSystemConfig();

  const nav = useNavigate();
  const [activeMenu, setActiveMenu] = useState("system");

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    const off = onData((packet) => {
      if (packet.cmd === 200) {
        pushVrLog(packet.data);
      }
    });

    return off;
  }, [onData]);

  const ActiveTab = tabMap[activeMenu] || (() => <p>Tab chưa có</p>);

  return (
    <div className="w-screen h-screen bg-gradient-to-br from-slate-100 to-slate-200 flex flex-col">
      {/* HEADER */}
      <div className="fixed top-0 left-0 w-full h-[60px] flex items-center justify-between px-6 bg-white/70 backdrop-blur-xl border-b border-slate-200 shadow-sm z-50">
        <h1 className="text-lg font-semibold">Cài đặt</h1>
        <button
          onClick={() => nav("/")}
          className="px-4 py-2 bg-gray-500 text-white rounded-xl shadow hover:bg-gray-600 transition"
        >
          Quay lại
        </button>
      </div>

      {/* BODY */}
      <div className="flex flex-1 pt-[60px] overflow-hidden gap-4">
        {/* SIDEBAR */}
        <div className="w-64 py-4 pl-4 text-base">
          <div className="h-full bg-white/70 backdrop-blur-xl rounded-2xl border border-slate-200 shadow-sm p-3 space-y-2">
            {menus.map((menu) => {
              const Icon = menu.icon;
              const isActive = activeMenu === menu.id;

              return (
                <button
                  key={menu.id}
                  onClick={() => setActiveMenu(menu.id)}
                  className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl text-left transition ${
                    isActive ? menu.activeBg : menu.hoverBg
                  }`}
                >
                  <Icon
                    size={18}
                    className={isActive ? "text-white" : menu.color}
                  />
                  {menu.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* CONTENT */}
        <div className="flex-1 py-4 pr-4 overflow-auto">
          <div className="h-full bg-white/70 backdrop-blur-xl rounded-2xl border border-slate-200 shadow-sm p-6">
            <ActiveTab />
          </div>
        </div>
      </div>

      <FlashModal />
    </div>
  );
}
